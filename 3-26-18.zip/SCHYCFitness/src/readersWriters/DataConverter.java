package readersWriters;

import readersWriters.*;
import containers.*;
import java.util.*;

import com.sf.ext.InvoiceData;

public class DataConverter {
 
 //Create the reader and writer objects needed for each data type
 protected static PersonReader readP= new PersonReader();
 protected static AssetMasterList list= new AssetMasterList();
 protected static MemberReader readM= new MemberReader();
 private static JSONWriter jWrite= new JSONWriter();
 private static XMLWriter xmlWrite= new XMLWriter();
 protected static InvoiceWriter iWrite= new InvoiceWriter();
 
	public static void main(String[] args) {
		
		//Create array lists to store each data type
		ArrayList<Person> personList = new ArrayList<Person>();
		ArrayList<Member> memberList= new ArrayList<Member>();
		ArrayList<Asset> masterAsset= list.readAssets();
		
		//Populate each array list by using getter methods
		personList= PersonReader.getPersonList();
		memberList= readM.getMemberList();
		
		
		
		
		//Convert each list into a neatly formatted output type
		jWrite.JSONConverter(masterAsset, "data/Products.json");
		jWrite.JSONConverter(memberList, "data/Members.json");
		jWrite.JSONConverter(personList, "data/Persons.json");
		xmlWrite.xmlConverter(masterAsset, "data/Products.xml");
		xmlWrite.xmlConverter(memberList, "data/Members.xml");
		xmlWrite.xmlConverter(personList, "data/Persons.xml");
		iWrite.writeInvoices();
		
//		InvoiceData.removeAllPersons();
//		InvoiceData.addPerson("04jj", "firstName", "lastName", "street", "city", "state", "zip", "country");
//		InvoiceData.addEmail("04jj", "pickledude@gmail.com");
//		InvoiceData.removeAllMembers();
//		InvoiceData.addMember("8888", "S", "04jj", "mike hunt", "street", "city", "state", "zip", "country");
//		InvoiceData.removeAllProducts();
//		InvoiceData.addDayPass("qq33", "2017-11-12", "street", "city", "state", "zip", "country", 4, 3.00, 2.00, 12.00, 11.00);
//		InvoiceData.addYearPass("qq33", "2017-11-12", "2018-11-13", "street", "city", "state", "zip", "country", "potato membership", 4, 3.00, 2.00, 12.00, 11.00);
//		InvoiceData.addParkingPass("po90", 5, 3.00, 2.00, 12.00, 11.00);
//		InvoiceData.addRental("ffg5", "potato cannon", 5, 3.00, 2.00, 12.00, 11.00);
//		InvoiceData.removeAllInvoices();
//		InvoiceData.addInvoice("rtf2", "8888", "04jj", "2017-11-12", 5.00, 3.00, 2.00, 12.00);
//		InvoiceData.addDayPassToInvoice("qq33", "2017-11-12", "street", "city", "state", "zip", "country", 4, 5.00, 3.00, 8.00, 2.00, "rtf2");
//		InvoiceData.addYearPassToInvoice("qq33", "2017-05-12", "2017-05-12", "street", "city", "state", "zip", "country", "name", 5, 6.00, 7.00, 8.00, 9.00, "rtf2");
//		InvoiceData.addParkingPassToInvoice("55ew", 3, 5.55, 7.74, 49.33, 58.32, "rtf2");
//		InvoiceData.addRentalToInvoice("gh3h", "name", 5, 5.43, 5, 6.44, 8.00, "rtf2");
	}

}