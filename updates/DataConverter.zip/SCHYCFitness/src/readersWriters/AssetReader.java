package readersWriters;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.*;
import containers.*;

public class AssetReader {
	
	private static ArrayList<YearLongMembership> yearList= new ArrayList<YearLongMembership>();
	private static ArrayList<DayMembership> dayList= new ArrayList<DayMembership>();
	private static ArrayList<EquipmentRental> equipList= new ArrayList<EquipmentRental>();
	private static ArrayList<ParkingPass> parkList= new ArrayList<ParkingPass>();
	
	private static void ReadAssets () {
		
		//Lists are cleared to prevent overwriting the same info repeatedly
		yearList.clear();
		dayList.clear();
		equipList.clear();
		parkList.clear();
		
		//Create an array list
		ArrayList<String> strings = new ArrayList<String>();
		
		//Open the reader to import data
		try { 
			BufferedReader in = new BufferedReader(new FileReader("data/Products.dat"));
			in.readLine();
		
			String str;
		
			//Read in each line of the input file
			while((str = in.readLine()) != null){
				if (str.length()>0){
					strings.add(str);
				}
			}
			
			//Close the reader
			in.close();
		
		}
		
		//Display error message if file name is invalid
		catch (Exception e){ e.printStackTrace();
		System.out.println("File not found");
	}
		
		//Split each asset string into its components based on the asset type
		for (String s:strings){
			String data []= s.split("[;]");
			
			if (data[1].equalsIgnoreCase("Y")){
				
				String address []=data[4].split("[,]");
				Address a= new Address (address[0],address[1],address[2],address[4],address[3]);
				YearLongMembership y= new YearLongMembership (data[0],"Y",Double.parseDouble(data[6]),data[2],data[3],a,data[5]);
				yearList.add(y);
				
			}
			
			else if (data[1].equalsIgnoreCase("R")){
				
				EquipmentRental r= new EquipmentRental (data[0],"R",Double.parseDouble(data[3]), data[2]);
				equipList.add(r);
				
			}
			
			else if (data[1].equalsIgnoreCase("D")){

				String address []=data[3].split("[,]");
				Address a= new Address (address[0],address[1],address[2],address[4],address[3]);
				DayMembership d= new DayMembership(data[0],"D",Double.parseDouble(data[4]), a,data[2]);
				dayList.add(d);
				
			}
			
			else if (data[1].equalsIgnoreCase("P")){

				ParkingPass p= new ParkingPass(data[0],"P", Double.parseDouble(data[2]));
				parkList.add(p);
				
			}
			
		}
		
	}
	
	//Getter methods
	public static ArrayList<YearLongMembership> getYearList() {
		ReadAssets();
		return yearList;
	}
	
	public static ArrayList<DayMembership> getDayList() {
		ReadAssets();
		return dayList;
	}

	public static ArrayList<EquipmentRental> getEquipList() {
		ReadAssets();
		return equipList;
	}
	
	public static ArrayList<ParkingPass> getParkList() {
		ReadAssets();
		return parkList;
	}
	
}