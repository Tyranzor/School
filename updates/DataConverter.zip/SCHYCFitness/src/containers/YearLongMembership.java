package containers;

public class YearLongMembership extends Asset {

	private String startDate;
	private String endDate;
	private Address address;
	private String membershipName;
	
	//Year long membership constructor
	public YearLongMembership(String productCode, String identifier, double cost, String startDate, String endDate,
			Address address, String membershipName) {
		super(productCode, "Y", cost);
		this.startDate = startDate;
		this.endDate = endDate;
		this.address = address;
		this.membershipName = membershipName;
	}
	
	//Getter methods
	public String getStartDate() {
		return startDate;
	}
	
	public String getEndDate() {
		return endDate;
	}

	public Address getAddress() {
		return address;
	}
	
	public String getMembershipName() {
		return membershipName;
	}
	
}
