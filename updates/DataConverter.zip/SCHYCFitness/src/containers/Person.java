package containers;
import containers.Address;

public class Person extends Object {
	
	private String lastName;
	private String personCode;
	private String emaillist;
	private Address address; 
	private String firstName;

	//Person constructor without email
	public Person( String lastName, String personCode, Address address, String firstName) {
		super();
		this.lastName = lastName;
		this.personCode = personCode;
		this.address = address;
		this.firstName = firstName;
	}
	
	//Person constructor with email
	public Person( String lastName, String personCode, String emaillist, Address address,
			String firstName) {
		super();
		this.lastName = lastName;
		this.personCode = personCode;
		this.emaillist = emaillist;
		this.address = address;
		this.firstName = firstName;
	}

	//Getter methods
	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public String getPersonCode() {
		return personCode;
	}

	public String getEmaillist() {
		return emaillist;
	}
	
	public Address getAddress(){
		return this.address;
		
	}
	
}