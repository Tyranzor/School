package readersWriters;
import java.util.*;
import containers.*;

public class DataConversion {
private static Reader reader= new Reader();
private static ArrayList<Customer> customerList ;
private static ArrayList<ExpertBroker> eBrokerList;
private static ArrayList<JuniorBroker> jBrokerList;
private static ArrayList<Stock> stockList ;
private static ArrayList <DepositAccount> accountList;
private static ArrayList <PrivateInvestment> investmentList;
private static ArrayList <Asset> assetList= new ArrayList<Asset>();
private static ArrayList <Person> personlist= new ArrayList<Person>();
private static XMLWriter xwrite= new XMLWriter();
private static JSONWriter jwrite = new JSONWriter();
public static void main (String args[]){
	
	reader.readPersons();
	reader.readAssets();
	customerList=reader.getCustomerList();
	eBrokerList=reader.geteBrokerList();
	jBrokerList=reader.getjBrokerList();
	stockList=reader.getStockList();
	accountList=reader.getAccountList();
	investmentList=reader.getInvestmentList();
	
	xwrite.xmlPersonConverter(jBrokerList);
	for (Customer c:customerList){
		personlist.add(c);
	}
	for (JuniorBroker jb: jBrokerList){
		personlist.add(jb);
	}
	for (ExpertBroker eb: eBrokerList){
			personlist.add(eb);
	}
	for (Stock s:stockList){
		assetList.add(s);
	}
	for (DepositAccount da:accountList){
		assetList.add(da);
	}
	for (PrivateInvestment pi:investmentList){
		assetList.add(pi);
	}
	xwrite.xmlPersonConverter(personlist);
	xwrite.xmlAssetsConverter(assetList);
	jwrite.JSONPersonConverter(personlist);
	jwrite.JSONAssetConverter(assetList);
	
	}
}
