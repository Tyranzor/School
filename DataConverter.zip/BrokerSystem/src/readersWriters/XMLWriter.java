package readersWriters;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import com.thoughtworks.xstream.XStream;
import containers.*;




public class XMLWriter {

	public <T extends Person> void xmlPersonConverter(ArrayList<T> personList){
		XStream xs= new XStream();
		File xmlOutput= new File ("data/People.xml");
		PrintWriter xmlPrintWriter = null; 
			
		try {
			 xmlPrintWriter = new PrintWriter(xmlOutput);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		xmlPrintWriter.write("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n");
		xs.alias("person", Person.class);
		
		for (Object anObject : personList) {
			// Use toXML method to convert Person object into a String
			String personOutput = xs.toXML(anObject);
			xmlPrintWriter.write(personOutput);
		}
		xmlPrintWriter.close();
	}
	
	public <T extends Asset> void xmlAssetsConverter(ArrayList<T> Objects){
		XStream xs= new XStream();
		File xmlOutput= new File ("data/Assets.xml");
		PrintWriter xmlPrintWriter = null; 
			
		try {
			 xmlPrintWriter = new PrintWriter(xmlOutput);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		xmlPrintWriter.write("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n");
		xs.alias("person", Person.class);
		for (Object anObject : Objects) {
			// Use toXML method to convert Person object into a String
			String personOutput = xs.toXML(anObject);
			xmlPrintWriter.write(personOutput);
		}
		xmlPrintWriter.close();
	}
}




