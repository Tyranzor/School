package containers;

public class JuniorBroker extends Person {
private  String JBIdentifier;
@SuppressWarnings("unused")
private String secCode;


public JuniorBroker(String Identifier,String firstName, String lastName, String street, String city, String state, String country,
		String zip, String personCode, String emaillist,String secCode) {
	super(firstName, lastName, street, city, state, country, zip, personCode, emaillist);
	this.JBIdentifier=Identifier;
	this.secCode=secCode;
	// TODO Auto-generated constructor stub
}

public JuniorBroker(String Identifier, String firstName, String lastName, String street, String city, String state, String country,
		String zip, String personCode,String secCode) {
	super(firstName, lastName, street, city, state, country, zip, personCode);
	this.JBIdentifier=Identifier;
	this.secCode=secCode;
	// TODO Auto-generated constructor stub
}

	/**
 * @return the identifier
 */
public String getIdentifier() {
	return JBIdentifier;
}
	
}
