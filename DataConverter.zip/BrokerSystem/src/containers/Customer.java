package containers;

public class Customer extends Person {
	@SuppressWarnings("unused")
	private String Identifier="";
	public Customer(String firstName, String lastName, String street, String city, String state, String country,
			String zip, String personCode) {
		super(firstName, lastName, street, city, state, country, zip, personCode);
		// TODO Auto-generated constructor stub
	}

	public Customer(String firstName, String lastName, String street, String city, String state, String country,
			String zip, String personCode,String emaillist) {
		super(firstName, lastName, street, city, state, country, zip, personCode, emaillist);
		// TODO Auto-generated constructor stub
	}

}
