package containers;

public abstract class Asset extends Object {
private transient String Code;
private transient String Identifier;
/**
 * @return the code
 */
public String getCode() {
	return Code;
}
/**
 * @return the identifier
 */
public String getIdentifier() {
	return Identifier;
}

}
