package containers;

public class DepositAccount extends Asset {
	
private String code;
private String Identifier="D";
private String label;
private double apr;

/**
 * @param code
 * @param identifier
 * @param label
 * @param apr
 */
public DepositAccount(String code, String label, double apr) {
	super();
	this.code = code;
	this.label = label;
	this.apr = apr;
}
/**
 * @return the code
 */
public String getCode() {
	return code;
}
/**
 * @return the identifier
 */
public String getIdentifier() {
	return Identifier;
}
/**
 * @return the label
 */
public String getLabel() {
	return label;
}
/**
 * @return the apr
 */
public double getApr() {
	return apr;
}
}
