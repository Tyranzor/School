package containers;

public abstract class Person extends Object {
	private transient String Identifier= "";
	

	private String firstName;
	private String lastName;
	private String street;
	private String city;
	private String state;
	private String country;
	private String zip;
	private String personCode;
	private String emaillist;
	
	/**
	 * @param identifier
	 * @param firstName
	 * @param lastName
	 * @param street
	 * @param city
	 * @param state
	 * @param country
	 * @param zip
	 * @param personCode
	 * @param emaillist
	 */
	public Person(String firstName, String lastName, String street, String city, String state,
			String country, String zip, String personCode,String emaillist) {
		super();
		this.Identifier = "";
		this.firstName = firstName;
		this.lastName = lastName;
		this.street = street;
		this.city = city;
		this.state = state;
		this.country = country;
		this.zip = zip;
		this.personCode = personCode;
		this.emaillist = emaillist;
	}
	
	/**
	 * @param firstName
	 * @param lastName
	 * @param street
	 * @param city
	 * @param state
	 * @param country
	 * @param zip
	 * @param personCode
	 */
	public Person(String firstName, String lastName, String street, String city, String state, String country,
			String zip, String personCode) {
		super();
		this.Identifier="";
		this.firstName = firstName;
		this.lastName = lastName;
		this.street = street;
		this.city = city;
		this.state = state;
		this.country = country;
		this.zip = zip;
		this.personCode = personCode;
	}


	// Getter and Setter methods
	public String getAddress(){
		return this.street+","+this.city+","+this.state+","+this.zip+","+this.country;
		
	}
	
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPersoncode() {
		return personCode;
	}

	public void setPersonCode(String personCode) {
		this.personCode = personCode;
	}

	public String getEmaillist() {
		return emaillist;
	}

	public void setEmaillist(String emaillist) {
		this.emaillist = emaillist;
	}
	/**
	 * @return the identifier
	 */
	public String getIdentifier() {
		return Identifier;
	}
	
}



