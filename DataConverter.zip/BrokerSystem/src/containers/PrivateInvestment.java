package containers;

public class PrivateInvestment extends Asset {
private String code;
private final String Identifier="P";
private double quarterlyDivedend;
private double baseRateOfReturn;
private double OmegaMeasure;
private double totalValue;
/**
 * @param code
 * @param quarterlyDivedend
 * @param baseRateOfReturn
 * @param omegaMeasure
 * @param totalValue
 */
public PrivateInvestment(String code, double quarterlyDivedend, double baseRateOfReturn, double omegaMeasure,
		double totalValue) {
	super();
	this.code = code;
	this.quarterlyDivedend = quarterlyDivedend;
	this.baseRateOfReturn = baseRateOfReturn;
	OmegaMeasure = omegaMeasure;
	this.totalValue = totalValue;
}
/**
 * @return the code
 */
public String getCode() {
	return code;
}
/**
 * @return the identifier
 */
public String getIdentifier() {
	return Identifier;
}
/**
 * @return the quarterlyDivedend
 */
public double getQuarterlyDivedend() {
	return quarterlyDivedend;
}
/**
 * @return the baseRateOfReturn
 */
public double getBaseRateOfReturn() {
	return baseRateOfReturn;
}
/**
 * @return the omegaMeasure
 */
public double getOmegaMeasure() {
	return OmegaMeasure;
}
/**
 * @return the totalValue
 */
public double getTotalValue() {
	return totalValue;
}
}
//code;P;label;quarterlyDividend;baseRateOfReturn;omegaMeasure;totalValue