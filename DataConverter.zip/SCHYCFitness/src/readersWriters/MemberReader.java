package readersWriters;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.*;
import containers.*;

public class MemberReader {
	
	private static ArrayList<Member> memberList= new ArrayList<Member>();
	private static void ReadMembers(){
	
	//Create an array list
	ArrayList<String> strings= new ArrayList<String>();
	String str;
	
	try { 
		
		//Open the file reader
		BufferedReader in = new BufferedReader(new FileReader("data/Members.dat"));
		in.readLine();
		
		//Read in each line of the member input file
		while((str = in.readLine()) != null){
			if (str.length()>0){
		    strings.add(str);
			}
			
			}
		
		//Close the file reader
		in.close();
		
	}
		
		catch (Exception e){ e.printStackTrace();
			System.out.println("File not found");
		}

		//Split each line into its components
		for (String s: strings){
			String data []= s.split("[;]");
			String line=data[4];
			String address []=line.split("[,]");
			
			//Call the address constructor and the member constructor
			Address a= new Address (address[0],address[1],address[2],address[4],address[3]);
				Member m = new Member (data[1],data[0],data[2],data[3], a );
				memberList.add(m);
		}
	}

	//Getter method
	public static ArrayList<Member> getMemberList() {
		ReadMembers();
		return memberList;
	}
	
}
