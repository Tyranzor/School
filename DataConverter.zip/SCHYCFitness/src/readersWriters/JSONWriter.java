package readersWriters;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import containers.*;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class JSONWriter {
	
	public<T extends Object> void JSONConverter(ArrayList<T> objects,String filename ){
		
		//Create the gson
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		
		//Create the output file
		File jsonOutput = new File(filename);
		PrintWriter jsonPrintWriter = null;
		
		try {
			 jsonPrintWriter = new PrintWriter(jsonOutput);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	
		for (Object anObject : objects) {
			
			//Use toJson method to convert Person object into a String
			String personOutput = gson.toJson(anObject);
			jsonPrintWriter.write(personOutput + "\n");
			
		}
		
		//Close the file writer
		jsonPrintWriter.close();
		
	}

}

