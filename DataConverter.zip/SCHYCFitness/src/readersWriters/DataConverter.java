package readersWriters;
import containers.*;
import java.util.*;

public class DataConverter {
	
	protected static PersonReader readP= new PersonReader();
	protected static AssetReader readA= new AssetReader();
	protected static MemberReader readM= new MemberReader();
	private static JSONWriter jWrite= new JSONWriter();
	private static XMLWriter xmlWrite= new XMLWriter();
 
	public static void main(String[] args) {
		
		//Create array lists to store all the assets, persons, and members
		ArrayList<Person> personList = new ArrayList<Person>();
		ArrayList<Member> memberList= new ArrayList<Member>();
		ArrayList<YearLongMembership> yearList= new ArrayList<YearLongMembership>();
		ArrayList<DayMembership> dayList= new ArrayList<DayMembership>();
		ArrayList<EquipmentRental> equipList= new ArrayList<EquipmentRental>();
		ArrayList<ParkingPass> parkList= new ArrayList<ParkingPass>();
		ArrayList<Asset> masterAsset= new ArrayList<Asset>();
		
		//Call the getter functions for each data type
		personList= PersonReader.getPersonList();
		memberList= readM.getMemberList();
		yearList=readA.getYearList();
		dayList= readA.getDayList();
		equipList= readA.getEquipList();
		parkList= readA.getParkList();
		
		//Build the asset array with each of its components
		for (YearLongMembership y:yearList ){
			masterAsset.add(y);
		}
		for (DayMembership y:dayList ){
			masterAsset.add(y);
		}
		for (EquipmentRental y:equipList ){
			masterAsset.add(y);
		}
		for (ParkingPass y:parkList ){
			masterAsset.add(y);
		}
		
		//Convert the array lists to JSON and XML file outputs
		jWrite.JSONConverter(masterAsset, "data/Products.json");
		jWrite.JSONConverter(memberList, "data/Members.json");
		jWrite.JSONConverter(personList, "data/Persons.json");
		xmlWrite.xmlConverter(masterAsset, "data/Products.xml");
		xmlWrite.xmlConverter(memberList, "data/Members.xml");
		xmlWrite.xmlConverter(personList, "data/Persons.xml");
		
	}

}
