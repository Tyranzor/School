package containers;

public class DayMembership extends Asset {
	
	private Address address;
	private String dateTime;
	
	//Day membership constructor
	public DayMembership(String productCode, String identifier, double cost, Address address, String dateTime) {
		super(productCode, "D", cost);
		this.address=address;
		this.dateTime=dateTime;
	}
	
	//Getter methods
	public Address getAddress() {
		return address;
	}
	
	public String getDateTime() {
		return dateTime;
	}
	
}
