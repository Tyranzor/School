package containers;

public class Member  {

	private String type;
	private String memberCode;
	private String primaryContactCode;
	private String name;
	private Address address;
	
	//Member constructor
	public Member(String type, String memberCode, String primaryContactCode, String name, Address address) {
		super();
		this.type = type;
		this.memberCode = memberCode;
		this.primaryContactCode = primaryContactCode;
		this.name = name;
		this.address = address;
	}

	//Getter methods
	public String getType() {
		return type;
	}

	public String getMemberCode() {
		return memberCode;
	}

	public String getPrimaryContactCode() {
	return primaryContactCode;
	}

	public String getName() {
	return name;
	}

	public Address getAddress() {
	return address;
	}
	
}