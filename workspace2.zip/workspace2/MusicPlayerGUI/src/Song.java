import java.io.File;
import javax.media.*;
import java.util.*;

/**
 * @author MaiPham
 * Song class has three private members: songName, singer object and player
 * This class utilizes Java Media Framework to create player for a particular song,
 * Calls play() and stop() methods to play and stop the player
 */
public class Song {
	//Create data variables 
	private String songName;
	//private Singer singer;
	private Player player;

	//Constructor
	public Song (){	 
		this.songName="";	
		this.player=null;
	}


	//Returns song name
	public String getSongName() {
		return songName;
	}

	//Assigns song name
	public void setSongName(String songName) {
		this.songName = songName;
	}


	/**
	 * @param songLocation
	 * @throws Exception
	 * This method set player for a particular song
	 * songLocation is where you store your music file, for example "Data/song.wav"
	 */
	public void setPlayer (String songLocation) throws Exception {
		File musicFile=new File(songLocation);
		this.player=Manager.createRealizedPlayer(musicFile.toURI().toURL());
	}
	
	/**
	 * This method starts the music player, print song's name, singer's name and genre to console
	 */
	public void playMusic() {
		//start music
		player.start();	

	}
	
	public void pauseMusic() {
		//start music
		player.stop();

	}


	/**
	 * This method stops the music player and sets time back to 0
	 */
	public void stopMusic(){
		//stop music
		player.stop();
		//set time back to 0, because stop() function acts like "pause" if not setting time back to 0
		player.setMediaTime(new Time(0.0));

	}


}
