/**
 * @author MaiPham
 * @version 1.0
 * This program creates a simple music player with graphic user interface GUI
 * This program helps students to get familiar with Swing components such as
 * JLabel, JComboBox, Jbutton.
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class MusicPlayerFrame extends JFrame implements ActionListener{
	// instance variables
	private static final long serialVersionUID = 1L;
	private static final int FRAME_WIDTH = 300; //Width of frame
	private static final int FRAME_HEIGHT = 300; //Height of frame
	private static final int FRAME_X_ORIGIN = 150; //X Origin of frame
	private static final int FRAME_Y_ORIGIN = 250; //Y Origin of frame
	private static final int BUTTON_WIDTH = 40;   //Pre-set width of a button
	private static final int BUTTON_HEIGHT = 40; //Pre-set height of a button
	private JButton pauseButton;//Pause Button
	private JButton playButton;//Play Button
	private JButton stopButton;//Stop Button
	private JLabel outputLine;//Label
	private String playIcon="Data/play.png";//Play Icon location
	private String pauseIcon="Data/pause.png";//Play Icon location
	private String stopIcon="Data/stop.png";//Play Icon location
	private Song song=null;
	private String songName=""; 
	JLabel playlistlabel;
	 JComboBox fuckbox;

	//Main method
	public static void main(String[] args){
		MusicPlayerFrame frame = new MusicPlayerFrame();
		frame.setVisible(true);
	}

	/**
	 * Constructor for objects of class MusicPlayerFrame
	 */
	public MusicPlayerFrame (){
		//Activity 1
		//TODO: CHANGE frame title to " <your name>'s music player" 
		
		//Set background
		JLabel background=new JLabel(new ImageIcon("Data/background.jpeg"));
		add(background);
		setSize         (FRAME_WIDTH, FRAME_HEIGHT);
		setResizable    (true);
		setTitle        ("Music player");
		setLocation     (FRAME_X_ORIGIN, FRAME_Y_ORIGIN);
		setTitle( "Mr. Awesome's music player" );
		setBackground( Color.GREEN );		
		
		
		/*  JLabel combonent
		 * 	This part uses JLabel to create text area name outputLine
		 *	This field is empty for now
		 *  Later, in event listener handling part, this text area will be implemented the way
		 *  when a button is clicked, there are different messages displayed accordingly 
		 */
		outputLine = new JLabel();
		outputLine.setBounds(40, 180, 230, 40);
		background.add(outputLine);
		
		

		//Activity 2a:
		//TODO: Imlement "Playlist" label using JLabel
	 playlistlabel= new JLabel("Playlist");
		playlistlabel.setBounds(50, 70, 80, 80);
		background.add(playlistlabel);


		//Array of songs
        String	songs[] =
        {
            "choose a song...",
            "Gentleman",
            "LittleApple",
            "TheHottestEthnicTrend"
        };
		
		//Activity 2b
		//TODO:  JComboBox
		//Implement song list using JComboBox
        fuckbox= new JComboBox(songs);
        fuckbox.setBounds (140,90, 65, 65);
        fuckbox.addActionListener(this);
        background.add(fuckbox);
        


		
		//Create image icons
		ImageIcon play= new ImageIcon(playIcon);
		ImageIcon pause= new ImageIcon(pauseIcon);
		ImageIcon stop= new ImageIcon(stopIcon);

		//Play button
		playButton = new JButton();
		playButton.setIcon(play);
		playButton.setBounds(80, 220, BUTTON_WIDTH, BUTTON_HEIGHT);
		playButton.setOpaque(false);
		playButton.setContentAreaFilled(false);
		playButton.setBorderPainted(false);
		background.add(playButton);

		//Pause button
		pauseButton = new JButton();
		pauseButton.setIcon(pause);
		pauseButton.setBounds(140, 220, BUTTON_WIDTH, BUTTON_HEIGHT);
		pauseButton.setOpaque(false);
		pauseButton.setContentAreaFilled(false);
		pauseButton.setBorderPainted(false);
		background.add(pauseButton);
	
		 //Activity 2c
		//TODO: implement stop button
		stopButton =new JButton(stopIcon);
		stopButton.setBounds(240, 220, BUTTON_WIDTH, BUTTON_HEIGHT);
		stopButton.setOpaque(false);
		stopButton.setContentAreaFilled(false);
		stopButton.setBorderPainted(false);
		stopButton.setIcon(stop);
		background.add(stopButton);

		//Activity 3 
		//TODO: ADD action listener to pause, stop buttons and playList combobox
		//playButton has been added action listener for your reference
		playButton.addActionListener(this);
		stopButton.addActionListener(this);
		pauseButton.addActionListener(this);
		//Exit program when the viewer is closed
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}


	//Activity 4:
	//TOTO: Comment actionPerformed() method, observe MusicPlayerFrame
	//class declaration and answer question on the worksheet
	
	public void actionPerformed(ActionEvent event){

		if(event.getSource() instanceof JComboBox){ 
			//Activity 5a 
			
			songName=(String) fuckbox.getSelectedItem();
			System.out.println (songName);
			//Note that String songName has been declared for you

			if(!songName.equals("choose a song...")){				
				outputLine.setText(" You have chosen " + songName);				
				song= new Song();
				try {
					song.setPlayer("media/" + songName.trim()+ ".wav");
				} catch (Exception e) {
					e.printStackTrace();
				}
			}else{
				outputLine.setText(" Please choose a song");
			}

		}else{
			outputLine.setText("Please choose a song ");
			if(songName!=""&& event.getSource() instanceof JButton){ 
				JButton clickedButton = (JButton) event.getSource();
				String icon = clickedButton.getIcon().toString();

				if(icon.equals(playIcon)){    //Play music
					song.playMusic();	
					//Activity 5b 
					outputLine.setText (""+songName+"is playing");
				}
				else if(icon.equals(pauseIcon)){    //Pause music	
					song.pauseMusic();
					//Activity 5b
					outputLine.setText (""+songName+"is paused");

				} else{		
					song.stopMusic();
					// Activity 5b
					outputLine.setText (""+songName+"is stopped");
				}
			}
			else {				
				outputLine.setText("Pick a song ");
			}//End outter if
		}//end if

	}


}





