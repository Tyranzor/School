

public class ChildCredit {

	public static void main(String args[]) {
		Child tom = new Child("Tommy", 14);
		Child dick = new Child("Richard", 12);
		Child harry = new Child("Harold", 21);
		int under=0; int amount=0,totalamount=0;
		Child arr[] = new Child[3];
		arr[0] = tom;
		arr[1] = dick;
		arr[2] = harry;
		System.out.println("Child "+ "\t\t"+ "Amount ");
for (int i=0;i<arr.length;i++){
	int age=arr[i].getAge();
	
	if (age<18){
		under+=1;
		if(under>1){
			amount=amount+1000;
			totalamount=1000;
			
			String a = arr[i].getName();
			int b = amount;
			String result = String.format("%-10s, %-5d\t", a, b);
			System.out.println(result);

		}
		if (amount>0&&under>1){
			amount=500; totalamount+=500;
			
			String a = arr[i].getName();
			int b = amount;
			String result = String.format("%-10s, %-5d\t", a, b);
			System.out.println(result);

		}
	}
	else { 
		amount=0;
		String a = arr[i].getName();
		int b = amount;
		String result = String.format("%-10s, %-5d\t", a, b);
		System.out.println(result);

	}
}

String a = "Total credit: ";
int b = totalamount;
String result = String.format("%-10s %-5d\t", a, b);
System.out.println(result);

		
		
	}
}