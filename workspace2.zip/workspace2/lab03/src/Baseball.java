

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;


public class Baseball {

	public static void main(String args[]) {
		
		String fileName = "data/mlb_nl_2011.txt";
		Scanner s = null;
		try {
			s = new Scanner(new File(fileName));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		Team teams[] = new Team[16];
String []name= new String [teams.length];
Integer [] win=new Integer [teams.length];
Integer [] loss=new Integer [teams.length];
		int k=0; int i=0;
String[] temp=new String [47];
while(s.hasNextLine()){
	
	String teaminfo=s.nextLine();
	String[] temporary = teaminfo.split(" ");
			name[i]=temporary[0];
			win[i]=Integer.parseInt(temporary[1]);
			loss[i]=Integer.parseInt(temporary[2]);
			System.out.println(name[i]);
			System.out.print(win[i]);
			System.out.print(loss[i]);
			teams[i]=new Team (name[i],win[i],loss[i]);
			i++;
	} 

	
	
		Arrays.sort(teams, new Comparator<Team>() {
			@Override
			public int compare(Team a, Team b) {
				return b.getWinPercentage().compareTo(a.getWinPercentage());
			}
			
		});
		
		System.out.println("\n\nSorted Teams: ");
		for(Team t : teams) {
			System.out.println(t);
		}
		try {PrintWriter out = new PrintWriter("data/mlb_nl_2011_results.txt");
			for (int j=0; j<teams.length;j++){
			 out.write(teams[j].getName()+ " " );
			 out.write(teams[j].getWins()+" " );
			 out.write(teams[j].getLoss()+" " );
			 out.write(" "+teams[j].getWinPercentage().doubleValue());
			 out.println();
			
			}
			 out.close();
			
		}catch (FileNotFoundException fnfe) {
			 fnfe.printStackTrace();
			}
		}
		//TODO: output the team array to a file as specified
		
	}
