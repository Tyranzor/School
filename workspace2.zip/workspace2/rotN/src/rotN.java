import java.io.*;
import java.util.*;
public class rotN {

	public static void main(String[] args) {
		int root=0;
		 try { root=Integer.parseInt(args[0]);}
		 catch (NumberFormatException e){
			 e.printStackTrace();
			 System.out.println("please enter a number");}
		 String output=new String();
	StringBuilder sb= new StringBuilder (output);
		 
char[] alphabet = new char[26]; 
for(char ch = 'a'; ch <= 'z'; ++ch)
{alphabet[ch-'a']=ch;}

int change=0;
//alphabet array to change stuff
String fileName = "data/cipher_input_002.txt";
String fileOutputName ="data/cipher_output_002.txt";
Scanner s = null;
String wholeFile= null;
try {
	wholeFile = new Scanner(new File(fileName)).useDelimiter("\\Z").next();
} catch (FileNotFoundException e) {
	e.printStackTrace();
}
char[] entirefile=wholeFile.toCharArray();

	for (int i=0; i<entirefile.length;i++){
		System.out.println(entirefile[i]);
		if (Character.isLetter(entirefile[i])){
			if (Character.isUpperCase(entirefile[i])){
				 change= Findnumber (Character.toString(entirefile[i]));
				change=change+root;
				sb.append(entirefile[change]);
				 if (change>25){
					change=change-25;
					sb.append(entirefile[change]);}
				else  {output.concat(Character.toString(Character.toUpperCase(alphabet[change])));}
			}
			else { change= Findnumber (Character.toString(entirefile[i]));
			change=change+root;
			sb.append(entirefile[change]);
			if (change>25){
				change=change-25;
				sb.append(entirefile[change]);}
			else {sb.append(entirefile[change]);}}
		}
		else	{sb.append(entirefile[i]);}
		change=0;
	}
	System.out.println(sb);
	try {PrintWriter out = new PrintWriter(fileOutputName);
	out.write(" "+sb);
	 out.close();}
		catch (FileNotFoundException fnfe) {fnfe.printStackTrace();}
		
	}
	

 public static int Findnumber (String found){
 int foundnumber=0;
 if (found.equalsIgnoreCase("a")) {foundnumber=0;}  if (found.equalsIgnoreCase("n")) {foundnumber=13;}
 if (found.equalsIgnoreCase("b")) {foundnumber=1;}  if (found.equalsIgnoreCase("o")) {foundnumber=14;}
 if (found.equalsIgnoreCase("c")) {foundnumber=2;}  if (found.equalsIgnoreCase("p")) {foundnumber=15;}
 if (found.equalsIgnoreCase("d")) {foundnumber=3;}  if (found.equalsIgnoreCase("q")) {foundnumber=16;}
 if (found.equalsIgnoreCase("e")) {foundnumber=4;}  if (found.equalsIgnoreCase("r")) {foundnumber=17;}
 if (found.equalsIgnoreCase("f")) {foundnumber=5;}  if (found.equalsIgnoreCase("s")) {foundnumber=18;}
 if (found.equalsIgnoreCase("g")) {foundnumber=6;}  if (found.equalsIgnoreCase("t")) {foundnumber=19;}
 if (found.equalsIgnoreCase("h")) {foundnumber=7;}  if (found.equalsIgnoreCase("u")) {foundnumber=20;}
 if (found.equalsIgnoreCase("i")) {foundnumber=8;}  if (found.equalsIgnoreCase("v")) {foundnumber=21;}
 if (found.equalsIgnoreCase("j")) {foundnumber=9;}  if (found.equalsIgnoreCase("w")) {foundnumber=22;}
 if (found.equalsIgnoreCase("k")) {foundnumber=10;} if (found.equalsIgnoreCase("x")) {foundnumber=23;}
 if (found.equalsIgnoreCase("l")) {foundnumber=11;} if (found.equalsIgnoreCase("y")) {foundnumber=24;}
 if (found.equalsIgnoreCase("m")) {foundnumber=12;} if (found.equalsIgnoreCase("z")) {foundnumber=25;}
 return foundnumber;

	 
 }
 
 }

	


