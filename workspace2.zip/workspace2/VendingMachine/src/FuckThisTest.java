
public class FuckThisTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean done; 
		if (done = true)
			System.out.println("the job is done");
		else 
			System.out.println("The job is not done");
	}

}
