// *************************************************************************************************************************
// Vending Machine, Author: Nathan Pittman
// this program simulates a vending machine, allowing for multiple customers each time the program runs
//*************************************************************************************************************************
import java.util.*;
import java.text.DecimalFormat ;
public class VendingMachine1 {

	public static void main(String[] args) {
		Scanner scanner; 
	int  milk=5, candy=5, soda=4, chips=6, gummybears=6,n=0, y=0;
	float milkvalue=(float) 2.00, candyvalue=(float) 1.25, sodavalue=(float) 2.25, chipvalue=(float) 1.00, 
			gummyvalue=(float) 1.50,money=(float) 0.00; 
		scanner=new Scanner (System.in);
		DecimalFormat fmt= new DecimalFormat ("0.00");
		boolean j=true;//all declerations
		
if (money==0.00) {try {	System.out.println (" Welcome to the vending machine, today we have:"+ "\r Milk \t\t\t"+fmt.format(milkvalue) 
 	+"\t\t\t" +milk +"\r Soda \t\t\t" +sodavalue +"\t\t\t" +soda 
				+"\r Candy \t\t\t"
				+ candyvalue +"\t\t\t" + candy + "\r Chips \t\t\t" + fmt.format(chipvalue)+ "\t\t\t"+ chips 
				+"\r Gummy Bears\t\t"+ 
				fmt.format(gummyvalue) +"\t\t\t" + gummybears);
		System.out.println("Please enter how much money you have");
	 money=  scanner.nextFloat();
	System.out.println("Please make a selection, 1 for Milk, 2 for Soda, 3 for Candy, 4 for Chips, 5 for Gummy Bears."
	+"\rEnter 6 if you would like to enter more money or 0 if you would like to finish and get your change, or use option 7 to get your change, or option 8 for a new"
	+ "customer");
	 y = scanner.nextInt(); 
	 }
catch (NumberFormatException e) {System.out.println("Please re-enter your choice, be sure to use digits and not words");}
catch (InputMismatchException e) {System.out.println("Please try again! Looks like something went wrong");}
catch (NoSuchElementException e) {System.out.println("Please double-check your input");}
catch (IllegalStateException e) {System.out.println("I have no idea how you managed to close the scanner, but well done");}
}// establishes first customer 



	
 try {while (j==true){
	
	switch (y) { 
	
	
	case 1: if (money<milkvalue) {System.out.println("Not enough money,Please choose option 6 and insert more money");}
    else if (milk==0) {System.out.println("Out of Milk! Please make another choice");}
	else	money=money-milkvalue; milk=Math.max(milk-1,0);  
	System.out.println ("Thank you for you purchase! This is what we have left:"
			+ "\r Milk \t\t\t"+fmt.format(milkvalue) +"\t\t\t" +milk +"\r Soda \t\t\t" +sodavalue +"\t\t\t" +soda 
			+"\r Candy \t\t\t"
			+ candyvalue +"\t\t\t" + candy + "\r Chips \t\t\t" + fmt.format(chipvalue)+ "\t\t\t"+ chips 
			+"\r Gummy Bears\t\t"+ 
			fmt.format(gummyvalue) +"\t\t\t" + gummybears);
	System.out.print("You have $"+ fmt.format(money)+" left " +"\r If you are done, use option 7 to get your change, option 8 for a new customer or option 9 to close");
	break;//purchase of milk
	
	case 2: if (money <sodavalue) {System.out.println("Not enough money,Please choose option 6 and insert more money");}
	else if (soda==0) {System.out.println("Out of Soda! Please make another choice"); }
	else	money=money-sodavalue; soda=Math.max(soda-1,0);
	System.out.println ("Thank you for your purchase! This is what we have left:"
			+ "\r Milk \t\t\t"+fmt.format(milkvalue) +"\t\t\t" +milk +"\r Soda \t\t\t" +sodavalue +"\t\t\t" +soda 
			+"\r Candy \t\t\t"
			+ candyvalue +"\t\t\t" + candy + "\r Chips \t\t\t" + fmt.format(chipvalue)+ "\t\t\t"+ chips 
			+"\r Gummy Bears\t\t"+ 
			fmt.format(gummyvalue) +"\t\t\t" + gummybears);
	System.out.print("You have $"+ fmt.format(money)+" left " +"\r If you are done, use option 7 to get your change, option 8 for a new customer or option 9 to close");
	break;//purchase of soda
	
	case 3:if (money < candyvalue) {System.out.println("Not enough money,Please choose option 6 and insert more money");}
	else if (candy==0) {System.out.println("Out of Candy! Please make another choice"); }
	else	money=money-candyvalue; candy=Math.max(candy-1,0);
	System.out.println ("This is what we have left:"
			+ "\r Milk \t\t\t"+fmt.format(milkvalue) +"\t\t\t" +milk +"\r Soda \t\t\t" +sodavalue +"\t\t\t" +soda 
			+"\r Candy \t\t\t"
			+ candyvalue +"\t\t\t" + candy + "\r Chips \t\t\t" + fmt.format(chipvalue)+ "\t\t\t"+ chips 
			+"\r Gummy Bears\t\t"+ 
			fmt.format(gummyvalue) +"\t\t\t" + gummybears);
	System.out.print("You have $"+ fmt.format(money)+" left " +"\r If you are done, use option 7 to get your change, option 8 for a new customer or option 9 to close");
	break;//purchase of candy
	
	case 4:if(money <chipvalue) {System.out.println("Not enough money,Please choose option 6 and insert more money");}
	else if (chips==0) {System.out.println("Out of Chips! Please make another choice");}  
	else	money=money-chipvalue; chips=Math.max(chips-1,0);
	System.out.println ("This is what we have left:"
			+ "\r Milk \t\t\t"+fmt.format(milkvalue) +"\t\t\t" +milk +"\r Soda \t\t\t" +sodavalue +"\t\t\t" +soda 
			+"\r Candy \t\t\t"
			+ candyvalue +"\t\t\t" + candy + "\r Chips \t\t\t" + fmt.format(chipvalue)+ "\t\t\t"+ chips 
			+"\r Gummy Bears\t\t"+ 
			fmt.format(gummyvalue) +"\t\t\t" + gummybears);
	System.out.print("You have $"+ fmt.format(money)+" left " +"\r If you are done, use option 7 to get your change, option 8 for a new customer or option 9 to close");
	break;///purchase of chips
	
	case 5:if(money <gummyvalue) {System.out.println("Not enough money,Please choose option 6 and insert more money");}
	else if (gummybears==0) {System.out.println("Out of Soda! Please make another choice");}  
	else money=money-gummyvalue; gummybears=Math.max(gummybears-1,0);
	System.out.println ("This is what we have left:"
			+ "\r Milk \t\t\t"+fmt.format(milkvalue) +"\t\t\t" +milk +"\r Soda \t\t\t" +sodavalue +"\t\t\t" +soda 
			+"\r Candy \t\t\t"
			+ candyvalue +"\t\t\t" + candy + "\r Chips \t\t\t" + fmt.format(chipvalue)+ "\t\t\t"+ chips 
			+"\r Gummy Bears\t\t"+ 
			fmt.format(gummyvalue) +"\t\t\t" + gummybears);
	System.out.print("You have $"+ fmt.format(money)+" left " +"\r If you are done, use option 7 to get your change, option 8 for a new customer or option 9 to close");
	break;///purchase of gummybears
	
	case 6: System.out.print ("Please enter the amount of money you would like to add");
	float moremoney=0;
	moremoney= scanner.nextFloat();
	money= money+moremoney;
	System.out.print("You now have $"+fmt.format(money) +"\r If you are done, use option 7 to get your change, option 8 for a new customer or option 9 to close"); 
	break;// adding more money for the current customer
	
	case 7: System.out.println("Your change is $"+fmt.format(money));
	money=(float) 0.00;
	break; // getting the change for the current customer
	
	case 8:System.out.println("Welcome new customer! Please enter your money"); 
		money=scanner.nextFloat();
	System.out.println("This is what we currently have: "+ "\r Milk \t\t\t"+fmt.format(milkvalue) +"\t\t\t" +milk 
			+"\r Soda \t\t\t" 
		+sodavalue +"\t\t\t" +soda +"\r Candy \t\t\t"
			+ candyvalue +"\t\t\t" + candy + "\r Chips \t\t\t" + fmt.format(chipvalue)+ "\t\t\t"+ chips 
			+"\r Gummy Bears\t\t"+ 
			fmt.format(gummyvalue) +"\t\t\t" + gummybears +"\r If you are done, use option 7 to get your change, option 8 for a new customer or option 9 to close");
	break; // new customer
	
	case 9:System.out.println("Thank you for using the vending machine! Your change is $" +fmt.format(money)+ "Have a great day!"); j=false;
	break; // terminates program 
	
	default: System.out.print("Invalid entry! please try again!");
	break;}
	
	if (y!=9)
	{y = scanner.nextInt();}
	else while (j==false){ scanner.close();
	System.out.println("Goodbye!");
	System.exit(n);}
	
	}} //closes try statement and while loop
	catch (NumberFormatException e) {System.out.println("Please re-enter your choice, be sure to use digits and not words");}
	catch (InputMismatchException e) {System.out.println("Please try again! Looks like something went wrong");}
	catch (NoSuchElementException e) {System.out.println("Please double-check your input");}
	catch (IllegalStateException e) {System.out.println("I have no idea how you managed to close the scanner, but well done");}

	
	System.out.println ("Goodbye!");
}}//closes class and main method

	
	
	

	
	
	
	
	
