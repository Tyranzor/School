package unl.cse.labs.lab02;

import org.joda.time.DateTime;
import org.joda.time.Interval;
import org.joda.time.Period;

public class Birthday {

	public static void main(String args[]) {
		
		String name = "Nathan Pittman";
		
		int month = 2;
		int date  = 4;
		int year  = 1994;

		DateTime bday = new DateTime(year, month, date, 0, 0);
		DateTime today = new DateTime();

		Period age = new Period(bday, today);
		
		int years = age.getYears();
		int months = age.getMonths();
		int days = age.getWeeks() * 7 + age.getDays();

		DateTime next_bday = new DateTime(year + years + 1, month, date, 0, 0);
		Interval days_to_next_bday_i = new Interval(today, next_bday);
		double days_remaining = days_to_next_bday_i.toDurationMillis() / (1000 * 60 * 60 * 24) + 1;

		//TODO: write code to output results here
		System.out.println("Greetings "+name+" Today you are "+years+" years old "+months+ " months old and "+
		days+ " days old");
		if (next_bday.isEqualNow()){
			System.out.println("Happy birthday! "+name );
		}
		else {System.out.println("Your friends have "+days_to_next_bday_i+ " to shop!");
	}
}
