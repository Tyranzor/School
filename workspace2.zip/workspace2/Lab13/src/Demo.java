import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;


public class Demo {

	public static void main(String args[]){
		
		//Activity 1
		String[] movies = getMovies(); //Call the provided helper function to load a String array of movies
		String movieTitle= ("A Beautiful Mind");
		//TODO: Write a recursive binary search method below the main method
		
		//TODO: Declare a String that holds a movie title to be searched for	
		
		//TODO: Call your binary search method to find the movie title in the movies array
		
		
		//Activity 2
		//TODO: Call the getSortedScript method to load a movie script of your choice
		String[] script = getSortedScript("data/StarWars.txt");
		//TODO: Declare a String that holds a word to be searched for and call your recursive binary search method to find it


		
		//Activity 3 + 4
		
				
	}
	
	//TODO: Put your recursive binary search methods here
	public static boolean recursiveSearch (String [] temparray, String movieTitle, int high, int low){
		int mid= ((low+high)/2);
		if (temparray [mid].equalsIgnoreCase(movieTitle)){
			return true;
		}
		else if (temparray [mid].compareToIgnoreCase(movieTitle)>0){
			high=mid;
			recursiveSearch ( temparray,  movieTitle,  high,  low);
			return false;
		}
		else {
			low=mid;
			recursiveSearch ( temparray, movieTitle,  high, low);
			return false;
		}
			
	}
	
    
    //TODO: Put your recursive and non-recursive palindrome methods here
    

	/**A method to get a String array of IMDB.com's top 250 movies, as of November 2014
     *Do not change!
	 * @return
	 */
	public static String[] getMovies(){
		ArrayList<String> words = new ArrayList<String>();
		try{
			Scanner f = new Scanner(new File("data/top250.txt"));
			while(f.hasNext()){
				String line = f.nextLine();
				words.add(line.trim());
			}
		}catch(FileNotFoundException fe){
			System.err.println("error loading the file");
		}
		String[] w = new String[words.size()];
		for(int i=0; i<words.size(); i++){
			w[i] = words.get(i);
		}
		return w;
	}
	
    
	/**A method that returns an alphabetically sorted String array of each word in the parameter file
	 * @param fileName
	 *DO not change!
     * @return
	 */
	public static String[] getSortedScript(String fileName){
		ArrayList<String> words = new ArrayList<String>();
		ArrayList<String> html = new ArrayList<String>();
		html.add("<b>"); html.add("</b>"); html.add("</b><b>"); html.add("<b></b>"); html.add("</pre>");
		try{
			Scanner f = new Scanner(new File(fileName));
			while(f.hasNext()){
				String line = f.nextLine();
				String[] arr = line.split("\\s+");
				for(int i=0; i<arr.length; i++){
					if(!arr[i].equals("") && !html.contains(arr[i]) ){
						words.add(arr[i].replaceAll("\\.","").trim());
					}
				}
			}
		}catch(FileNotFoundException fe){
			System.err.println("error loading the file");
		}
		String[] w = new String[words.size()];
		for(int i=0; i<words.size(); i++){
			w[i] = words.get(i);
		}
		Arrays.sort(w, String.CASE_INSENSITIVE_ORDER);
		return w;
	}
}
