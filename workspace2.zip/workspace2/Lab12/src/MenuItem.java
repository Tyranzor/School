public class MenuItem {
	private String name;
	private String description;
	private double price;
	
	/**Constructor that sets field variables
	 * @param name
	 * @param description
	 * @param price
	 */
	public MenuItem(String name, String description, double price) {
		this.name = name;
		this.description = description;
		this.price = price;
	}
	
	/**Returns the name of the item
	 * @return
	 */
	public String getName() {
		return name;
	}
	
	/**Returns a brief description of the item
	 * @return
	 */
	public String getDescription() {
		return description;
	}
	
	/**Returns the price of the item
	 * @return
	 */
	public double getPrice() {
		return price;
	}
	
}