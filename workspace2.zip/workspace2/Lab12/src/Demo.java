import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;


public class Demo {
	public static void main(String args[]){
		//Activity 1
		int[] a = {4, 6, 34, 65, 46, 98, 72, 9, 58, 37, 20, 61, 2};
		//TODO: Use linear search to find the number 9 in the array
		//TODO: When you find it, print "Found" and the number
		for (int i=0; i<a.length; i++)
		
		//Activity 2
		MenuItem[] menu = loadMenu(); //Call a helper function to instantiate the menu array with data from a file
		//TODO: Declare a String that holds what you want to eat, and use linear search to find it in the menu array

		//TODO: When you find it, print the name, description, and price of the item

		
		
		//Activity 3
		int[] b = {2, 4, 6, 9, 20, 34, 37, 46, 58, 61, 65, 72, 98};
		//TODO: Use binary search to find the number 9 in the array
		//TODO: When you found it, print "Found" and the number

		
		
		//Activity 4
		//TODO: Use the getScript(fileName) method to load a String array
		
		//TODO: Declare a String that holds a word to be found in the script

		long startTime = System.nanoTime();
		//TODO: Use linear search to find the word. When you find it, print "Found <word> at index <index>".

		//TODO: Use the surrounding code to time how long the search takes.
		long endTime = System.nanoTime();
		System.out.println("\tTime (Linear search): "+ (endTime-startTime) / 1000000.0 + " milliseconds");
		
		//Activity 5
		//TODO: Uncomment and complete the following line of code to sort your script array
	//	Arrays.sort( <YOUR STRING ARRAY> , String.CASE_INSENSITIVE_ORDER);
		//(TODO: Activity 6: Use the timing code to to time the sort, and print the time)
		
		startTime = System.nanoTime();
		//TODO: Use binary search to find the word in the script
		
		//TODO: Use the provided code to time how long the binary search takes
		endTime = System.nanoTime();
		System.out.println("\tTime (Binary search): " + (endTime-startTime) / 1000000.0 + " milliseconds");
		
		
		
		//Activity 7 (Bonus)
		//TODO: Uncomment and complete the following code, and complete the Activity 7 section of the worksheet
		Comparator<String> comp = new Comparator<String>(){
		@Override
		public int compare(String x, String y) {
			return x.compareToIgnoreCase(y);
		}
	};
		startTime = System.nanoTime();
		int index = Arrays.binarySearch( <YOUR ARRAY> , <YOUR KEY WORD> , comp);
		endTime = System.nanoTime();
	System.out.println("Found " + key +" at index " + index);
		System.out.println("\tTime (Built in binary search): "+ (endTime-startTime) / 1000000.0 + " milliseconds");
	}
	
	/**A method that loads the menu from the file and returns a MenuItem array
	 * @return
	 */
	public static MenuItem[] loadMenu(){
		String inFile = "data/menu.txt";
		Scanner f;
		try {
			ArrayList<MenuItem> m = new ArrayList<MenuItem>();
			f = new Scanner(new File(inFile));
			while(f.hasNext()){
				String item = f.nextLine();
				String str[] = item.split(";");
				if(str.length>2){
					MenuItem mi = new MenuItem(str[0],str[1],Double.parseDouble(str[2]));
					m.add(mi);
				}
			}
			MenuItem[] menu = new MenuItem[m.size()];
			for(int i=0; i<m.size(); i++){
				menu[i] = m.get(i);
			}
			return menu;
		} catch (FileNotFoundException e){
			System.out.println("Menu file not found.");
		}
		return null;
	}
	/**A method that returns a String array containing each word in the parameter file
	 * @param fileName
	 * @return
	 */
	public static String[] getScript(String fileName){
		ArrayList<String> words = new ArrayList<String>();
		ArrayList<String> html = new ArrayList<String>();
		html.add("<b>"); html.add("</b>"); html.add("</b><b>"); html.add("<b></b>"); html.add("</pre>"); html.add("<pre><b>"); html.add("</b></pre>");
		try{
			Scanner f = new Scanner(new File(fileName));
			while(f.hasNext()){
				String line = f.nextLine();
				String[] arr = line.split("\\s+");
				for(int i=0; i<arr.length; i++){
					if(!arr[i].equals("") && !html.contains(arr[i]) ){
						String word = arr[i].replaceAll("[^a-zA-Z']", "").trim();
						if(!word.equals("")){
							words.add(word);
						}
					}
				}
			}
		}catch(FileNotFoundException fe){
			System.err.println("error loading the file");
		}
		String[] w = new String[words.size()];
		for(int i=0; i<words.size(); i++){
			w[i] = words.get(i);
		}
		return w;
	}
}
