import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
public class Volewcount {

	public static void main(String[] args) {
		String fileName="data/paragrpah_input_001.txt";
		Scanner s =null;
		String wholefile=" ";
		try {
			s = new Scanner(new File(fileName)).useDelimiter("\\Z");
					wholefile=s.toString();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
System.out.println(wholefile);
	}

}
