/*************************************************************************
 * Item class used in all instances of VendingMachine.java
 * 
 * CSCE 155A Spring 2016
 * Assignment 4
 * @file VendingMachineDriver.java
 * @author Kyle Mahlin
 * @version 1.0
 * @date March 25, 2016
 * 
 * No changes occured during coding of homework 6, all code belongs to Kyle Mahlin
 * @date 4/20/2016
 * Used by Nathan Pittman for assignment 6
 * all code belongs to Kyle Mahlin
 *************************************************************************/
public class Item {
	
	private String description;
	private double price;
	private int quantity;
	
	public Item(String itemDesc, double itemPrice, int itemQuantity) {
		// TODO Auto-generated constructor stub
		
		this.description = itemDesc;
		this.price       = itemPrice;
		this.quantity    = itemQuantity;
		
	}
	//mutator for description
	public String getDescription() {
		return description;
	}
	//mutator for price
	public double getPrice() {
		return price;
	}
	//mutator for quantity
	public int getQuantity() {
		return quantity;
	}
	//setter for quantity
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

}


