
/**
 * @author Nathan Pittman
 *@date 4/19/2016
 *@version 1.5, because I made some changes at 1 in the morning and had to rework quite a bit of it
 *used in assignment 6, all code written by Nathan Pittman except for some measurements taken from lab 14
 *(see below)
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.border.Border;

import java.text.DecimalFormat;
public class VendingMachineGUI extends JFrame implements ActionListener {
	/**
	 * GUI implementation of vending machine program originally written by Jeremy Suing and modified by 
	 * Kyle Mahlin, all pertinent information can be found in the VendingMachineDriver, VendingMachine and 
	 * Item classes.
	 */
	//frame width/height and button width/height taken from lab 14 
	private static final long serialVersionUID = 1L;
	private static final int FRAME_WIDTH = 500; //Width of frame
	private static final int FRAME_HEIGHT = 800; //Height of frame
	private static final int FRAME_X_ORIGIN = 150; //X Origin of frame
	private static final int FRAME_Y_ORIGIN = 250; //Y Origin of frame
	private static final int BUTTON_WIDTH = 70;   //Pre-set width of a button
	private static final int BUTTON_HEIGHT = 40; //Pre-set height of a button
	private static VendingMachineGUI vendor;// Actual GUI interface
	private static JRadioButton Food;// used to select appropiate vending machine
	private static JRadioButton Drinks;// used to select appropraite vending machine
	private static VendingMachineDriver driver= new VendingMachineDriver();// driver used to set up vendingmachines
	private static JTextArea menu=new JTextArea();// the vending machine menu
	private static JButton vend;// vend button to confirm choice
	private static JButton getchange;// returns money and set Money to 0
	private static JButton addmoney;//adds money to the machines
	private static JTextField selected;// displays the text "Item selected"
	private static Vendingmachine drinks=driver.Drinkvend();// Actual vending machine which the vend methof
	//is called on
	private static Vendingmachine food= driver.Foodvend();// Same as above except for food
	private static double Money;//amount of money user has entered
	private static JTextField emergency;// displays information if vending machine is unable to function
	private static JTextArea money;//displays the amount of money the user has
	private static JButton confirmtotal;// confirms the total they entered
	private static JButton buttonA;private static JButton buttonB;private static JButton buttonC;//Buttons used to select itme
	private static JButton buttonD;private static JButton buttonE;private static JButton buttonF;//Same as above
	private static JButton button1;private static JButton button2;private static JButton button3;//Same as above
	private static JButton button4;private static JButton button5;private static JButton button6;//Same as above
	private static JTextArea entry;//displays the users entered choice
	private static String moneytoadd;// String value returned form JOptionPane when adding money
	private static JTextArea selection;// Main display for vending machine
	private static String selecteditem=("");//backup string for user selction
	private static DecimalFormat format= new DecimalFormat("0.00");//decimal format to make the Money value
	//look pretty
	private static Border border= BorderFactory.createLineBorder(Color.BLACK,1);
	//border to make text areas look pretty
	/**
	 * Initializes and sets bounds for the GUI frame, and initializes the Money value to 0
	 * @author Nathan Pittman
	 * @date 4/20/2016
	 * @version 1.0
	 * @param args
	 */
	public static void main(String[] args){
 vendor= new VendingMachineGUI();
vendor.setVisible(true);
vendor.setBounds(FRAME_X_ORIGIN, FRAME_Y_ORIGIN, FRAME_WIDTH, FRAME_HEIGHT);
vendor.setResizable(false);
vendor.setDefaultCloseOperation(EXIT_ON_CLOSE);
vendor.getContentPane();
Money=0.00;
	}
// end GUI constructor for the vending machines.
	/**
	 * @author Nathan Pittman
	 * @date 4/25/2016
	 * @version 2.0
	 * Creates, sets up and adds all components to the GUI frame created by main method
	 */
public VendingMachineGUI (){
	JLabel background=new JLabel();
	add(background);
	setSize         (FRAME_WIDTH, FRAME_HEIGHT);
	setResizable    (true);
	setTitle        ("Vending Machine 3");
	setLocation     (FRAME_X_ORIGIN, FRAME_Y_ORIGIN);
	setTitle( "Vending Machines" );
	//above creates the background to which everything is added which is added to the GUI frame
	 Food=new JRadioButton();
	 Drinks = new JRadioButton();
	ButtonGroup vendgroup= new ButtonGroup();
	vendgroup.add (Food);
	vendgroup.add(Drinks);
	Food.addActionListener(this);
	Drinks.addActionListener(this);
	background.add(Food);
	background.add(Drinks);
	Food.setText("Food");
	Drinks.setText("Drinks");
	Food.setBounds(160, 5, BUTTON_WIDTH, BUTTON_HEIGHT);
	Drinks.setBounds(230, 5, BUTTON_WIDTH, BUTTON_HEIGHT);
	Food.setVisible(true);
	Drinks.setVisible(true);
	//radiogroup buttons for selecting machine
	background.setVisible(true);
	 selection=new JTextArea ("Please make a selection");
	selection.setBounds(20, 50, 500, 20);
	emergency=new JTextField();emergency.setBounds(20, 50,500, 20);background.add(emergency);emergency.setVisible(true);emergency.setText("Please choose a vending machine and enter money"); emergency.setEditable(false);
	background.add(selection); selection.setEditable(false); selection.setVisible(false); selection.setBorder(border);
	//Sets up main and emergency displays to display machine info to the user
	buttonA=new JButton ("A"); background.add(buttonA); buttonA.setBounds(20, 100, BUTTON_WIDTH, BUTTON_HEIGHT);buttonA.setVisible(true);buttonA.addActionListener(this);
	buttonB=new JButton ("B"); background.add(buttonB); buttonB.setBounds(20, 150, BUTTON_WIDTH, BUTTON_HEIGHT);buttonB.setVisible(true);buttonB.addActionListener(this);
	buttonC=new JButton ("C"); background.add(buttonC); buttonC.setBounds(20, 200, BUTTON_WIDTH, BUTTON_HEIGHT);buttonC.setVisible(true);buttonC.addActionListener(this);
	buttonD=new JButton ("D"); background.add(buttonD);buttonD.setBounds(20, 250, BUTTON_WIDTH, BUTTON_HEIGHT);buttonD.setVisible(true);buttonD.addActionListener(this);
	buttonE=new JButton ("E"); background.add(buttonE);buttonE.setBounds(20, 300, BUTTON_WIDTH, BUTTON_HEIGHT);buttonE.setVisible(true);buttonE.addActionListener(this);
	buttonF=new JButton ("F"); background.add(buttonF);buttonF.setBounds(20, 350, BUTTON_WIDTH, BUTTON_HEIGHT);buttonF.setVisible(true);buttonF.addActionListener(this);
	button1=new JButton ("1"); background.add(button1); button1.setBounds(100, 100, BUTTON_WIDTH, BUTTON_HEIGHT);button1.setVisible(true);button1.addActionListener(this);
	button2=new JButton ("2"); background.add(button2); button2.setBounds(100, 150, BUTTON_WIDTH, BUTTON_HEIGHT);button2.setVisible(true);button2.addActionListener(this);
	button3=new JButton ("3"); background.add(button3); button3.setBounds(100, 200, BUTTON_WIDTH, BUTTON_HEIGHT);button3.setVisible(true);button3.addActionListener(this);
	button4=new JButton ("4"); background.add(button4);button4.setBounds(100, 250, BUTTON_WIDTH, BUTTON_HEIGHT);button4.setVisible(true);button4.addActionListener(this);
	button5=new JButton ("5"); background.add(button5);button5.setBounds(100, 300, BUTTON_WIDTH, BUTTON_HEIGHT);button5.setVisible(true);button5.addActionListener(this);
	button6=new JButton ("6"); background.add(button6);button6.setBounds(100, 350, BUTTON_WIDTH, BUTTON_HEIGHT);button6.setVisible(true);button6.addActionListener(this);
	//sets up and adds all the selection buttons
    money=new JTextArea();
	money.setText("Current money "+Money); money.setVisible(true); background.add(money); money.setEditable(false);
	money.setBounds(20, 400, 150, BUTTON_HEIGHT);money.setBorder(border);
	//sets up money TextArea for displaying current money
	menu.setBounds(250, 80, 200, 560);menu.setVisible(true); background.add(menu); menu.setEditable(false); menu.setBorder(border);
	//sets up menu JTextArea which is populated once a machine is selected
	vend= new JButton ("Vend!"); vend.setBounds(300, 690, BUTTON_WIDTH, BUTTON_HEIGHT); vend.setVisible(true);vend.addActionListener(this); background.add(vend);
	getchange=new JButton ("Get change");getchange.setVisible(true); getchange.setBounds(20, 500, 150, BUTTON_HEIGHT);getchange.addActionListener(this);background.add(getchange);
	addmoney=new JButton ("Add money");addmoney.setBounds(20, 450, 150, BUTTON_HEIGHT);addmoney.setVisible(true);background.add(addmoney);addmoney.addActionListener(this);
	confirmtotal=new JButton ("Confirm total"); confirmtotal.setBounds(20, 450, 150, BUTTON_HEIGHT);confirmtotal.setVisible(false);background.add(confirmtotal); confirmtotal.addActionListener(this); confirmtotal.setEnabled(false);
	//sets up all non selection buttons
	this.selected=new JTextField("Item selected:");this.selected.setBounds(250, 640, 90, BUTTON_HEIGHT);this.selected.setVisible(true);background.add(this.selected);this.selected.setEditable(false);
	entry=new JTextArea(); entry.setBounds(340, 640, 50, BUTTON_HEIGHT); entry.setEditable(false);entry.setVisible(true);background.add(entry); entry.setBorder(border);
	//sets up text areas used to improve look of GUI
}// end of GUI creator
/**
 * @author Nathan Pittman
 * @date 4/25/2016
 * @version 1.55 
 * Event listeners for all actions fired from the GUI frame
 */
public void actionPerformed(ActionEvent event) {
	double add = 0;// throwaway variable used to maintain money if the JOptionPane from addmoney
	//throws an exception
	/*
	 * keeps track of the length of the entry box, and disables the selction buttons once the user
	 * selects two variables, the codeconverter method handles any situations where the user enters two
	 * letters or two numbers
	 */
	if (entry.getText().length()==1||entry.getText().length()>1){selection.setVisible(true);
	buttonA.setEnabled(false);buttonB.setEnabled(false);buttonC.setEnabled(false);buttonD.setEnabled(false);buttonE.setEnabled(false);buttonF.setEnabled(false);button1.setEnabled(false);
	button2.setEnabled(false);button3.setEnabled(false);button4.setEnabled(false);button5.setEnabled(false);
	button6.setEnabled(false);}
	else{selection.setVisible(true);buttonA.setEnabled(true);buttonB.setEnabled(true);buttonC.setEnabled(true);
	buttonD.setEnabled(true);buttonE.setEnabled(true);buttonF.setEnabled(true);button1.setEnabled(true);
	button2.setEnabled(true);button3.setEnabled(true);button4.setEnabled(true);button5.setEnabled(true);
	button6.setEnabled(true);}
	if (event.getSource()instanceof JRadioButton){
		if (Money==0){ emergency.setVisible(true);selection.setVisible(false);
			emergency.setText("Please enter some money!");
		} else { emergency.setVisible(false);}
	 if (Food.isSelected()){
		 menu.setText(food.printMenu()); 
	 }
	 else {menu.setText(drinks.printMenu());}}
	/*
	 * the below event listener is activated when the user wishes to add more money, it does not actually
	 * proceed with the addition of the money, the confirmtotal event handles that, this listener
	 * just preps the machine and brings up a JOptionPane to prompt the user for the amount they wish to 
	 * add, it also catches a nullpointer exception if the user cancels or closes the JOptionPane
	 * or doesnt enter anything.
	 */
	  if (event.getSource()==addmoney&&!money.isEditable()){emergency.setVisible(true);selection.setVisible(false);
		money.setText(""); 
		emergency.setText("Please enter the amount of money to add.");
		emergency.setBounds(20, 50, 500, 20);
			 money.setEditable(true);
			 addmoney.setVisible(false);addmoney.setEnabled(false);
			 confirmtotal.setEnabled(true);confirmtotal.setVisible(true);
	try{ moneytoadd=JOptionPane.showInputDialog(null,"Please enter the amount of money to add.");}
	catch (NullPointerException e){emergency.setVisible(true);selection.setVisible(false);
		emergency.setText("Please re-enter your money, something went wrong");
	addmoney.setEnabled(true);addmoney.setVisible(true);
	confirmtotal.setEnabled(false);confirmtotal.setVisible(false);}
	  money.setText(moneytoadd);}
	  /*
	   * The listener below activates when the user has entered an amount of money they wish to add
	   * it also catches any exceptions thrown form attempting parse a non integer
	   */
		if(money.isEditable()&&event.getSource()==confirmtotal){ selection.setVisible(true);
		money.setEditable(false); add=Money; selection.setText("Thank you for depositing additional money");
		try { add=Double.parseDouble(moneytoadd);}
		catch (NullPointerException e){emergency.setVisible(true);selection.setVisible(false);
			emergency.setText("Please re-enter your money, something went wrong");
		addmoney.setEnabled(true);addmoney.setVisible(true);
		confirmtotal.setEnabled(false);confirmtotal.setVisible(false);}
		catch (NumberFormatException e){emergency.setVisible(true);
			emergency.setText("Please enter numerals");addmoney.setEnabled(true);addmoney.setVisible(true);
		confirmtotal.setEnabled(false);confirmtotal.setVisible(false);}
		addMoney (add);
		money.setText("You have "+format.format(Money)+ " to spend" );
		addmoney.setEnabled(true);addmoney.setVisible(true);
		confirmtotal.setEnabled(false);confirmtotal.setVisible(false);
		emergency.setVisible(false);}
		/*
		 * All event listeners below are used to display the user's choice and create a backup string
		 * in case of error
		 */
		if (event.getSource()==buttonA&&!money.isEditable()){entry.append("A");selecteditem.concat("A");}
		if (event.getSource()==buttonB&&!money.isEditable()){entry.append("B");selecteditem.concat("B");}
		if (event.getSource()==buttonC&&!money.isEditable()){entry.append("C");selecteditem.concat("C");}
		if (event.getSource()==buttonD&&!money.isEditable()){entry.append("D");selecteditem.concat("D");}
		if (event.getSource()==buttonE&&!money.isEditable()){entry.append("E");selecteditem.concat("E");}
		if (event.getSource()==buttonF&&!money.isEditable()){entry.append("F");selecteditem.concat("F");}
		if (event.getSource()==button1&&!money.isEditable()){entry.append("1");selecteditem.concat("1");}
		if (event.getSource()==button2&&!money.isEditable()){entry.append("2");selecteditem.concat("2");}
		if (event.getSource()==button3&&!money.isEditable()){entry.append("3");selecteditem.concat("3");}
		if (event.getSource()==button4&&!money.isEditable()){entry.append("4");selecteditem.concat("4");}
		if (event.getSource()==button5&&!money.isEditable()){entry.append("5");selecteditem.concat("5");}
		if (event.getSource()==button6&&!money.isEditable()){entry.append("6");selecteditem.concat("6");}
		/*
		 * the following is used to vend the appropriate item, it can also check to make sure the
		 * user has entered money and has selected one of the vending machines to use
		 */
		if (event.getSource()==vend){
			if (!Food.isSelected()&&!Drinks.isSelected()){emergency.setVisible(true);selection.setVisible(false);
				emergency.setText("Choose either the food or drink machine to proceed!");
			}//the above checks to make sure that one of the vending machines has been chosen
			if (Food.isSelected()){selection.setVisible(true);
				selecteditem=entry.getText();
				System.out.println (selecteditem);
				int choice=codeConverter(selecteditem);
					if (choice==99){emergency.setVisible(false); selection.setVisible(true);
						selection.setText("Invalid entry, please try again");}
					else{emergency.setVisible(false); selection.setVisible(true);
				String output=food.vend(Money, choice);//actual method call to vend the chosen item
				selection.setText(output);
				setMoney (food.getMoney());
				money.setText("You have "+format.format(Money)+ " to spend" );
				menu.setText(food.printMenu());}
			}// the above makes the appropriate method calls to vend items from the food vending machine
			// it also checks for an appropriate selection
			
			if (Drinks.isSelected()){selection.setVisible(true);
				selecteditem=entry.getText();
				System.out.println(selecteditem);
				int choice=codeConverter(selecteditem);
				if (choice==99){emergency.setVisible(false); selection.setVisible(true);
					selection.setText("Invalid entry, please try again");}
				else {emergency.setVisible(false); selection.setVisible(true);
					String output=drinks.vend(Money, choice);// actual method call to vend the chosen item
					selection.setText(output);
					setMoney(drinks.getMoney());
					money.setText("You have "+format.format(Money)+ " to spend" );
					menu.setText(drinks.printMenu());}
			}//the above performs the exact same action as the food event listener except it functions 
			//for the drink vending machine.
			
			entry.setText("");buttonA.setEnabled(true);buttonB.setEnabled(true);buttonC.setEnabled(true);
			buttonD.setEnabled(true);buttonE.setEnabled(true);buttonF.setEnabled(true);button1.setEnabled(true);
			button2.setEnabled(true);button3.setEnabled(true);button4.setEnabled(true);button5.setEnabled(true);
			button6.setEnabled(true);
			selecteditem=("");}
		if (event.getSource()==getchange){
			selection.setText("Your change is "+format.format(Money));
			selection.setVisible(true);emergency.setVisible(false);
			setMoney (0);
			money.setText("You have "+format.format(Money)+ " to spend" );
		}
		
		}//end of action performed method
	
		 
	 
	
/**
 * Used to reset money value when the get change button is pressed
 * @param money almost always 0.
 */

public void setMoney (double money){
	Money=money;
}//end setMoney
/**
 * 
 * @returns the value of money, used to pass the money value to the vendingmachine and 
 * vendingmachinedriver classes
 */
public double getMoney (){
	return Money;
}//end getMoney
/**
 * 
 * @param code is letter numeral combination taken from the GUI
 * @return chosen is the true array value of the selected item
 * @author Nathan Pittman
 * @date 4/24/2016
 */
public int codeConverter (String code){
	int chosen=99;
	if (code.contains("A1")){chosen=0;}
	if (code.contains("A2")){chosen=1;}
	if (code.contains("A3")){chosen=2;}
	if (code.contains("A4")){chosen=3;}
	if (code.contains("A5")){chosen=4;}
	if (code.contains("A6")){chosen=5;}
	if (code.contains("B1")){chosen=6;}
	if (code.contains("B2")){chosen=7;}
	if (code.contains("B3")){chosen=8;}
	if (code.contains("B4")){chosen=9;}
	if (code.contains("B5")){chosen=10;}
	if (code.contains("B6")){chosen=11;}
	if (code.contains("C1")){chosen=12;}
	if (code.contains("C2")){chosen=13;}
	if (code.contains("C3")){chosen=14;}
	if (code.contains("C4")){chosen=15;}
	if (code.contains("C5")){chosen=16;}
	if (code.contains("C6")){chosen=17;}
	if (code.contains("D1")){chosen=18;}
	if (code.contains("D2")){chosen=19;}
	if (code.contains("D3")){chosen=20;}
	if (code.contains("D4")){chosen=21;}
	if (code.contains("D5")){chosen=22;}
	if (code.contains("D6")){chosen=23;}
	if (code.contains("E1")){chosen=24;}
	if (code.contains("E2")){chosen=25;}
	if (code.contains("E3")){chosen=26;}
	if (code.contains("E4")){chosen=27;}
	if (code.contains("E5")){chosen=28;}
	if (code.contains("E6")){chosen=29;}
	if (code.contains("F1")){chosen=30;}
	if (code.contains("F2")){chosen=31;}
	if (code.contains("F3")){chosen=32;}
	if (code.contains("F4")){chosen=33;}
	if (code.contains("F5")){chosen=99;}
	if (code.contains("F6")){chosen=99;}
	
	return chosen;
	
}//end codeConverter
/**
 * called by the add money button to add additional money to the machines
 * @param money amount of money enter into the JOptionPane
 */
public void addMoney (double money){
	Money+=money;
}//end addMoney
	
}//end VendingMachineGUI class

