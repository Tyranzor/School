import java.io.FileNotFoundException;
import java.text.DecimalFormat;
import java.util.Scanner;

/*************************************************************************
 * Driver class to test multiple instances of VendingMachine.java
 * 
 * CSCE 155A Spring 2016
 * Assignment 4
 * @file VendingMachineDriver.java
 * @author Kyle Mahlin
 * @version 1.0
 * @date March 25, 2016
 * 
 * @version2.0,edits implemented by Nathan Pittman
 * @date 4/20/2016
 * used by Nathan Pittman for assignment 6
 *************************************************************************/


class VendingMachineDriver {
	/**
	 * Called to create a food vending machine
	 * @returns the snack vending machine
	 * @author Nathan Pittman, modified from original code belonging to Kyle Mahlin
	 */
	public static Vendingmachine Foodvend() {
		
		//declaring objects and initializing to null
		Vendingmachine snackVend = null;
		//linking machine to proper file
		try {
			snackVend = new Vendingmachine("snacks.txt");
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.out.println("Something went wrong with the file. Please ensure the file is correct.");
		}
		
		return snackVend;
	}//end snackVend method
	/**
	 * Called to create a drinks vending machine
	 * @returns the drinks vending machine
	 * @author Nathan Pittman, modified from original code belonging to Kyle Mahlin
	 */
public static Vendingmachine Drinkvend() {
		
		//declaring objects and initializing to null
		Scanner input = new Scanner(System.in);
		String userInput = null;
		Vendingmachine drinkVend = null;
		Vendingmachine snackVend = null;
		
		//total money both vending machines have earned
		double totalMoney = 0.0;
		
		//initializing vending machine objects with the proper text files
		try {
			drinkVend = new Vendingmachine("drinks.txt");
			snackVend = new Vendingmachine("snacks.txt");
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.out.println("Something went wrong with the file. Please ensure the file is correct.");
		}
		return drinkVend;
	}//end drinkVend method
}// end vending machine driver class
		
	

