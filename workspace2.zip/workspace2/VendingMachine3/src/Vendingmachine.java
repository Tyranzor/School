import java.io.*;
import java.text.DecimalFormat;
import java.util.Scanner;

/*************************************************************************
 * Simulates a real life vending machine with stock read from a file.
 * 
 * CSCE 155A Spring 2016
 * Assignment 4
 * @file VendingMachine.java
 * @author Jeremy Suing
 * @version 1.0
 * @date March 7, 2016
 * 
 * @Updated By Kyle Mahlin
 * @version 1.1
 * @date March 25, 2016
 * 
 * @Updated by Nathan Pittman
 * @version 1.15
 * @date 4/20/2016
 * Used by Nathan Pittman in assignment 6
 *************************************************************************/
public class Vendingmachine {

	//data members
	private Item[]  stock;     //Array of Item objects in machine
	/**
	 * used to return the price of an item to the vending machine GUI
	 * @param choice int value of choice of item in stock array
	 * @returns the price of the item
	 * @author Nathan Pittman, modified form original code belonging to Kyle Mahlin
	 */
	public double getStock(int choice) {
		return stock[choice].getPrice();
	}//end getStock

	

	private double  balance;   //Amount of money in the user's balance
	private int     selection; //Item user selects
	private boolean exit;	   //exits sentinel for vending machine
	
	// formatting for decimals printout
	DecimalFormat percentF  = new DecimalFormat("#0.00");
	
	/*********************************************************************
	 * This is the constructor of the VendingMachine class that take a
	 * file name for the items to be loaded into the vending machine.
	 *
	 * It creates objects of the Item class from the information in the 
	 * file to populate into the stock of the vending machine.  It does
	 * this by looping the file to determine the number of items and then
	 * reading the items and populating the array of stock. 
	 * 
	 * @param filename Name of the file containing the items to stock into
	 * this instance of the vending machine. 
	 * @throws FileNotFoundException If issues reading the file.
	 *********************************************************************/
	public Vendingmachine(String filename) throws FileNotFoundException{
		//Open the file to read with the scanner
		File    file = new File(filename);
		Scanner scan = new Scanner(file);

		//Determine the total number of items listed in the file
		int totalItem = 0;
		while (scan.hasNextLine()){
			scan.nextLine();
			totalItem++;
		} //End while another item in file
		//Create the array of stock with the appropriate number of items
		stock = new Item[totalItem];
		scan.close();

		//Open the file again with a new scanner to read the items
		scan = new Scanner(file);
		int    itemQuantity = -1;
		double itemPrice    = -1;
		String itemDesc     = "";
		int    count        = 0;
		String line         = "";

		//Read through the items in the file to get their information
		//Create the item objects and put them into the array of stock
		while(scan.hasNextLine()){
			line = scan.nextLine();
			String[] tokens = line.split(",");
			try {
				itemDesc     = tokens[0];
				itemPrice    = Double.parseDouble(tokens[1]);
				itemQuantity = Integer.parseInt(tokens[2]);

				stock[count] = new Item(itemDesc, itemPrice, itemQuantity);
				count++;
			} catch (NumberFormatException nfe) {
				System.out.println("Bad item in file " + filename + 
						" on row " + (count+1) + ".");
			}
		} //End while another item in file
		scan.close();

		//Initialize data variables.
		
		balance   = 0.0;
		selection = 0;
		exit	  = false;

	} //End VendingMachine constructor
	/**
	 * 
	 * @param money from vendig machine GUI that user has passed in
	 * @param selected int value belonging to chosen item in array, passed in from the result of the 
	 * codeConverter method
	 * @returns a string based on if all parameters are met to purchase item or not
	 * @author Nathan Pittma, modified heavily from original code belonging to Kyle Mahlin
	 * @date 4/20/2016
	 */
	public String vend(double money,int selected){
		selection=selected;
		SetterMoney(money);
		String item=outputMessage (selected);
			return item;
		}
		
	// end vend method
	/**
	 * original code belongs to Kyle Mahlin
	 * @param input the array value to be vended
	 * @return string varies depending on if vend was successful or not.
	 * I don't know why Kyle did the vast majority of work in here instead of Vend method, but it works
	 * -Nathan Pittman
	 */
	public String  outputMessage(int input){

		if(balance < stock[selection].getPrice()){
			// checks if user has enough money
			// keeps them in until they add more money or exit
			String s=("You do not have enough money. Please add more money or exit.");
			
	return s;
			
		}
		else if(stock[selection].getQuantity() == 0){
			// if an item is not in stock asks the user to select again
			// if the user exits they exit the vending machine
			String s= ("Sorry, we are out of this item.");
		return s;
			
		}
		else{
		// take money from user 
		// take quantity from vending machine
		balance -= stock[selection].getPrice();
		
		//update the quantity by decrementing it by 1
		int updatedQuant = stock[selection].getQuantity() - 1;
		stock[selection].setQuantity(updatedQuant);
		
		String s= ("You have bought "+stock[selection].getDescription()+" for $"
			+percentF.format(stock[selection].getPrice())
			+". Your change is $"+percentF.format(roundValue(balance))+".");	
		 return s;
		}
	}//end outputMessage method
	// prints the vending machine menu from stock array
	/**
	 * Code not modified by Nathan Pittman
	 * all code below belongs to Kyle Mahlin
	 * @returns the menu of the appropiate vending machine
	 */
	public String printMenu(){
		String format = "%-6s %-9s %-9s %-6s \n";

		
		System.out.println("\n");
		System.out.println("Menu:");
		String s= ("Vending machine menu");
		System.out.printf(format,"Item#","Item","Price","Qty");
		 for(int i = 0; i < stock.length; i++){
			s=(s+ "\n"+ stock[i].getDescription()+" "+
					percentF.format(stock[i].getPrice())+" "+stock[i].getQuantity());
			
		}
		return s;
	}//end printMenu method
	
	
	/**
	 * Very minor edits implemented by Nathan Pittman
	 * original code belongs to Kyle Mahlin
	 * @param choice int value of selected item in stock array
	 */
	// ask the user to select item, if the user inputs an invalid 
	// or empty item then the method is called again
	public void setUserSelection( int choice){
		int tempSelection = choice;
		boolean sentinal  = false;


		// Contain the user until they enter a valid value
		while (!sentinal){
			System.out.println("Please make a selection (enter 0 to exit): ");
			
			
			if (tempSelection > 0 && tempSelection <= stock.length){
				selection = tempSelection;
				sentinal  = true;
			}
			else{
				setUserSelection(choice);
				
				// stops the recursion from running the loop again
				// once a user sets a valid value
				sentinal  = true;
			}
		}//end while

	}//end setUserSelection method
	/**
	 * @author Nathan Pittman
	 * completely got rid of old setMoney method written by Kyle Mahlin
	 * @param money what balance value is to be set to
	 */
	public void SetterMoney (double money) {
	
	 balance=money;
	}
	/**
	 * not modified by Nathan Pittman, all code belongs to Kyle Mahlin
	 * @returns value of balance
	 */
	//getter method for money
	public double getMoney(){
		return balance;
	}
	/**
	 * not modified by Nathan Pittman, all code belongs to Kyle Mahlin
	 * @returns value of balance rounded appropriately
	 */
	//helper method for rounding double value
	private double roundValue(double value){
		return ((double)Math.round(value*100)/100);
	}
	/**
	 * @author Nathan Pittman
	 * @param money balance left in machine after vending item
	 * @returns value of balance and set balance to 0
	 */
	public double getChange (double money) {
		double tempbalance=balance;
		balance=0.00;
		return tempbalance;
		
		
	}
	
} //End VendingMachine class definition

