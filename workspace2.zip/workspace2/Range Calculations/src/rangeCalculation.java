import java.lang.*;
import java.text.DecimalFormat;

public class rangeCalculation {

	public static void main(String[] args) {
	double range;
	double angle=Double.parseDouble(args[1]);
	double radian;
	double velocity = Double.parseDouble(args[0]); 
	double [] allangles= new double [(int) angle];
	DecimalFormat df=new DecimalFormat("0.00");
	for (int i=0; i<(int) angle; i++){
		allangles[i]=i+1;
	}
	double [] radianmeasurement= new double [(int) angle];
	for (int j=0; j<radianmeasurement.length;j++){
		radianmeasurement[j]=Math.toRadians(allangles[j]);
	}
	System.out.println("Angle in degrees\t Range ");
	System.out.println("--------------------------------");
	for (int k=0;k<radianmeasurement.length;k++){
		range=((-2.0*(velocity*velocity))/-9.81)*Math.sin(radianmeasurement[k])*Math.cos(radianmeasurement[k]);
		System.out.println((k+1)+"\t\t\t"+df.format(range));
	}
	}

}
