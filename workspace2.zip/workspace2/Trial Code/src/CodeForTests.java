import java.util.InputMismatchException;
import java.util.NoSuchElementException;

import javax.swing.*; 
public class CodeForTests {

	public static void main(String[] args) {
	
		

	}

}
