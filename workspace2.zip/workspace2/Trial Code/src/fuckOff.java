
public class fuckOff {

	public static void main(String[] args) {
		int sum =0;
		int n = 10;
		for ( int i=0; i<n; i++){
			for (int j =i; j<2*n; j++){
				for (int k=j; k<j*4; k++){
					sum++;
				}
			}
		}
				
System.out.println(sum);
	}

}
