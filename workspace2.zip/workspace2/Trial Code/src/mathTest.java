
public class mathTest {

}
