
public class TrialCode {

	public static void main(String[] args) {
System.out.println("Hello World");
System.out.println("What is your name?");

	}
/** TrialCode.java 
 * this is just a comment to practice 
 */
}
