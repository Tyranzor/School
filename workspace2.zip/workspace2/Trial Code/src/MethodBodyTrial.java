
public class MethodBodyTrial {

	public static void main(String[] args) {
	double x,y,r; 
	x= 450;
	y=600 ;
	r = (x*100)/y;
	System.out.print ("Your score is "+ r);

	}

}
