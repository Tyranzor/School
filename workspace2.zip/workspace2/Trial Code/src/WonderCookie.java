import java.util.*;
public class WonderCookie {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double A,B,C,D = 0;
Scanner scanner;
System.out.println("Please enter the number of hours worked");
scanner= new Scanner (System.in);
A = scanner.nextDouble ();
if (A<=40) D=A*8.25;
else D=((A-40)*12.375)+(40*8.25);
System.out.println ("Total wage is before sales is "+ D);

System.out.println ("Please enter total sales");
B = scanner.nextDouble ();

if (B<=299){B=B*.05;
C= B+A;
System.out.println ("total wage is "+C);
}else if (B>299&&A<=40){ B=B*.10;
System.out.println(""+B);
C= B+D;
System.out.println("Your total pay is "+C);
}else B= (B*.08);
C=B+D;
System.out.println("Your total pay is "+C);
scanner.close();


	}

}
