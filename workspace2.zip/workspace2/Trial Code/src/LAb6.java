import java.util.Scanner; 
public class LAb6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s=("gcgtcattacttatgaaaacaacacttgggtaaatcagacatatgttaacatcagcaacaccaactttgctgctggacagtcagtggtttccgtgaaattagcgggcaattcctctctctgccctgttagtggatgggctatatacagtaaagacaacagtgtaagaatcggttccaagggggatgtgtttgtcataagggaaccattcatatcatgctcccccttggaatgcagaaccttcttcttgactcaaggggccttgctaaatgacaaacattccaatggaaccattaaagacaggagcccatatcgaaccctaatgagctgtcctattggtgaagttccctctccatacaactcaagatttgagtcagtcgcttggtcagcaagtgcttgtcatgatggcatcaattggctaacaattggaatttctggcccagacaatggggcagtggctgtgttaaagtacaacggcataataacagacactatcaagagttggagaaacaatatattgagaacacaagagtctgaatgtgcatgtgtaaatggttcttgctttactgtaatgaccgatggaccaagtaatggacaggcctcatacaagatcttcagaatagaaaagggaaagatagtcaaatcagtcgaaatgaatgcccctaattatcactatgaggaatgctcctgttatcctgattctggtgaaatcacatgtgtgtgcagggataactggcatggctcgaatcgaccgtgggtgtctttcaaccagaatctggaatatcagataggatacatatgcagtgggattttcggagacaatccacgccctaatgacaagacaggcagttgtggtccagtatcgtctaatggagcaaatggagtaaaaggattttcattcaaatacggcaatggtgtttggatagggagaactaaaagcattagttcaagaaacggttttgagatgatttgggatccgaacggatggactgggacagacaataacttctcaataaagcaagatatcgtaggaataaatgagtggtcaggatatagcgggagttttgttcagcatccagaactaacagggctggattgtataagaccttgcttctgggttgaactaatcagagggcgacccaaagagaacacaatctggactagcgggagcagcatatccttttgtggtgtaaacagtgacactgtgggttggtcttggccagacggtgctgagt");
		int x=0, j=0, n=0;
		Scanner scanner=new Scanner (System.in) ;
	System.out.println ("Please enter the substring you would like to search for, please note it can not be longer"
			+"than the original string");
	String y= scanner.nextLine();
	System.out.println("The substring " +y+ "is seperated by the following code fragments " );
	while (s.indexOf(y)!=-1){ if (s.indexOf(y)!=-1){
		x=s.indexOf (y)+1;
		s=s.replaceFirst(y, " ");
		j=s.indexOf(y)-1;
	
		if (j>s.length()){
		String q= s.substring(x, j);
		System.out.println(q);
		}
		
	}
	
	else if (s.indexOf(y)==-1){
			break;}
		}
	System.out.println("and");
	if (s.indexOf (y)==-1){ 
		System.out.println("Goodbye");
		scanner.close();
		System.exit (n);
	}
		}

	}
	




