import java.util.*;
public class ArrayLab {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int y=0, h=0, x=0;
int [] input = new int[100];

Scanner scanner= new Scanner (System.in);

 String s=("Please enter an interger, or -1 to calculate.");
 System.out.println(""+ s);
 y =scanner.nextInt();
 
 do { System.out.println (""+s);

 
 for (int i=0; i<=100; i++) {
	 input [i]= y;
	 h++;
	 x++;
	
	 
 }
 y=scanner.nextInt();

	}
 while (y!=-1);
 int q;
 q= input[0];

 do {
	for (int u=1; u<input.length;u++){
		 
	 

	q=q+ input [u];
	h--;}}
 while (h>0);

System.out.println  ("The sum of the array is " + q + " the average of the array is "+ (q/x));
}}