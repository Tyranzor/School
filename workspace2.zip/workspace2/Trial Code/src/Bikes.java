import java.util.*;
public class Bikes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
double bike,day,deposit,cost;
Scanner scanner;
scanner= new Scanner(System.in);
System.out.println("Please enter bike type, 1=Regular Bike, 2=Mountain Bike, 3= Tandem Bike");
bike= scanner.nextDouble();
System.out.println("Please enter number of days rented");
day = scanner.nextDouble ();
if (bike==1){;
cost = (day*10)+50;
System.out.println ("The total cost of your bike is"+cost);
}else if (bike==2){;
cost = (day*12.50)+60.00;
System.out.println ("The total cost of your bike is"+cost);
}else cost= (day*15.00)+75.00;
System.out.println ("The total cost of your bike is"+cost);


	}

}
