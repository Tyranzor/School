import java.lang.Math ;
import java.util.* ; 
public class Sphere {

	public static void main(String[] args) {
		Scanner scanner; 
		double R,volume1  ;
		System.out.println ("Please input the radius of the sphere");
		scanner = new Scanner ( System.in) ;
		R = scanner.nextDouble () ; 
		volume1 = Math.pow(R, 3)* Math.PI*((double)4/(double) 3);
		System.out.println ("The volume of your sphere is " + volume1);
		scanner.close();
		
		

	}

}
