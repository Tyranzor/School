import javax.swing.JOptionPane;
public class Randomcode {

	public static void main(String[] args) {
		System.out.println("Fuck this boring class");
		String s =("This is Java refresher practice");
		s=JOptionPane.showInputDialog(null, "Java is hard when you havent coded all summer");
		// TODO Auto-generated method stub
if (JOptionPane.CLOSED_OPTION==0){
	System.exit(0);
}
else if (JOptionPane.CANCEL_OPTION==0){
	System.exit(0);
}

	
else  if (s.equalsIgnoreCase("No")&&JOptionPane.OK_OPTION==0){

	JOptionPane.showConfirmDialog(null, "Fuck you too!");
	
if (JOptionPane.CLOSED_OPTION==0){
	System.exit(0);
}
else if (JOptionPane.CANCEL_OPTION==0){
	System.exit(0);
}
else if (JOptionPane.OK_CANCEL_OPTION==0){
	System.exit(0);
}
}

	}

}
