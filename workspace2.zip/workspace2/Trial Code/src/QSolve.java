// 
import java.util.*; 
import java.lang.Math ;
public class QSolve {


	public static void main(String[] args) {
	Scanner scanner ;
 double A,B,C, root1, root2  ;
 scanner = new Scanner (System.in); 
System.out.println(" Please input first variable: A");
A = scanner.nextDouble (); 
System.out.println("Please inpit second variable: B");
B = scanner.nextDouble(); 
System.out.println (" Please input third variable: C");
C = scanner.nextDouble() ; 
root1 = (-B+ Math.sqrt(Math.pow(B, 2)-4*A*C ))/(2*A) ;
root2 = (-B- Math.sqrt(Math.pow(B, 2)-4*A*C ))/(2*A) ;
System.out.println("The first root of your quadratic equation is "+ root1);
System.out.println("The second root of your quadratic equation is "+ root2);
scanner.close();
assert (root1>0);
	}

}
