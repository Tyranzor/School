package lab8;

public class TestFactorial {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

    	//Activity 1
    	//TODO: finish worksheet Activity 1 based on the following codes.
        int y = 1;

        for (int x = 1; x <= 10; x++) {
            y *= x;
        }

        System.out.println("The value of 10! is: "+y);


    }
}
