package lab8;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.util.InputMismatchException;


public class TestException {
	
	public static void main(String args[]) {
		
		Scanner s = new Scanner(System.in);	
		
		//Activity 2
		//TODO: uncommend and run the code and answer Activity 2 question 1 on the worksheet
		int arr[] = {3, 45, 21, 97, 4, 12};
		for(int i=0; i<=arr.length; i++){
			System.out.println(arr[i]);
		}

		System.out.print("Please enter the file name: ");
		String fileName = s.next();
		//TODO: uncomment the next line, answer Activity 2 question 2 on the worksheet, and then fix the for-loop
		try {
			Scanner inFile = new Scanner(new File(fileName));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//TODO: Select the "surround with try/catch" fix for the previous line, answer question 4, and
		//		modify and test the catch block as directed by the Activity 2 section of the handout

	}

}
