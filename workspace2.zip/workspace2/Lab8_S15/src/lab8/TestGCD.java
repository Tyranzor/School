package lab8;

public class TestGCD {

public static void main(String[] args){
  
//Bonus Activity
	//TODO: Finish the worksheet Activity 3 based on the following codes. 
 int r=0;
 int n = 20;
 int initialN = n;
 int m = 44;
 int initialM = m;

 r=n%m;
  while(r!=0){
	  	n=m;
		m=r;
		r=n%m;
	  }
	  
	  System.out.println("GCD of "+initialN+" and "+initialM+ " is: " + m);

	}


}
