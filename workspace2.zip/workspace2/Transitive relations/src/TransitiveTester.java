/**
 * 
 */

/**
 * @author Nathan
 *
 */
import java.util.*;
public class TransitiveTester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Please input your three points one digit at a time");
		int a = sc.nextInt();
		int b= sc.nextInt();
		int c= sc.nextInt();
		int d= sc.nextInt();
		int e = sc.nextInt();
		int f = sc.nextInt();
		int count =0;
		if (b==c){
			if (a==e&&d==f){
				count++;
			}
		}
		if (b==e){
			if (a==c&&f==d){
				count++;
			}
		}
		if ()
	}

}
