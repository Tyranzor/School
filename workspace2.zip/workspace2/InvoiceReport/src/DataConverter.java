
import java.util.List;




public class DataConverter {

	public static void main(String[] args) {

		Reader fr = new Reader();

		
		List<containers.Person> personList = fr.readPersons();
		List<containers.Customer> customerList = fr.readCustomers();
		List<containers.Product> productList = fr.readProducts();
		List<containers.Invoice> invoiceList = fr.readInvoices(customerList, productList);
		
		JsonWriter jWriterperson = new JsonWriter();
		jWriterperson.jsonConverterperson(personList);
		
	
		XMLWriter xmlWriterperson = new XMLWriter();
		xmlWriterperson.xmlConverterperson(personList);

		JsonWriter jWritercustomer = new JsonWriter();
		jWritercustomer.jsonConvertercustomer(customerList);

		XMLWriter xmlWritercustomer = new XMLWriter();
		xmlWritercustomer.xmlConvertercustomer(customerList);

		JsonWriter jWriterproduct = new JsonWriter();
		jWriterproduct.jsonConverterproduct(productList);

		XMLWriter xmlWriterproduct = new XMLWriter();
		xmlWriterproduct.xmlConverterproduct(productList);	
				
		System.out.println("Executive Summary Report");
		System.out.println("==========================");
		System.out.format("Invoice	   Customer		          Salesperson     Subtotal    Fees	Taxes	    Discount	Total%n");
		for(int i =0; i < invoiceList.size(); i++){
		int j = 0;	
		System.out.format("%-10s %-30s %-15s %-11.2f %-10d %f%n", invoiceList.get(i).getInvoiceCode(), customerList.get(i).getName(),invoiceList.get(i).getSalesperson(),invoiceList.get(i).getPrice(),j,invoiceList.get(i).getTaxes());
				
				
	}
		
}
}
