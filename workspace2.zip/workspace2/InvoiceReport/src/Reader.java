import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import containers.Address;
import containers.Customer;
import containers.Invoice;
import containers.Person;
import containers.Product;
import containers.Movieticket;
import containers.Refreshment;
import containers.Seasonpass;
import containers.Parkingpass;

public class Reader {

	public ArrayList<Person> readPersons() {
		Scanner sc = null;		
		try {
			sc = new Scanner(new File("Persons.dat"));
			sc.nextLine(); 
			
			ArrayList<Person> personList = new ArrayList<Person>();
			while (sc.hasNext()) {
				ArrayList<String> emaillist = new ArrayList<String>();
				String line = sc.nextLine();		
				String data[] = line.split("[;,]"); 
													
				String personCode = data[0];
				String lastName = data[1];
				String firstName = data[2];
				String street = data[3];
				String city = data[4];
				String state = data[5];
				String zip = data[6];
				String country = data[7];
				if(data.length > 7){				
				for(int i = 8; i < data.length; i++){
				String emailaddress = data[i];
				emaillist.add(emailaddress);										
				}
				Address address = new Address(street, city, state, zip, country);
				Person person;
				
				if(emaillist.isEmpty()){
					 person = new Person(personCode, lastName, firstName, address);
				}
				else{
						 person = new Person(personCode, lastName, firstName, address, emaillist);
				}
				personList.add(person);
				}			
			}
			sc.close();
			return personList;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return null;
		}		
	}
	public ArrayList<Customer> readCustomers() {
		Scanner sc = null;
		try {
			sc = new Scanner(new File("Customers.dat"));
			sc.nextLine(); 
			ArrayList<Customer> customerList = new ArrayList<Customer>();

			while (sc.hasNext()) {
				String line = sc.nextLine(); 
				String data[] = line.split("[;,]"); 
													
				String customerCode = data[0];
				String type = data[1];
				String primaryContact = data[2];
				String name = data[3];
				String street = data[4];
				String city = data[5];
				String state = data[6];
				String zip = data[7];
				String country = data[8];

				Address address = new Address(street, city, state, zip, country);
				Customer customer = new Customer(customerCode, type, primaryContact, name, address);
				customerList.add(customer);
			}
			sc.close();
			return customerList;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return null;
		}
	}
	public ArrayList<Product> readProducts() {
		Scanner sc = null;

		try {
			sc = new Scanner(new File("Products.dat"));
			sc.nextLine(); 
			ArrayList<Product> productList = new ArrayList<Product>();

			while (sc.hasNext()) {
				String line = sc.nextLine(); 
												
				String data[] = line.split("[;,]"); 
				String productCode = data[0];
				String productType = data[1];
			
				if (data[1].equals("M") ) {
					
					String dateTime = data[2];
					String movieName = data[3];
					String street = data[4];
					String city = data[5];
					String state = data[6];
					String zip = data[7];
					String country = data[8];
					String screenNo = data[9];
					String pricePerUnit = data[10];
					
					Address address = new Address(street, city, state, zip, country);
					Movieticket movieticket = new Movieticket(productCode, productType, dateTime, movieName, address,
							screenNo, pricePerUnit);
					productList.add(movieticket);
				} else if (data[1].equals("R")) {
					String name = data[2];
					String cost = data[3];
					Refreshment refreshment = new Refreshment(productCode, productType, name, cost);
					productList.add(refreshment);
				}

				else if (data[1].equals("S")) {
					String name = data[2];
					String startDate = data[3];
					String endDate = data[4];
					String cost = data[5];
					Seasonpass seasonpass = new Seasonpass(productCode, productType, name, startDate, endDate, cost);
					productList.add(seasonpass);
				}

				else if (data[1].equals("P")) {

					String parkingFee = data[2];
					Parkingpass parkingpass = new Parkingpass(productCode, productType, parkingFee);
					productList.add(parkingpass);
				}				
			}
			sc.close();
			return productList;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return null;
		}
	}
	public ArrayList<Invoice> readInvoices(List<containers.Customer> customerList,List<containers.Product> productList) {
		Scanner sc = null;		
		try {
			sc = new Scanner(new File("Invoices.dat"));
			sc.nextLine(); 
			
			ArrayList<Invoice> invoiceList = new ArrayList<Invoice>();
			while (sc.hasNext()) {
				ArrayList<Product> products = new ArrayList<Product>();
				String line = sc.nextLine(); 
				String data[] = line.split("[;,]"); 
				String invoiceCode = data[0];
				String customerCode = data[1];
				Customer customer = null; 
				for(int i = 0; i < customerList.size(); i++){
					if(customerCode.equals (customerList.get(i).getCustomerCode())){
						customer = customerList.get(i);
					}
				}		
				String[] quantity = new String[data.length];
				String salespersonCode = data[2];
				//Person person = null;
			/*	for(int i = 0; i < personList.size(); i++){
					if(salespersonCode.equals (personList.get(i).getpersonCode())){
						person = personList.get(i);
					}
				}		*/
				String invoiceDate = data[3];
				if(data.length > 3){		
				for(int i = 4; i < data.length; i++){					
				String product = data[i];
				String pinfo[] = product.split(":");
				quantity[i-4] = pinfo[1];
				for(int j = 0; j < productList.size(); j++){
					if(pinfo[0].equals(productList.get(j).getProductCode())){
						products.add(productList.get(j));	
					}						
				}	
				}			
				Invoice invoice;
				invoice = new Invoice(invoiceCode, customer, salespersonCode, invoiceDate, products, quantity);
				invoiceList.add(invoice);
				}
			}
			sc.close();
			return invoiceList;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return null;
		}
	}	
}
