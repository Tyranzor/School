package com.ceg.ext;
import java.util.Comparator;
/**
 * 
 * @author Nathan Pittman
 * With assistance from Jeremy Thorne
 * @version 1
 * Overrides Comparator for use with InvoiceList class
 *
 */

	public class ComparatorTotal implements Comparator<Invoice> {
		@Override
		public int compare(Invoice i1, Invoice i2) {
			if (i1==null){
				return 1 ;
			}
			if (i2 == null)
				return -1;
			else if(i1.getTotal() == i2.getTotal())
				return 0;
			else if (i1.getTotal() > i2.getTotal())
				return 1;
			else if (i2.getTotal()>i1.getTotal()){
				return -1;}
			return 0;
		}
	}

