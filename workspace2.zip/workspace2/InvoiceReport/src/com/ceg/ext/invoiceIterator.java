package com.ceg.ext;

import java.util.Iterator;

public class invoiceIterator implements Iterator<Invoice> {
InvoiceNode current;
public invoiceIterator (InvoiceNode node){
this.current=node;
}
	@Override
	public boolean hasNext() {
		if (current.getNext()==null){
			
		
		return false;
	}
		else { return true;}
			
	}

	@Override
	public Invoice next() {
		Invoice returnvalue=current.getInvoice();
		current=current.getNext();
		return returnvalue;
	}

}