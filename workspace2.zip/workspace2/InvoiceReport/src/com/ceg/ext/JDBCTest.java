package com.ceg.ext;

public class JDBCTest {

	@SuppressWarnings("static-access")
	public static void main(String[] args) {
		InvoiceData id= new InvoiceData();
	id.removeAllInvoices();
	}

}
