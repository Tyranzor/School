package containers;

import java.util.ArrayList;

public class Person {

	private String firstName;
	private String lastName;
	private String street;
	private String city;
	private String state;
	private String country;
	private double zip;
	private String personCode;
	private ArrayList<String> emaillist;
	
	/**
	 * @param firstName
	 * @param lastName
	 * @param street
	 * @param city
	 * @param state
	 * @param country
	 * @param zip
	 * @param personCode
	 * @param emaillist
	 */
	public Person(String firstName, String lastName, String street, String city, String state, String country,
			double zip, String personCode, ArrayList<String> emaillist) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.street = street;
		this.city = city;
		this.state = state;
		this.country = country;
		this.zip = zip;
		this.personCode = personCode;
		this.emaillist = emaillist;
	}
	
	
	/**
	 * @param firstName
	 * @param lastName
	 * @param street
	 * @param city
	 * @param state
	 * @param country
	 * @param zip
	 * @param personCode
	 */
	public Person(String firstName, String lastName, String street, String city, String state, String country,
			double zip, String personCode) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.street = street;
		this.city = city;
		this.state = state;
		this.country = country;
		this.zip = zip;
		this.personCode = personCode;
	}


	// Getter and Setter methods
	public String getAddress(){
		return this.street+","+this.city+","+this.state+","+this.zip+","+this.country;
		
	}
	
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPersoncode() {
		return personCode;
	}

	public void setPersonCode(String personCode) {
		this.personCode = personCode;
	}

	public ArrayList<String> getEmaillist() {
		return emaillist;
	}

	public void setEmaillist(ArrayList<String> emaillist) {
		this.emaillist = emaillist;
	}
}
