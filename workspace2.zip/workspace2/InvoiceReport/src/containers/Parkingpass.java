package containers;

public class Parkingpass extends Product {

	private String productCode;
	private String productType;
	private String parkingFee;

	public Parkingpass(String productCode, String productType, String parkingFee) {
		super();
		this.productCode = productCode;
		this.productType = productType;
		this.parkingFee = parkingFee;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getParkingFee() {
		return parkingFee;
	}

	public void setParkingFee(String parkingFee) {
		this.parkingFee = parkingFee;
	}

	public double getPrice() {
		double total = Double.valueOf(parkingFee);
		return total;
	}
	
	public double getTaxes() {
		double tax = Double.valueOf(parkingFee);
		tax = tax * .04;
		return tax;
	}

	

}
