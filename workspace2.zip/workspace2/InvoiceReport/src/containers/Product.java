package containers;

abstract public class Product {

	abstract public double getTaxes();
abstract public double getPrice();
public abstract String getProductCode();
}
