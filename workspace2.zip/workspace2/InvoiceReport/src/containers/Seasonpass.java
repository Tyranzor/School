package containers;

public class Seasonpass extends Product {

	private String productCode;
	private String productType;
	private String name;
	private String startDate;
	private String endDate;
	private String cost;

	public Seasonpass(String productCode, String productType, String name, String startDate, String endDate,
			String cost) {
		super();
		this.productCode = productCode;
		this.productType = productType;
		this.name = name;
		this.startDate = startDate;
		this.endDate = endDate;
		this.cost = cost;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getCost() {
		return cost;
	}

	public void setCost(String cost) {
		this.cost = cost;
	}

	public double getPrice() {
		double total = Double.valueOf(cost);
		total = total + 8;
		return total;
	}
		
	public double getTaxes() {
		double tax = Double.valueOf(cost);
		tax = tax + 8;
		tax = tax * .04;
		return tax;
	}




	
	
}
