package containers;

import java.util.ArrayList;
import containers.Product;

public class Invoice {
	
private String invoiceCode;
private String date;
private Customer customer;
private String salesperson;
private ArrayList<Product> product;
private String[] quantity;
// Constructor
public Invoice(String invoiceCode, Customer customer, String salesperson, String date, ArrayList<Product> product, String[] quantity) {
	super();
	this.invoiceCode = invoiceCode;
	this.date = date;
	this.customer = customer;
	this.salesperson = salesperson;
	this.product = product;
	this.quantity = quantity;
}




// Getter & Setter methods
public String getInvoiceCode() {
	return invoiceCode;
}

public void setInvoiceCode(String invoiceCode) {
	this.invoiceCode = invoiceCode;
}

public String getDate() {
	return this.date;
}

public void setDate(String date) {
    this.date = date;
}
public Customer getCustomer() {
	return this.customer;
}
public void setCustomerCode(Customer customer) {
	this.customer = customer;
}

public String getSalesperson() {
	return this.salesperson;
}

public void setSalesperson(String salesperson) {
    this.salesperson = salesperson;
}

public ArrayList<Product> getProduct() {
	return product;
}

public void setProduct(ArrayList<Product> product) {
	this.product = product;
}

public String[] getQuantity() {
	return quantity;
}

public void setQuantity(String[] quantity) {
	this.quantity = quantity;
}



public double getPrice() {
	double totalPrice = 0; 
	double finalPrice = 0;
	for(int i = 0; i < product.size(); i++){
		double total = Double.valueOf(quantity[i]);
		totalPrice = total * product.get(i).getPrice();
		finalPrice = finalPrice + totalPrice;
}
	return finalPrice;	
}


public double getTaxes() {
	
	double totalTax = 0;
	double finalTax = 0;
	if(customer.getType().equals("S")){
		finalTax = 0;	
	}	
	else	{
		for(int i = 0; i < product.size(); i++){
			double total = Double.valueOf(quantity[i]);
			totalTax = total * product.get(i).getTaxes();
			finalTax = finalTax + totalTax;
	}  	
	}
	return finalTax;	
}
}


