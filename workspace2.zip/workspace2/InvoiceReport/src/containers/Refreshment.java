package containers;

public class Refreshment extends Product {

	private String productCode;
	private String productType;
	private String name;
	private String cost;

	public Refreshment(String productCode, String productType, String name, String cost) {
		super();
		this.productCode = productCode;
		this.productType = productType;
		this.name = name;
		this.cost = cost;
		
	}

	
	
	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCost() {
		return cost;
	}

	public void setCost(String cost) {
		this.cost = cost;
	}

	public double getPrice() {	
		double total = Double.valueOf(cost);
		return total;
		
	}
	public double getTaxes() {
		double tax = Double.parseDouble(cost);
		tax = tax * .04;
		return tax;
	}



	

}
