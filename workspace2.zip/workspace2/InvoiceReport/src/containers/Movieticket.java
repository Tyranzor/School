package containers;

public class Movieticket extends Product {

	private String productCode;
	private String productType;
	private String dateTime;
	private String movieName;
	private Address address;
	private String screenNo;
	private String pricePerUnit;

	public Movieticket(String productCode, String productType, String dateTime, String movieName, Address address,
			String screenNo, String pricePerUnit) {
		super();
		this.productCode = productCode;
		this.productType = productType;
		this.dateTime = dateTime;
		this.movieName = movieName;
		this.address = address;
		this.screenNo = screenNo;
		this.pricePerUnit = pricePerUnit;
		
	}

	
	public Address getAddress() {
		return this.address;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getDateTime() {
		return dateTime;
	}

	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public String getScreenNo() {
		return screenNo;
	}

	public void setScreenNo(String screenNo) {
		this.screenNo = screenNo;
	}

	public String getPricePerUnit() {
		return pricePerUnit;
	}

	public void setPricePerUnit(String pricePerUnit) {
		this.pricePerUnit = pricePerUnit;
	}

	
	public double getPrice() {
		double total = Double.valueOf(pricePerUnit);	
		return total;
	}
	
	@Override
	public double getTaxes() {
		double tax = Double.valueOf(pricePerUnit);
		tax = tax * .06;
		System.out.println(tax);
		return tax;
	}


}
