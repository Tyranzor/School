import java.util.*;
public class WeatherDataObject {
private int high;
private int low;
private String location;
private int wind;
private int gusts;
private double precip;
private GregorianCalendar date;

public int getHigh() {
	return high;
}
public void setHigh(int high) {
	this.high = high;
}
public int getLow() {
	return low;
}
public void setLow(int low) {
	this.low = low;
}
public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}
public int getWind() {
	return wind;
}
public void setWind(int wind) {
	this.wind = wind;
}
public int getGusts() {
	return gusts;
}
public void setGusts(int gusts) {
	this.gusts = gusts;
}
public double getPrecip() {
	return precip;
}
public void setPrecip(double precip) {
	this.precip = precip;
}
public GregorianCalendar getDate() {
	return date;
}
public void setDate(GregorianCalendar date) {
	this.date = date;
}

}

