import java.util.*;
class WeatherProcessingSystem {
public static void main(String[] args) {
	Scanner scan= new Scanner (System.in);
	final String [] LOCATION_NAME= { "Eagle, NE", "New York", "Houston, TX", "LA, CA"};
	final int [] DAYS_IN_MONTH={31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}; 
	int index=0;
	int choice=9;
	WeatherDataLoad weatherdata= new WeatherDataLoad();
	
	
			WeatherDataObject [] [] [] WeatherData= new WeatherDataObject [4][12][31];
				for (int location=0; location<4; location++) 
					{GregorianCalendar date=new GregorianCalendar (2008, 0, 1);
					for ( int month=0; month<WeatherData[location].length; month++) {
						for (int day=0; day<DAYS_IN_MONTH[month];day++){
								WeatherData [location][month][day]= new WeatherDataObject();
								WeatherData [location][month][day].setLocation(LOCATION_NAME [location]);
								WeatherData [location][month][day].setDate((GregorianCalendar)date.clone());
								WeatherData [location][month][day].setHigh(weatherdata.getHIGHS(index));
								WeatherData [location][month][day].setLow(weatherdata.getLOWS(index));
								WeatherData [location][month][day].setGusts(weatherdata.getGUSTS(index));
								WeatherData [location][month][day].setWind(weatherdata.getWIND(index));
								WeatherData [location][month][day].setPrecip(weatherdata.getPRECIP(index));
								index++;
								date.add (Calendar.DAY_OF_MONTH,1);
						}							
					}
	}
System.out.println("Welcome to the weather data processer! \n Please make a choice, \n 1.) Weather Record \n 2.)Averages"+
	"\n 3.) Maximums \n 4.) Minimums \n 5.)Total Precipitation \n 6.) Extremems \n 0.) to quit."	);
choice= scan.nextInt();

while (choice==1) {System.out.println("Please enter a date to view mm/dd/yyyy,or 0 to quit. ");
String inputdate=null; String[] newdate=null;
	do{ inputdate = scan.next();
	newdate= inputdate.split ("/");}
	while (inputdate.equals(null));
	 if (inputdate.length()==1){System.out.println("Welcome to the weather data processer! \n Please make a choice, \n 1.) Weather Record \n 2.)Averages"+
				"\n 3.) Maximums \n 4.) Minimums \n 5.)Total Precipitation \n 6.) Extremems \n 0.) to quit."	);
	 choice= scan.nextInt();
	 break;}
	 else for (int i=0; i<4; i++){
		for (int j=0; j<12; j++){
			for (int k=0; k<DAYS_IN_MONTH [j]; k++){				
				String comparisondate=WeatherData [i][j][k].getDate().toString();
				if (comparisondate.contains(newdate[0])&&comparisondate.contains (newdate[1])){
					for (int q=0;q<1; q++){
					System.out.println(WeatherData[i][j][k].getLocation());
					System.out.println(WeatherData[i][j][k].getHigh());
					System.out.println(WeatherData[i][j][k].getLow());
					System.out.println(WeatherData[i][j][k].getGusts());
					System.out.println(WeatherData[i][j][k].getWind());
					System.out.println(WeatherData[i][j][k].getPrecip());}
					break;
				}
			}
		}
	}
	System.out.println("Please enter a date to view mm/dd/yyyy,or 0 to quit. ");
	 inputdate= scan.nextLine();
	
	}
	while (choice==2){System.out.println("Please choose a data value 1.) for Highs. 2.) for Lows. 3.) for Wind. 4.) for gusts. 5.) for Precip. 0.) to go back.  ");
	int locations=scan.nextInt();
	switch (locations){
	case 1:{ for (int local=0; local<4; local++){
		if (local==0){System.out.println("The average high for each month in Eagle, NE is:");}
		if (local==1){System.out.println ("The average high for each month in New York NY is: ");}
		if (local==2) {System.out.println ("The average high for each month in Houston, TX is:");}
		if (local==3) {System.out.println("The average high for each month in LA, CA is:" );}
					for (int month=0; month<12; month++){
						for (int day=0; day< DAYS_IN_MONTH[month]; day++){
							System.out.print("The average high for month " +(month+1) );
							double totalhigh=0;
							totalhigh= totalhigh+ WeatherData [local][month][day].getHigh();
							System.out.println(" is "+(totalhigh/DAYS_IN_MONTH [month]));
							}
					}
	}
	break;}
	case 2: {for (int local=0; local<4; local++){
		if (local==0){System.out.println("The average low for each month in Eagle, NE is:");}
		if (local==1){System.out.println ("The average low for each month in New York NY is: ");}
		if (local==2) {System.out.println ("The average low for each month in Houston, TX is:");}
		if (local==3) {System.out.println("The average low for each month in LA, CA is:" );}
					for (int month=0; month<12; month++){
						System.out.println("The average low for month " +(month+1));
						for (int day=0; day< DAYS_IN_MONTH[month]; day++){
							double totalhigh=0;
							totalhigh= totalhigh+ WeatherData [local][month][day].getLow();
							System.out.println(" is "+(totalhigh/DAYS_IN_MONTH [month]));
							}
					}
	}
	break;}
	case 3:{for (int local=0; local<4; local++){
		if (local==0){System.out.println("The average windspeed for each month in Eagle, NE is:");}
		if (local==1){System.out.println ("The average windspeed for each month in New York NY is: ");}
		if (local==2) {System.out.println ("The average windspeed for each month in Houston, TX is:");}
		if (local==3) {System.out.println("The average windspeed for each month in LA, CA is:" );}
					for (int month=0; month<12; month++){
						System.out.print("The average windspeed for month " +(month+1));
						for (int day=0; day< DAYS_IN_MONTH [month]; day++){
							double totalhigh=0; 
							totalhigh= totalhigh+ WeatherData [local][month][day].getWind();
							System.out.println(" is "+(totalhigh/DAYS_IN_MONTH [month]));
							}
					}
	}
	break;}
	case 4:{for (int local=0; local<4; local++){
		if (local==0){System.out.println("The average gust for each month in Eagle, NE is:");}
		if (local==1){System.out.println ("The average gust for each month in New York NY is: ");}
		if (local==2) {System.out.println ("The average gust for each month in Houston, TX is:");}
		if (local==3) {System.out.println("The average gust for each month in LA, CA is:" );}
					for (int month=0; month<12; month++){
						System.out.print("The average gust for month " +(month+1));
						for (int day=0; day< DAYS_IN_MONTH [month]; day++){
							double totalhigh=0;
							totalhigh= totalhigh+ WeatherData [local][month][day].getGusts();
							System.out.println(" is "+(totalhigh/DAYS_IN_MONTH [month]));
							}
					}
	}
	break;}
	case 5:{for (int local=0; local<4; local++){
	
		if (local==0){System.out.println("The average precipitation for each month in Eagle, NE is:");}
		if (local==1){System.out.println ("The average precipitation for each month in New York NY is: ");}
		if (local==2) {System.out.println ("The average precipitation for each month in Houston, TX is:");}
		if (local==3) {System.out.println("The average precipitation for each month in LA, CA is:" );}
					for (int month=0; month<12; month++){
						System.out.print("The average precipitation for month " +(month+1));
						for (int day=0; day< DAYS_IN_MONTH [month]; day++){
							double totalhigh=0;
							totalhigh= totalhigh+ WeatherData [local][month][day].getPrecip();
							System.out.println(" is "+(totalhigh/DAYS_IN_MONTH [month]));
							}
					}
	}
	break;}
	case 0:{   System.out.println("Welcome to the weather data processer! \n Please make a choice, \n 1.) Weather Record \n 2.)Averages"+
			"\n 3.) Maximums \n 4.) Minimums \n 5.)Total Precipitation \n 6.) Extremems \n 0.) to quit."	);
	choice= scan.nextInt();
	break;}
	default: {System.out.println("Invalid entry! Please try again!Please choose a data value 1.) for Highs. 2.) for Lows. 3.) for Wind. 4.) for gusts. 5.) for Precip. 0.) to go back.  ");
	choice=scan.nextInt();
	break;}
	}
	}
	
	
	int value=0;
while (choice==3) { System.out.println("Please choose a data value 1.) for Highs. 2.) for Lows. 3.) for Wind. 4.) for gusts. 5.) for Precip. 0.) to go back.  "); 
value=scan.nextInt();
switch (value){
case 1: {for (int local=0; local<4; local++){
	if (local==0){System.out.println("The maximum high for each month in Eagle, NE is:");}
	if (local==1){System.out.println ("The maximum high for each month in New York NY is: ");}
	if (local==2) {System.out.println ("The maximum high for each month in Houston, TX is:");}
	if (local==3) {System.out.println("The maximum high for each month in LA, CA is:" );}
				for (int month=0; month<12; month++){
					System.out.print("The maximum high for month " +(month+1));
					for (int day=0; day< DAYS_IN_MONTH [month]; day++){
						int max=0;
						if (WeatherData [local][month][day].getHigh()>max)
							max= WeatherData [local][month][day].getHigh();
						System.out.println(" is "+max);}
						
}
}
break;}
case 2: {for (int local=0; local<4; local++){
	if (local==0){System.out.println("The maximum low for each month in Eagle, NE is:");}
	if (local==1){System.out.println ("The maximum low for each month in New York NY is: ");}
	if (local==2) {System.out.println ("The maximum low for each month in Houston, TX is:");}
	if (local==3) {System.out.println("The maximum low for each month in LA, CA is:" );}
				for (int month=0; month<12; month++){
					System.out.print("The maximum low for month " +(month+1));
					for (int day=0; day< DAYS_IN_MONTH [month]; day++){
						int max=0;
						if (WeatherData [local][month][day].getLow()>max)
							max= WeatherData [local][month][day].getLow();
						System.out.println(" is "+max);}
						
}
}
break;}
case 3: {for (int local=0; local<4; local++){
	if (local==0){System.out.println("The maximum windspeed for each month in Eagle, NE is:");}
	if (local==1){System.out.println ("The maximum windspeed for each month in New York NY is: ");}
	if (local==2) {System.out.println ("The maximum windspeed for each month in Houston, TX is:");}
	if (local==3) {System.out.println("The maximum windspeed for each month in LA, CA is:" );}
				for (int month=0; month<12; month++){
					System.out.print("The maximum windspeed for month " +(month+1));
					for (int day=0; day< DAYS_IN_MONTH [month]; day++){
						int max=0;
						if (WeatherData [local][month][day].getWind()>max)
							max= WeatherData [local][month][day].getWind();
						System.out.println(" is "+max);}
						
}
}
break;}
case 4:{for (int local=0; local<4; local++){
		if (local==0){System.out.println("The maximum gust for each month in Eagle, NE is:");}
		if (local==1){System.out.println ("The maximum gust for each month in New York NY is: ");}
		if (local==2) {System.out.println ("The maximum gust for each month in Houston, TX is:");}
		if (local==3) {System.out.println("The maximum gust for each month in LA, CA is:" );}
					for (int month=0; month<12; month++){
						System.out.print("The maximum gust for month " +(month+1));
						for (int day=0; day< DAYS_IN_MONTH [month]; day++){
							int max=0;
							if (WeatherData [local][month][day].getHigh()>max)
								max= WeatherData [local][month][day].getGusts();
							System.out.println(" is "+max);}
					}
	}
break;}
case 5: {for (int local=0; local<4; local++){
	if (local==0){System.out.println("The maximum precipitation for each month in Eagle, NE is:");}
	if (local==1){System.out.println ("The maximum precipitation for each month in New York NY is: ");}
	if (local==2) {System.out.println ("The maximum precipitation for each month in Houston, TX is:");}
	if (local==3) {System.out.println("The maximum precipitation for each month in LA, CA is:" );}
				for (int month=0; month<12; month++){
					System.out.print("The maximum precipitation for month " +(month+1));
					for (int day=0; day< DAYS_IN_MONTH [month]; day++){
						double max=0;
						if (WeatherData [local][month][day].getHigh()>max)
							max= WeatherData [local][month][day].getPrecip();
						System.out.println(" is "+max);}
				}
}
break;}
case 0: {   System.out.println("Welcome to the weather data processer! \n Please make a choice, \n 1.) Weather Record \n 2.)Averages"+
		"\n 3.) Maximums \n 4.) Minimums \n 5.)Total Precipitation \n 6.) Extremems \n 0.) to quit."	);
choice= scan.nextInt();
break;}
default: {System.out.println("Invalid entry! Please try again!Please choose a data value 1.) for Highs. 2.) for Lows. 3.) for Wind. 4.) for gusts. 5.) for Precip. 0.) to go back.  ");
value=scan.nextInt();
break;}
}
value=scan.nextInt();
}
int data=0;
while (choice==4) {System.out.println("Please choose a data value 1.) for Highs. 2.) for Lows. 3.) for Wind. 4.) for gusts. 5.) for Precip. 0.) to go back.  "); 
data=scan.nextInt();

switch (data) {
case 1: {for (int local=0; local<4; local++){
	if (local==0){System.out.println("The minimum high for each month in Eagle, NE is:");}
	if (local==1){System.out.println ("The minimum high for each month in New York NY is: ");}
	if (local==2) {System.out.println ("The minimum high for each month in Houston, TX is:");}
	if (local==3) {System.out.println("The minimum high for each month in LA, CA is:" );}
				for (int month=0; month<12; month++){
					System.out.println("The minimum high for month " +(month+1));
					for (int day=0; day< DAYS_IN_MONTH [month]; day++){
						int min=0;
						if (WeatherData [local][month][day].getHigh()<min)
							min= WeatherData [local][month][day].getHigh();
						System.out.println(" is "+min);}
						
}
}
break;}
case 2:  {for (int local=0; local<4; local++){
	if (local==0){System.out.println("The minimum low for each month in Eagle, NE is:");}
	if (local==1){System.out.println ("The minimum low for each month in New York NY is: ");}
	if (local==2) {System.out.println ("The minimum low for each month in Houston, TX is:");}
	if (local==3) {System.out.println("The minimum low for each month in LA, CA is:" );}
				for (int month=0; month<12; month++){
					System.out.println("The minimum low for month " +(month+1)); 
					for (int day=0; day< DAYS_IN_MONTH [month]; day++){
						int min=0;
						if (WeatherData [local][month][day].getHigh()<min)
							min= WeatherData [local][month][day].getLow();
						System.out.println(" is "+min);}
						
}
}
break;}
case 3:  {for (int local=0; local<4; local++){
	if (local==0){System.out.println("The minimum windspeed for each month in Eagle, NE is:");}
	if (local==1){System.out.println ("The minimum windspeed for each month in New York NY is: ");}
	if (local==2) {System.out.println ("The minimum windspeed for each month in Houston, TX is:");}
	if (local==3) {System.out.println("The minimum windspeeed for each month in LA, CA is:" );}
				for (int month=0; month<12; month++){
					System.out.println("The minimum windspeed for month " +(month+1)); 
					for (int day=0; day< DAYS_IN_MONTH [month]; day++){
						int min=0;
						if (WeatherData [local][month][day].getHigh()<min)
							min= WeatherData [local][month][day].getWind();
						System.out.println(" is "+min);}
						
}
}
break;}
case 4:  {for (int local=0; local<4; local++){
	if (local==0){System.out.println("The minimum gust for each month in Eagle, NE is:");}
	if (local==1){System.out.println ("The minimum gust for each month in New York NY is: ");}
	if (local==2) {System.out.println ("The minimum gust for each month in Houston, TX is:");}
	if (local==3) {System.out.println("The minimum gust for each month in LA, CA is:" );}
				for (int month=0; month<12; month++){
					System.out.println("The minimum gust for month " +(month+1)); 
					for (int day=0; day< DAYS_IN_MONTH [month]; day++){
						int min=0;
						if (WeatherData [local][month][day].getHigh()<min)
							min= WeatherData [local][month][day].getGusts();
						System.out.println(" is "+min);}
						
}
}
break;}
case 5:  {for (int local=0; local<4; local++){
	if (local==0){System.out.println("The minimum precipitation for each month in Eagle, NE is:");}
	if (local==1){System.out.println ("The minimum precipitation for each month in New York NY is: ");}
	if (local==2) {System.out.println ("The minimum precipitation for each month in Houston, TX is:");}
	if (local==3) {System.out.println("The minimum precipitation for each month in LA, CA is:" );}
				for (int month=0; month<12; month++){
					System.out.println("The minimum precipitation for month " +(month+1)); 
					for (int day=0; day< DAYS_IN_MONTH [month]; day++){
						double min=0;
						if (WeatherData [local][month][day].getPrecip()<min)
							min= WeatherData [local][month][day].getHigh();
						System.out.println(" is "+min);}
						
}
}
break;}
case 0: {   System.out.println("Welcome to the weather data processer! \n Please make a choice, \n 1.) Weather Record \n 2.)Averages"+
		"\n 3.) Maximums \n 4.) Minimums \n 5.)Total Precipitation \n 6.) Extremems \n 0.) to quit."	);
choice= scan.nextInt();
break;}
default: {System.out.println("Invalid entry! Please try again!Please choose a data value 1.) for Highs. 2.) for Lows. 3.) for Wind. 4.) for gusts. 5.) for Precip. 0.) to go back.  ");
data=scan.nextInt();
break;}
}
data=scan.nextInt();
}
int precipchoice=0,month=0;
while (choice==5) { System.out.println("Please choose the location you would like to see the precipitation for"+
"1.) for Eagle, NE. 2.) for New York, NY. 3.) for Houston, TX. 4.) for LA, CA. or 0.) to quit.");
double preciptotal=0;
	switch (precipchoice) {
	case 1:{ for (month=0;month<12;month++){
		if (month==0){System.out.print("The total precipitation for Janruary in Eagle, NE is:");}
		if (month==1){System.out.print("The total precipitation for February in Eagle, NE is:");}
		if (month==2){System.out.print("The total precipitation for March in Eagle, NE is:");}
		if (month==3){System.out.print("The total precipitation for April in Eagle, NE is:");}
		if (month==4){System.out.print("The total precipitation for May in Eagle, NE is:");}
		if (month==5){System.out.print("The total precipitation for June in Eagle, NE is:");}
		if (month==6){System.out.print("The total precipitation for July in Eagle, NE is:");}
		if (month==7){System.out.print("The total precipitation for August in Eagle, NE is:");}
		if (month==8){System.out.print("The total precipitation for September in Eagle, NE is:");}
		if (month==9){System.out.print("The total precipitation for October in Eagle, NE is:");}
		if (month==10){System.out.print("The total precipitation for November in Eagle, NE is:");}
		if (month==11){System.out.print("The total precipitation for December in Eagle, NE is:");}
		for (int day=0; day< DAYS_IN_MONTH [month];day++){
			preciptotal=preciptotal+WeatherData [0][month][day].getPrecip();
			System.out.println(" "+preciptotal);
		}
	}
	break;}
	 case 2: { for (month=0;month<12;month++){
		if (month==0){System.out.print("The total precipitation for Janruary in New York, NY is:");}
		if (month==1){System.out.print("The total precipitation for February in New York, NY is:");}
		if (month==2){System.out.print("The total precipitation for March in New York, NY is:");}
		if (month==3){System.out.print("The total precipitation for April in New York, NY is:");}
		if (month==4){System.out.print("The total precipitation for May in New York, NY is:");}
		if (month==5){System.out.print("The total precipitation for June in New York, NY is:");}
		if (month==6){System.out.print("The total precipitation for July in New York, NY is:");}
		if (month==7){System.out.print("The total precipitation for August in New York, NY is:");}
		if (month==8){System.out.print("The total precipitation for September in New York, NY is:");}
		if (month==9){System.out.print("The total precipitation for October in New York, NY is:");}
		if (month==10){System.out.print("The total precipitation for November in New York, NY is:");}
		if (month==11){System.out.print("The total precipitation for December in New York, NY is:");}
		for (int day=0; day< DAYS_IN_MONTH [month];day++){
			preciptotal=preciptotal+WeatherData [1][month][day].getPrecip();
			System.out.println(" "+preciptotal);
		}
	}
	break;}
	 case 3: { for (month=0;month<12;month++){
		if (month==0){System.out.print("The total precipitation for Janruary in Houston, TX is:");}
		if (month==1){System.out.print("The total precipitation for February in Houston, TX is:");}
		if (month==2){System.out.print("The total precipitation for March in Houston, TX is:");}
		if (month==3){System.out.print("The total precipitation for April in Houston, TX is:");}
		if (month==4){System.out.print("The total precipitation for May in Houston, TX is:");}
		if (month==5){System.out.print("The total precipitation for June in Houuston, TX is:");}
		if (month==6){System.out.print("The total precipitation for July in Houston, TX is:");}
		if (month==7){System.out.print("The total precipitation for August in Houston, TX is:");}
		if (month==8){System.out.print("The total precipitation for September in Houston, TX is:");}
		if (month==9){System.out.print("The total precipitation for October in Houston, TX is:");}
		if (month==10){System.out.print("The total precipitation for November in Houston, TX is:");}
		if (month==11){System.out.print("The total precipitation for December in Houston, TX is:");}
		for (int day=0; day< DAYS_IN_MONTH [month];day++){
			
			preciptotal=preciptotal+WeatherData [2][month][day].getPrecip();
			System.out.println(" "+preciptotal);
		}
	}
	
	break;}
	 case 4: { for (month=0;month<12;month++){
		if (month==0){System.out.print("The total precipitation for Janruary in LA, CA is:");}
		if (month==1){System.out.print("The total precipitation for February in LA, CA is:");}
		if (month==2){System.out.print("The total precipitation for March in LA, CA is:");}
		if (month==3){System.out.print("The total precipitation for April in LA, CA is:");}
		if (month==4){System.out.print("The total precipitation for May in LA, CA is:");}
		if (month==5){System.out.print("The total precipitation for June in LA, CA is:");}
		if (month==6){System.out.print("The total precipitation for July in LA, CA is:");}
		if (month==7){System.out.print("The total precipitation for August in LA, CA is:");}
		if (month==8){System.out.print("The total precipitation for September in LA, CA is:");}
		if (month==9){System.out.print("The total precipitation for October in LA, CA is:");}
		if (month==10){System.out.print("The total precipitation for November in LA, CA is:");}
		if (month==11){System.out.print("The total precipitation for December in LA, CA is:");}
		for (int day=0; day< DAYS_IN_MONTH [month];day++){
			
			preciptotal=preciptotal+WeatherData [3][month][day].getPrecip();
			System.out.println(" "+preciptotal);
		}
	}
	break;}
	case 0: {   System.out.println("Welcome to the weather data processer! \n Please make a choice, \n 1.) Weather Record \n 2.)Averages"+
			"\n 3.) Maximums \n 4.) Minimums \n 5.)Total Precipitation \n 6.) Extremems \n 0.) to quit."	);
	choice= scan.nextInt();
	break;}
	default: {System.out.println("Invalid entry! Please try again!Please choose a data value 1.) for Highs. 2.) for Lows. 3.) for Wind. 4.) for gusts. 5.) for Precip. 0.) to go back.  ");
	precipchoice=scan.nextInt();
	break;}
}
	precipchoice=scan.nextInt();
}
int extremechoice=0;
while (choice==6){ System.out.println("Please choose the location you would like to see the extremes for"+
		"1.) for Eagle, NE. 2.) for New York, NY. 3.) for Houston, TX. 4.) for LA, CA. or 0.) to quit.");
int max=0,min=0,gustmax=0; double precipmax=0.00; GregorianCalendar maxdate=null,mindate=null, winddate=null, precipdate=null;
extremechoice=scan.nextInt();
	switch (extremechoice) {
	case 1: for ( month=0; month<12; month++){
						for (int day=0; day< DAYS_IN_MONTH [month]; day++){
							if (WeatherData [0][month][day].getHigh()>max)
								max= WeatherData [0][month][day].getHigh();
						 maxdate= WeatherData [0][month][day].getDate();}}
		
						System.out.println("The highest temperature recorded in Eagle NE is "+max+ " Which occured on "+ maxdate.MONTH+"/"+maxdate.DAY_OF_MONTH+"/2008");
		
				for ( int moonth=0; moonth<12; moonth++){
						for (int dayy=0; dayy< DAYS_IN_MONTH [moonth]; dayy++){
						if (WeatherData [0][moonth][dayy].getHigh()<min)
						min= WeatherData [0][moonth][dayy].getLow();
						mindate= WeatherData [0][moonth][dayy].getDate();}}
	
						System.out.println("The minimum low for Eagle, NE was " +min+ " which occured on " +(mindate.MONTH+"/"+mindate.DAY_OF_MONTH+"/2008"));

					for (int monthh=0; monthh<12; monthh++){
						for (int dasy=0; dasy< DAYS_IN_MONTH [monthh]; dasy++){
							if (WeatherData [0][monthh][dasy].getHigh()>max)
								gustmax= WeatherData [0][monthh][dasy].getWind();
							winddate=WeatherData [0][monthh][dasy].getDate();}}
							System.out.println("The maximum gust for Eagle, NE was " +gustmax+ " which occured on "+(winddate.MONTH+"/"+winddate.DAY_OF_MONTH+"/2008"));
	
					for (int montth=0; montth<12; montth++){
						for (int daya=0; daya<DAYS_IN_MONTH [montth]; daya++){
							if (WeatherData [0][montth][daya].getHigh()>max)
								precipmax= WeatherData [0][montth][daya].getPrecip();
							precipdate=WeatherData [0][month][daya].getDate();}}
							System.out.println("The maximum precip for Eagle, NE was " +precipmax+ " which occured on "+(precipdate.MONTH+"/"+precipdate.DAY_OF_MONTH+"/2008"));
					
	
	break;
	
	case 2:{ 
	for ( month=0; month<12; month++){
		for (int day=0; day< DAYS_IN_MONTH [month]; day++){
			if (WeatherData [1][month][day].getHigh()>max)
				max= WeatherData [1][month][day].getHigh();
		 maxdate= WeatherData [1][month][day].getDate();}}

		System.out.println("The highest temperature recorded in New York, NY  is "+max+ " Which occured on "+maxdate.MONTH+"/"+maxdate.DAY_OF_MONTH+"/2008");

for ( month=0; month<12; month++){
		for (int day=0; day< DAYS_IN_MONTH [month]; day++){
		if (WeatherData [1][month][day].getHigh()<min)
		min= WeatherData [1][month][day].getLow();
		mindate= WeatherData [1][month][day].getDate();}}

		System.out.println("The minimum low for New York, NY was " +min+ " which occured on " +mindate.MONTH+"/"+mindate.DAY_OF_MONTH+"/2008");

	for (int monthh=0; month<12; month++){
		for (int day=0; day< DAYS_IN_MONTH [month]; day++){
			if (WeatherData [1][monthh][day].getHigh()>max)
				gustmax= WeatherData [1][monthh][day].getWind();
			winddate=WeatherData [1][month][day].getDate();
			System.out.println("The maximum gust for New York, NY was " +gustmax+ " which occured on "+winddate.MONTH+"/"+winddate.DAY_OF_MONTH+"/2008");}}

	for (int montth=0; month<12; month++){
		for (int day=0; day<DAYS_IN_MONTH [month]; day++){
			if (WeatherData [1][montth][day].getHigh()>max)
				precipmax= WeatherData [1][montth][day].getPrecip();
			precipdate=WeatherData [1][month][day].getDate();
			System.out.println("The maximum precip for New York, NY was " +precipmax+ " which occured on "+precipdate.MONTH+"/"+precipdate.DAY_OF_MONTH+"/2008");}
	}

break;
		
	}
	case 3: { 
		for ( month=0; month<12; month++){
			for (int day=0; day< DAYS_IN_MONTH [month]; day++){
				if (WeatherData [2][month][day].getHigh()>max)
					max= WeatherData [2][month][day].getHigh();
			 maxdate= WeatherData [2][month][day].getDate();}}

			System.out.println("The highest temperature recorded in Houston, TX  is "+max+ " Which occured on "+maxdate.MONTH+"/"+maxdate.DAY_OF_MONTH+"/2008");

	for ( month=0; month<12; month++){
			for (int day=0; day< DAYS_IN_MONTH [month]; day++){
			if (WeatherData [2][month][day].getHigh()<min)
			min= WeatherData [2][month][day].getLow();
			mindate= WeatherData [2][month][day].getDate();}}

			System.out.println("The minimum low for Houston, TX was " +min+ " which occured on " +mindate.MONTH+"/"+mindate.DAY_OF_MONTH+"/2008");

		for (int monthh=0; month<12; month++){
			for (int day=0; day< DAYS_IN_MONTH [month]; day++){
				if (WeatherData [2][monthh][day].getHigh()>max)
					gustmax= WeatherData [2][monthh][day].getWind();
				winddate=WeatherData [2][month][day].getDate();
				System.out.println("The maximum gust for Houston, TX was " +gustmax+ " which occured on "+winddate.MONTH+"/"+winddate.DAY_OF_MONTH+"/2008");}}

		for (int montth=0; month<12; month++){
			for (int day=0; day<DAYS_IN_MONTH [month]; day++){
				if (WeatherData [2][montth][day].getHigh()>max)
					precipmax= WeatherData [2][montth][day].getPrecip();
				precipdate=WeatherData [2][month][day].getDate();
				System.out.println("The maximum precip for Houston, TX was " +precipmax+ " which occured on "+precipdate.MONTH+"/"+precipdate.DAY_OF_MONTH+"/2008");}
		}

	break;
			
		}
	case 4:{ 
		for ( month=0; month<12; month++){
			for (int day=0; day< DAYS_IN_MONTH [month]; day++){
				if (WeatherData [3][month][day].getHigh()>max)
					max= WeatherData [3][month][day].getHigh();
			 maxdate= WeatherData [3][month][day].getDate();}}

			System.out.println("The highest temperature recorded in LA,CA  is "+max+ " Which occured on "+maxdate.MONTH+"/"+maxdate.DAY_OF_MONTH+"/2008");

	for ( month=0; month<12; month++){
			for (int day=0; day< DAYS_IN_MONTH [month]; day++){
			if (WeatherData [3][month][day].getHigh()<min)
			min= WeatherData [3][month][day].getLow();
			mindate= WeatherData [3][month][day].getDate();}}

			System.out.println("The minimum low for LA, CA was " +min+ " which occured on " +mindate.MONTH+"/"+mindate.DAY_OF_MONTH+"/2008");

		for (int monthh=0; month<12; month++){
			for (int day=0; day< DAYS_IN_MONTH [month]; day++){
				if (WeatherData [3][monthh][day].getHigh()>max)
					gustmax= WeatherData [3][monthh][day].getWind();
				winddate=WeatherData [3][month][day].getDate();
				System.out.println("The maximum gust for LA, CA was " +gustmax+ " which occured on "+winddate.MONTH+"/"+winddate.DAY_OF_MONTH+"/2008");}}

		for (int montth=0; month<12; month++){
			for (int day=0; day<DAYS_IN_MONTH [month]; day++){
				if (WeatherData [3][montth][day].getHigh()>max)
					precipmax= WeatherData [3][montth][day].getPrecip();
				precipdate=WeatherData [3][month][day].getDate();
				System.out.println("The maximum precip for LA, CA was " +precipmax+ " which occured on "+precipdate.MONTH+"/"+precipdate.DAY_OF_MONTH+"/2008");}
		}

	break;
			
		}
	case 0: {   System.out.println("Welcome to the weather data processer! \n Please make a choice, \n 1.) Weather Record \n 2.)Averages"+
			"\n 3.) Maximums \n 4.) Minimums \n 5.)Total Precipitation \n 6.) Extremems \n 0.) to quit."	);
	choice= scan.nextInt();
	break;}
	default: {System.out.println("Invalid entry! Please try again!Please choose a data value 1.) for Highs. 2.) for Lows. 3.) for Wind. 4.) for gusts. 5.) for Precip. 0.) to go back.  ");
	extremechoice=scan.nextInt();
	break;}
}
	 System.out.println("Please choose the location you would like to see the extremes for"+
				"1.) for Eagle, NE. 2.) for New York, NY. 3.) for Houston, TX. 4.) for LA, CA. or 0.) to quit.");
	extremechoice=scan.nextInt();
}
while (choice==0) { int n=0;
	System.out.println ("Goodbye, and thank you for using the weather data processing system!");
	scan.close(); System.exit(n);

	}

































}
}





	

