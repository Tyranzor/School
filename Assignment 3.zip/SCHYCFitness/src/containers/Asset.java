package containers;

public abstract class Asset extends Object {
	
	private transient String productCode;
	private transient String identifier;
	private transient double cost;
	
	//Asset constructor
	public Asset(String productCode, String identifier, double cost) {
		super();
		this.productCode = productCode;
		this.identifier = identifier;
		this.cost = cost;
	}
	
	//Getter methods
	public String getCode() {
		return productCode;
	}
	
	public String getIdentifier() {
		return identifier;
	}
	
	public double getCost() {
		return cost;
	}
	
}
