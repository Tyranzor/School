package containers;

import java.util.ArrayList;

public class Invoice {

	private String invoiceCode;
	private Member memberName;
	private Person personalTrainer;
	private String date;
	private ArrayList<Asset> products;
	private boolean isStudent;
	private double subtotal;
	private double fees;
	private double taxes;
	private double discount;
	private double total;
	
	
	public String getInvoiceCode() {
		return invoiceCode;
	}
	public Member getMemberCode() {
		return memberName;
	}
	public Person getPersonalTrainer() {
		return personalTrainer;
	}
	public String getDate() {
		return date;
	}
	public ArrayList<Asset> getProducts() {
		return products;
	}
	public boolean isStudent() {
		return isStudent;
	}
	public double getSubtotal() {
		return subtotal;
	}
	public void setSubtotal() {
		double subtotal = 0;
		for(Asset a: products) {
			subtotal = subtotal + a.getCost();
		}
		this.subtotal = subtotal;
	}
	public double getFees() {
		return fees;
	}
	public void setFees() {
		if(isStudent) {
			this.fees = 10.50;
		}
	}
	public double getTaxes() {
		return taxes;
	}
	public void setTaxes() {
		double taxes = 0;
		if(isStudent) {
			taxes = 0;
		}
		else {
			for(Asset a: products) {
				if(a.getIdentifier().equalsIgnoreCase("Y") || a.getIdentifier().equalsIgnoreCase("D")) {
					taxes = a.getCost()*.06;
				}
				else {
					taxes = a.getCost()*.04;
				}
			}
		}
		this.taxes = taxes;
	}
	public double getDiscount() {
		return discount;
	}
	public void setDiscount(double discount) {
		if(isStudent) {
			discount = .08;
		}
	}
	public double getTotal() {
		return total;
	}
	public void setTotal() {
		double total = 0;
		total = subtotal + fees + taxes - discount;
		this.total = total;
	}
	public Invoice(String invoiceCode, Member memberName, Person personalTrainer, String date,
			ArrayList<Asset> products, boolean isStudent) {
		super();
		this.invoiceCode = invoiceCode;
		this.memberName = memberName;
		this.personalTrainer = personalTrainer;
		this.date = date;
		this.products = products;
		this.isStudent = isStudent;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
