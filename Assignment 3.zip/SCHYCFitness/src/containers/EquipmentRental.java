package containers;

public class EquipmentRental extends Asset{

	private String name;
	
	//Equipment rental constructor
	public EquipmentRental(String productCode, String identifier, double cost, String name) {
		super(productCode, "R", cost);
		this.name=name;
	}
	
	//Getter method
	public String getName() {
		return name;
	}
	
}