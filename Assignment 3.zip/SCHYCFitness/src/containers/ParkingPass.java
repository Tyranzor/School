package containers;

public class ParkingPass extends Asset{

	//Parking pass constructor
	public ParkingPass(String productCode, String identifier, double cost) {
		super(productCode, "P", cost);
	}

}