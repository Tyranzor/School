package readersWriters;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import com.thoughtworks.xstream.XStream;
import containers.*;

public class XMLWriter {

	public <T extends Object> void xmlConverter(ArrayList<T> personList, String filename){
		
		//Create the XML stream
		XStream xs= new XStream();
		
		//Create the output file
		File xmlOutput= new File (filename);
		
		//Create the writer
		PrintWriter xmlPrintWriter = null; 
			
		try {
			xmlPrintWriter = new PrintWriter(xmlOutput);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		//Call the write method of the print writer
		xmlPrintWriter.write("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n");
		xs.alias("person", Person.class);
		
		for (Object anObject : personList) {
			
			// Use toXML method to convert Person object into a String
			String personOutput = xs.toXML(anObject);
			xmlPrintWriter.write(personOutput);
			
		}
		
		//Close the file writer
		xmlPrintWriter.close();
		
	}
	
}




