package readersWriters;

public class InvoiceWriter {

	//import invoice array list
	
	//use enhanced for loop to cycle through each element in the invoice array list and
	//print each invoice field of the invoice class to the console
	
	//also print each product (asset) purchased and display its subtotal, tax, and total price 
	//that corresponds to each invoice
	
	
	
	
	
}
