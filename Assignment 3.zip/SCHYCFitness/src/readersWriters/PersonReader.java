package readersWriters;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.*;
import containers.Address;
import containers.Person;

public class PersonReader {
	
	private static ArrayList<Person> personList= new ArrayList<Person>();
	private static void ReadPersons(){
	
	//Create an array list
	ArrayList<String> strings= new ArrayList<String>();
	String str;	
		
	//Open the reader to import data
	try { 
		BufferedReader in = new BufferedReader(new FileReader("data/Persons.dat"));
		in.readLine();
	
		//Read in each line of the input file
		while((str = in.readLine()) != null){
			if (str.length()>0){
				strings.add(str);
			}
		}
		
		for (String s: strings){

			String personCode;
			String name;
			String fullAddress;
			String emails = null;
			String lastName;
			String firstName;
			String street;
			String city;
			String state;
			String zip;
			String country;
		
			//Separate each person line into its components
			String data[] = s.split("[;]"); 
			personCode= data[0];
			name=data[1];
			fullAddress= data[2];
			
			//Check to see if an email component is present and store it if one is found
			if(data.length>3){				
				emails=data[3];
			}
			
			else if(data.length<=3)  {}
			
			//Store each component in a local variable
			String [] splits=name.split("[,]");
			lastName= splits[0];
			firstName= splits[1];		  
			splits= fullAddress.split("[,]");		 
			street=splits[0];
			city=splits[1];
			state=splits[2];
			zip=splits[3];
			country=splits[4];
			
			//Call the address constructor
			Address address= new Address (street, city, state, country,zip);
			
			//Call the person constructor with an email
			if(data.length>3){				
				Person newPerson= new Person (lastName, personCode, emails, address, firstName);
				personList.add(newPerson);
			}
			
			//Call the person constructor without an email
			else if(data.length<=3)  {
				Person newPerson= new Person (lastName, personCode, address, firstName);
				personList.add(newPerson);
			}

		}
	
		//Close the file reader
		in.close();
	}
	
	catch (Exception e){ e.printStackTrace();
		System.out.println("File not found");
	}
	
	}
	
	//Getter method
	public static ArrayList<Person> getPersonList() {
		ReadPersons();
		return personList;
	}
}