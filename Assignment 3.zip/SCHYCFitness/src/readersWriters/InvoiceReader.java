package readersWriters;

import java.util.ArrayList;

import containers.Asset;
import containers.Invoice;

public class InvoiceReader {

	ArrayList<Invoice> invoiceList = new ArrayList<Invoice>();
	
	//read in the invoice.dat file line by line
	
	//split each semicolon delimited data into separate strings
	
	//create an asset arraylist
	
	//search for the product based on each product code removed from the input file and match
	//it to a corresponding product from the asset file input. store each match in an asset arraylist
	
	//search for a member based on the member code removed from the input file and match it
	//to a corresponding member from the member file input. store the member in a local member variable
	
	//search for a trainer based on the trainer code removed from the input file and match it to a
	//corresponding member from the person file input. store the person in a local person variable
	
	//check to see if the member is a student and if so, pass true for the isStudent boolean value in the constructor
	
	//call the invoice constructor with each data string and pass the asset arraylist as the last argument
	
	//add each invoice to the invoice arraylist
	
	
	
	
	
	
}
