package unl.cse.parking;

public class GarageSimulation {
	public static void main(String[] args) {
		
		Garage safePark = new Garage(10);
		CompactCar cc1= new CompactCar("ABC 123");
		SUV suv1= new SUV("QED NEB");
		Motorbike mb1= new Motorbike ("XYZ 321");
		Motorbike mb2 = new Motorbike ("QT 42");
		CompactCar cc2= new CompactCar("FOO 459");
		CompactCar cc3= new CompactCar ("BAR 560");
		SUV suv2 = new SUV("CSE 444");
		
		safePark.addVehicle(cc1);
		safePark.addVehicle(suv1);
		safePark.addDay();
		safePark.addDay();
		safePark.addVehicle(mb1);
		safePark.addDay();
		safePark.addVehicle(mb2);
		safePark.addVehicle(cc2);
		safePark.addDay();
		safePark.addDay();
		safePark.removeVehicle("QT 42");
		safePark.addDay();
		safePark.displayReport();
		
		
//		safePark.addDay();
//		safePark.removeVehicle(cc1.getLicense());
//		safePark.addDay();
//		safePark.addDay();
//		safePark.addDay();
//		safePark.addVehicle(cc3);
//		safePark.addDay();
//		safePark.addDay();
//		safePark.addDay();
//		safePark.displayReport();
//		
//		
//		safePark.addDay();
//		safePark.removeVehicle(suv1.getLicense());
//		safePark.addDay();
//		safePark.addDay();
//		safePark.addVehicle(suv2);
//		safePark.addVehicle(mb2);
//		safePark.addDay();
//		safePark.addDay();
//		safePark.addDay();
//		safePark.addDay();
//		safePark.displayReport();
		


		
	}
}
