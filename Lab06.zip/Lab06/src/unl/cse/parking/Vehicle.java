package unl.cse.parking;

public abstract class Vehicle {

	private final String license;
	private  int days;
	
	// The class constructor
	public Vehicle(String license) {
		this.license = license;
		days=0;
	}
	
	/**
	 * The getter method granting public access to reading the
	 * license plate number. Notice license does not have a
	 * setter since it cannot be modified.
	 */
	public String getLicense() {
		return license;
	}
	public abstract int getDays();
	public abstract void addDay(int numebr);
	public abstract double getCost();
	public abstract String getType();
	
}
