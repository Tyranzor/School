/**
 * 
 */
package unl.cse.parking;

/**
 * @author npittman
 *
 */
public class SUV extends Vehicle {
	private final String type="SUV";
	private int days;
	
	public SUV(String license) {
		super(license);
		days=0;
		// TODO Auto-generated constructor stub
	}

	

	

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	@Override
	public int getDays() {
		// TODO Auto-generated method stub
		return this.days;
	}

	@Override
	public void addDay(int numebr) {
		days= days+numebr;
		
	}


	@Override
	public double getCost() {
		// TODO Auto-generated method stub
		return this.days*6;
	}

	

}
