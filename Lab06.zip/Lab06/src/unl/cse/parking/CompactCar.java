/**
 * 
 */
package unl.cse.parking;

/**
 * @author npittman
 *
 */
public class CompactCar extends Vehicle {
	private final String type= "CompactCar";
	private int days;
	private int stallNumber;

	/**
	 * @param license
	 */
	public CompactCar(String license) {
		super(license);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	@Override
	public int getDays() {
		// TODO Auto-generated method stub
		return this.days;
	}

	@Override
	public void addDay(int numebr) {
		days= days+numebr;
		
	}


	@Override
	public double getCost() {
		// TODO Auto-generated method stub
		return this.days*4.5;
	}
	@Override
	public void setStallNumber(int stall) {
		this.stallNumber=stall;
		
	}
	
	@Override
	public int getStallNumber() {
		// TODO Auto-generated method stub
		return this.stallNumber;
	}

	

}
