package unl.cse.parking;

import java.util.ArrayList;

public class Garage {

	private final ArrayList<Vehicle> stalls= new ArrayList<Vehicle>();
	private int size; 
	
	public Garage(int capacity) {
		this.size=capacity;
	}
	
	/**
	 * "Parks" the vehicle in a stall if one is available.  Returns true if
	 * the vehicle was added successfully; false otherwise.
	 */
	public boolean addVehicle(Vehicle automobile) {
		if (stalls.size()<this.size){
			stalls.add(automobile);
			
			return true;
		}
		else { System.out.println("Garage full");
		return false; 
		}
		
	}
	
	/**
	 * Remove the vehicle having the provided
	 * license plate number from the garage. The method returns
	 * the vehicle if it is found otherwise it returns null. 
	 */
	public Vehicle removeVehicle(String license) {
		Vehicle removed= null;
		for (Vehicle v:stalls){
			if (v.getLicense().equalsIgnoreCase(license)){
				System.out.println("Total cost for "+v.getType()+" liscense plate "+v.getLicense()+" is "+v.getCost());
				stalls.remove(v);
				removed = v;
			}
			
		}
		return removed;
	}
		
		
	/**
	 * Returns the maximum capacity of this Garage
	 */
	public int getCapacity() {
		return this.stalls.size();
	}
	
	/**
	 * Returns the number of empty stalls in the garage--the number of open
	 * spots
	 * @return
	 */
	public int getNumFreeSpots() {
		return this.size-stalls.size();
	}

	/**
	 * Simulates the passing of a day by adding a day in the garage to each vehicle
	 * in the garage.
	 * @return
	 */
	public void addDay() {
		for (Vehicle v: stalls){
			v.addDay(1);
		}
	}
	
	public void addDay(int numDays) {
		for (Vehicle v: stalls){
			v.addDay(numDays);
		}
	}
	
	/**
	 * Displays the current "state" of the garage by printing out information about each
	 * stall
	 */
	public void displayReport() {
		
		System.out.println("Stall License Type Days Total Fee");
		int count=0;
			if(stalls.isEmpty()) {
				System.out.println(String.format("%3d EMPTY", (count+1)));
			} else {
				ArrayList<Vehicle>printgarage = new ArrayList<Vehicle>();
				for (Vehicle v:stalls){
				System.out.println(String.format("%3d %-10s %-11s %3d $%5.2f", (count+1), v.getLicense(), v.getType(), v.getDays(), v.getCost()));
				count++;
				}
			}
		}
	}
