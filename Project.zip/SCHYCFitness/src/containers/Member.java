package containers;

public class Member  {
	
	

	private  String type;
	private String memberCode;
	private Person primaryContact;
	private String name;
	private Address address;
	
	
	/**
	 * @param type
	 * @param memberCode
	 * @param primaryContact
	 * @param name
	 * @param address
	 */
	public Member(String type, String memberCode, Person primaryContact, String name, Address address) {
		super();
		this.type = type;
		this.memberCode = memberCode;
		this.primaryContact = primaryContact;
		this.name = name;
		this.address = address;
	}
	/**
 * @return the type
 */
	public String getType() {
		return type;
	}
/**
 * 
 * @return the memberCode, unique from the personCode
 */

	public String getMemberCode() {
		return memberCode;
	}


/**
 * @return the primaryContact
 */
public Person getPrimaryContact() {
	return primaryContact;
}
/**
 * @return the name
 */
	public String getName() {
	return name;
	}
/**
 * @return the address
 */
	public Address getAddress() {
	return address;
	}
	
}
