package containers;

public class Member  {
	
	

	private  String type;
	private String memberCode;
	private String primaryContactCode;
	private String name;
	private Address address;
	
	/**
	 * @param type
	 * @param memberCode
	 * @param primaryContactCode
	 * @param name
	 * @param address
	 */
	public Member(String type, String memberCode, String primaryContactCode, String name, Address address) {
		super();
		this.type = type;
		this.memberCode = memberCode;
		this.primaryContactCode = primaryContactCode;
		this.name = name;
		this.address = address;
	}
	/**
 * @return the type
 */
	public String getType() {
		return type;
	}
/**
 * 
 * @return the memberCode, unique from the personCode
 */

	public String getMemberCode() {
		return memberCode;
	}

/**
 * @return the primaryContactCode
 */
	public String getPrimaryContactCode() {
	return primaryContactCode;
	}
/**
 * @return the name
 */
	public String getName() {
	return name;
	}
/**
 * @return the address
 */
	public Address getAddress() {
	return address;
	}
	
}
