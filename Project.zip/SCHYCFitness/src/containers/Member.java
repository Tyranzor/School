package containers;

public class Member extends Person {
	
	

	private  String type;
	private String memberCode;
	private Person primaryContact;
/**
 * 
 * @param lastName
 * @param personCode
 * @param emaillist
 * @param address
 * @param firstName
 * @param type
 * @param memberCode
 * @param primary
 */
	public Member(String lastName, String personCode, String emaillist, Address address, String firstName,String type, String memberCode, Person primary) {
		super(lastName, personCode, emaillist, address, firstName);
		this.type=type;
		this.memberCode=memberCode;
		this.primaryContact=primary;
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 * @param lastName
	 * @param personCode
	 * @param address
	 * @param firstName
	 * @param type
	 * @param memberCode
	 * @param primary
	 */
	public Member(String lastName, String personCode, Address address, String firstName,String type, String memberCode, Person primary) {
		super(lastName, personCode, address, firstName);
		this.type=type;
		this.memberCode=memberCode;
		this.primaryContact=primary;
		// TODO Auto-generated constructor stub
	}

	/**
 * @return the type
 */
	public String getType() {
		return type;
	}
/**
 * 
 * @return the memberCode, unique from the personCode
 */

	public String getMemberCode() {
		return memberCode;
	}

/**
 * 
 * @return primary contact for the member
 */
	public Person getPrimaryContact() {
		return primaryContact;
	}
	
}
