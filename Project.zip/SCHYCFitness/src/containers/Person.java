package containers;
import containers.Address;
public class Person extends Object {
	
	private String lastName;
	private String personCode;
	private String emaillist;
	private Address address; 
	private String firstName;
	/**
	 * 
	 * @param lastName
	 * @param personCode
	 * @param address
	 * @param firstName
	 */

	public Person( String lastName, String personCode, Address address, String firstName) {
		super();
		this.lastName = lastName;
		this.personCode = personCode;
		this.address = address;
		this.firstName = firstName;
	}
/**
 * 
 * @param lastName
 * @param personCode
 * @param emaillist
 * @param address
 * @param firstName
 */


	public Person( String lastName, String personCode, String emaillist, Address address,
			String firstName) {
		super();
		this.lastName = lastName;
		this.personCode = personCode;
		this.emaillist = emaillist;
		this.address = address;
		this.firstName = firstName;
	}

/**
 * 
 * @return first name
 */

	public String getFirstName() {
		return firstName;
	}
/**
 * 
 * @return last name
 */

	public String getLastName() {
		return lastName;
	}
/**
 * 
 * @return unique person code
 */
	public String getPersonCode() {
		return personCode;
	}
/**
 * 
 * @return emaillist if exists
 */
	public String getEmaillist() {
		return emaillist;
	}
	
	/**
	 * 
	 * @return address
	 */
	public Address getAddress(){
		return this.address;
		
	}
	
	
	
	
}
 



