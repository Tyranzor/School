package containers;

public class YearLongMemebrship extends Asset {
private String startDate;
private String endDate;
private Address address;
private String membershipName;
/**
 * @param productCode
 * @param identifier
 * @param cost
 * @param startDate
 * @param endDate
 * @param address
 * @param membershipName
 */
public YearLongMemebrship(String productCode, String identifier, double cost, String startDate, String endDate,
		Address address, String membershipName) {
	super(productCode, "Y", cost);
	this.startDate = startDate;
	this.endDate = endDate;
	this.address = address;
	this.membershipName = membershipName;
}
}
