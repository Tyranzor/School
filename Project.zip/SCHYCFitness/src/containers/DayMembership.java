package containers;

public class DayMembership extends Asset {
	
	private Address address;
	private String dateTime;
	/**
	 * 
	 * @param productCode
	 * @param identifier
	 * @param cost
	 * @param address
	 * @param dateTime
	 */
	public DayMembership(String productCode, String identifier, double cost, Address address, String dateTime) {
		super(productCode, "D", cost);
		this.address=address;
		this.dateTime=dateTime;
		// TODO Auto-generated constructor stub
	}
	/**
	 * 
	 * @return the address of the membership
	 */
	public Address getAddress() {
		return address;
	}
	/**
	 * 
	 * @return the date time of the membership
	 */
	public String getDateTime() {
		return dateTime;
	}
	
}
