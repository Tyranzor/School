package containers;

public abstract class Asset extends Object {
private transient String productCode;
private transient String identifier;
private transient double cost;
/**
 * @param productCode
 * @param identifier
 * @param cost
 */
public Asset(String productCode, String identifier, double cost) {
	super();
	this.productCode = productCode;
	this.identifier = identifier;
	this.cost = cost;
}

/**
 * @return the code
 */
public String getCode() {
	return productCode;
}
/**
 * @return the productCode
 */

public String getIdentifier() {
	return identifier;
}
/**
 * 
 * @return cost
 */
public double getCost() {
	return cost;
}

}
