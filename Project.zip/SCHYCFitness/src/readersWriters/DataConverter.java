package readersWriters;

import readersWriters.*;
import containers.*;
import java.util.*;

public class DataConverter {
 protected static PersonReader readP= new PersonReader();
 protected static AssetReader readA= new AssetReader();
 protected static MemberReader readM= new MemberReader();
 private static JSONWriter jWrite= new JSONWriter();
 private static XMLWriter xmlWrite= new XMLWriter();
 
	public static void main(String[] args) {
		
		ArrayList<Person> personList = new ArrayList<Person>();
		ArrayList<Member> memberList= new ArrayList<Member>();
		ArrayList<YearLongMembership> yearList= new ArrayList<YearLongMembership>();
		ArrayList<DayMembership> dayList= new ArrayList<DayMembership>();
		ArrayList<EquipmentRental> equipList= new ArrayList<EquipmentRental>();
		ArrayList<ParkingPass> parkList= new ArrayList<ParkingPass>();
		ArrayList<Asset> masterAsset= new ArrayList<Asset>();
		
		personList= PersonReader.getPersonList();
		memberList= readM.getMemberList();
		yearList=readA.getYearList();
		dayList= readA.getDayList();
		equipList= readA.getEquipList();
		parkList= readA.getParkList();
		
		for (YearLongMembership y:yearList ){
			masterAsset.add(y);
		}
		for (DayMembership y:dayList ){
			masterAsset.add(y);
		}
		for (EquipmentRental y:equipList ){
			masterAsset.add(y);
		}
		for (ParkingPass y:parkList ){
			masterAsset.add(y);
		}
		jWrite.JSONConverter(masterAsset, "data/Assets.json");
		jWrite.JSONConverter(memberList, "data/Members.json");
		jWrite.JSONConverter(personList, "data/Persons.json");
		xmlWrite.xmlConverter(masterAsset, "data/Assets.xml");
		xmlWrite.xmlConverter(memberList, "data/Members.xml");
		xmlWrite.xmlConverter(personList, "data/Persons.xml");


		
		
		
		
		
		
		
	}

}
