package readersWriters;

import readersWriters.*;
import containers.*;
import java.util.*;

public class DataConverter {
 protected static PersonReader readP= new PersonReader();
 
	public static void main(String[] args) {
		ArrayList<Person> personList = new ArrayList<Person>();
		personList= readP.getPersonList();
		
		for (Person p: personList){
			System.out.println(p.getFirstName());
		}
		
	}

}
