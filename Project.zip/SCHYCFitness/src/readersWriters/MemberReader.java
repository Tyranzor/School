package readersWriters;

public class MemberReader {

}
