package readersWriters;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.*;
import containers.*;


public class MemberReader {
	protected static PersonReader readP= new PersonReader();
	private static ArrayList<Member> memberList= new ArrayList<Member>();
	private static ArrayList<Person> personList = new ArrayList<Person>();
	
	private static void ReadMembers(){
		personList= readP.getPersonList();
		ArrayList<String> strings= new ArrayList<String>();
		try { 
			BufferedReader in = new BufferedReader(new FileReader("data/Members.dat"));
			in.readLine();
			
		
		String str;
		
		while((str = in.readLine()) != null){
			if (str.length()>0){
		    strings.add(str);
			}
			
			}
		in.close();
		}
		catch (Exception e){ e.printStackTrace();
		System.out.println("you done fucked up now");
	}


		for (String s: strings){
			String data []= s.split("[;]");
			Person p = null;
			String line=data[4];
			String address []=line.split("[,]");
			Address a= new Address (address[0],address[1],address[2],address[4],address[3]);
				for (Person pers:personList){
					if (data[2].contentEquals(pers.getPersonCode())){
						p=pers;
					}
				}
				Member m= new Member(data[1],data[0],p,data[3],a);
				memberList.add(m);
			
			
		}
	}

	/**
	 * @return the memberList
	 */
	public static ArrayList<Member> getMemberList() {
		ReadMembers();
		return memberList;
	}
	
}
