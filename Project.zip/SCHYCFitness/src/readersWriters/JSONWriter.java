package readersWriters;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import containers.*;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class JSONWriter {
	
	public<T extends Person> void JSONPersonConverter(ArrayList<T> objects ){
	Gson gson = new GsonBuilder().setPrettyPrinting().create();
	File jsonOutput = new File("data/People.json");
	PrintWriter jsonPrintWriter = null;
	try {
		 jsonPrintWriter = new PrintWriter(jsonOutput);
	} catch (FileNotFoundException e) {
		e.printStackTrace();
	}

	
	for (Object anObject : objects) {
		// Use toJson method to convert Person object into a String
		String personOutput = gson.toJson(anObject);
		jsonPrintWriter.write(personOutput + "\n");
	}

	jsonPrintWriter.close();
	}

	public<T extends Asset> void JSONAssetConverter(ArrayList<T> objects){
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		File jsonOutput = new File("data/Assets.json");
		PrintWriter jsonPrintWriter = null;
		try {
			 jsonPrintWriter = new PrintWriter(jsonOutput);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		
		for (Object anObject : objects) {
			// Use toJson method to convert Person object into a String
			String personOutput = gson.toJson(anObject);
			jsonPrintWriter.write(personOutput + "\n");
		}

		jsonPrintWriter.close();
		}


}

