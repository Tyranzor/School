package readersWriters;

public class AssetReader {

}
