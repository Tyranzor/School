package unl.cse.queues;

import unl.cse.linked_list.LinkedList;

public class Queue<T> {

	private final LinkedList<T> list = new LinkedList<T>();

	public T dequeue() {
		T T = list.getElementFromTail();
		list.removeElementFromTail();
		return T;
	}

	public void enqueue(T item) {
		list.addElementToHead(item);
	}

	public int size() {
		return list.size();
	}

	public boolean isEmpty() {
		if (list.getElementFromHead() == null) {
			return true;
		} else
			return false;
	}

}
