package unl.cse.stacks;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class PostfixEvaluator {

	private static final Set<String> OPERATORS = new HashSet<String>(Arrays.asList("+", "-", "*", "/"));
	private final Stack<String> stack;

	/**
	 * Constructor
	 */
	public PostfixEvaluator() {
		this.stack = new Stack<String>();
	}

	private boolean isOperator(String s) {
		return OPERATORS.contains(s);
	}

	private String evaluate(String a, String b, String op) {
		Double d1 = Double.parseDouble(a);
		Double d2 = Double.parseDouble(b);
		if (op.equals("+"))
			return new Double(d1 + d2).toString();
		else if (op.equals("-"))
			return new Double(d1 - d2).toString();
		else if (op.equals("*"))
			return new Double(d1 * d2).toString();
		else if (op.equals("/"))
			return new Double(d1 / d2).toString();
		else
			throw new IllegalStateException("Unrecognized operator: " + op);
	}

	/**
	 * Evaluates the given arithmetic expression in postfix format change this
	 * method
	 *
	 * @param expression
	 * @return
	 */
	private double evaluateExpression(String expression) {
		String result;
		String values[] = expression.split("\\s+");
		for (String v : values) {
			if (v.equals("+") || v.equals("-") || v.equals("*") || v.equals("/")) {

				result = evaluate(stack.pop(), stack.pop(), v);
				stack.push(result);
			} else {

				stack.push(v);
			}

		}
		// At this point, the final result should be on the top of the stack,
		// we pop it off, parse it and return the result
		Double d = Double.parseDouble(this.stack.pop());
		return d;
	}

	/**
	 * 4 3 * 9 27 3 / * + 9 + 3 9 + - 3 4 * + 8 + should equal 10
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		PostfixEvaluator postfixEvaluator = new PostfixEvaluator();
		System.out.print("Please enter the Arithmatic Expression (Postfix form) to evaluate: ");
		Scanner myScanner = new Scanner(System.in);
		String expression = myScanner.nextLine();
		System.out.println(expression);
		System.out.println("Result: " + postfixEvaluator.evaluateExpression(expression));
	}
}
