package unl.cse.stacks;

import unl.cse.linked_list.LinkedList;

public class Stack<T> {

	private final LinkedList<T> list = new LinkedList<T>();

	public T pop() {
		T T = list.getElementFromHead();
		list.removeElementFromHead();
		return T;

	}

	public void push(T item) {
		list.addElementToHead(item);
	}

	public int size() {
		return list.size();
	}

	public boolean isEmpty() {
		if (list.getElementFromHead() == null) {
			return true;
		} else
			return false;
	}

}
