package unl.cse.company;

public interface CompanyPortfolio {
	public void computeProductivity();
}
