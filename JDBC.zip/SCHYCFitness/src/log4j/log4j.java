package log4j;
import org.apache.logging.log4j.*;

import readersWriters.MemberReader;
import readersWriters.databaseReader;
public class log4j {

	public log4j() {
		Logger Logger = LogManager.getLogger();
		
	}
	public void log (Exception error){
		System.out.println("Error logged");
		
	}

}
