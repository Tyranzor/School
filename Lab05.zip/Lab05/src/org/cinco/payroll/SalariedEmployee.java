package org.cinco.payroll;

public class SalariedEmployee extends Employee {
	private double salary;
	private String type="Salary";

	/**
	 * @param id
	 * @param firstName
	 * @param lastName
	 * @param title
	 * @param salary
	 */
	public SalariedEmployee(String id, String firstName, String lastName, String title, double salary) {
		super(id, firstName, lastName, title);
		this.salary = salary;
	}

	/**
	 * @return the salary
	 */
	public double getSalary() {
		return salary;
	}

	/**
	 * @param salary the salary to set
	 */
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	@Override
	public double calculateTax(){
		double pay= this.salary;
		double tax= pay*.2;
		return ((pay-tax)+100);
	}
	@Override
	public double getTax(){
		return salary*.2;
	}
	@Override
	public double getNet(){
		return this.salary;
	}
	public String getType(){
		return this.type;
	}

	

}
