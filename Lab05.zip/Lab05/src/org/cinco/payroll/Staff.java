/**
 * 
 */
package org.cinco.payroll;

/**
 * @author Nathan
 *
 */
public class Staff extends HourlyEmployee {
	private double TAX_RATE;
	private String type= "Staff";

	/**
	 * @param id
	 * @param firstName
	 * @param lastName
	 * @param title
	 * @param hourlyPay
	 * @param hoursWorked
	 * @param tAX_RATE
	 */
	public Staff(String id, String firstName, String lastName, String title, double hourlyPay, double hoursWorked,
			double tAX_RATE) {
		super(id, firstName, lastName, title, hourlyPay, hoursWorked);
		TAX_RATE = tAX_RATE;
	}

	/**
	 * @return the tAX_RATE
	 */
	public double getTAX_RATE() {
		return TAX_RATE;
	}

	/**
	 * @param tAX_RATE the tAX_RATE to set
	 */
	public void setTAX_RATE(double tAX_RATE) {
		TAX_RATE = tAX_RATE;
	}
	
	@Override
	public double calculateTax(){
		double tax=this.getNet()*.15;
		return this.getNet()-tax;
	}
		
	@Override
	public double getTax(){
		return .15;
	}
	public String getType(){
		return this.type;
	}
	
	

	
}
