package org.cinco.payroll;

public class Temporary extends HourlyEmployee {
	private String type="Temporary";

	public Temporary(String id, String firstName, String lastName, String title, double hourlyPay, double hoursWorked) {
		super(id, firstName, lastName, title, hourlyPay, hoursWorked);
		// TODO Auto-generated constructor stub
	}
	public String getType(){
		return this.type;
	}

}
