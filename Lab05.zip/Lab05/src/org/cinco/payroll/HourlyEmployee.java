/**
 * 
 */
package org.cinco.payroll;

/**
 * @author Nathan
 *
 */
public class HourlyEmployee extends Employee {
	private double hourlyPay;
	private double hoursWorked;
	private String type;



	/**
	 * @param id
	 * @param firstName
	 * @param lastName
	 * @param title
	 * @param hourlyPay
	 * @param hoursWorked
	 */
	public HourlyEmployee(String id, String firstName, String lastName, String title, double hourlyPay,
			double hoursWorked) {
		super(id, firstName, lastName, title);
		this.hourlyPay = hourlyPay;
		this.hoursWorked = hoursWorked;
	}



	/**
	 * @return the hoursWorked
	 */
	public double getHoursWorked() {
		return hoursWorked;
	}



	/**
	 * @param hoursWorked the hoursWorked to set
	 */
	public void setHoursWorked(double hoursWorked) {
		this.hoursWorked = hoursWorked;
	}
	@Override
	public double calculateTax(){
		double pay= this.hourlyPay*this.hoursWorked;
		return pay;
	}
	@Override
	public double getTax(){
		return 0;
	}
	@Override
	public double getNet(){
		return this.hourlyPay*this.hoursWorked;
	}
	public String getType(){
		return this.type;
	}

}
