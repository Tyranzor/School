package org.cinco.payroll;

public abstract class Employee {
	private String id;
	private String firstName;
	private String lastName;
	private String title;
	private String type;
	/**
	 * @param id
	 * @param firstName
	 * @param lastName
	 * @param title
	 */
	public Employee(String id, String firstName, String lastName, String title) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.title = title;
	}
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}
	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	
	public double getTax(){
		return 0;
	}
	public double getNet(){
		return 0;
	}
	
	public double calculateTax() {
		// TODO Auto-generated method stub
		return 0;
	}
	public String getType(){
		return this.type;
	}

}
