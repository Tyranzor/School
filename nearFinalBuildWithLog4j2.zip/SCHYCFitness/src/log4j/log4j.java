package log4j;

public class log4j {

	public log4j() {
		// Logger Logger = LogManager.getLogger("log4j.java");

	}

	public static void log(Exception error) {
		System.out.println("Error logged");

	}

}
