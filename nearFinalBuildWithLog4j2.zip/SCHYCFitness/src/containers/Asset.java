package containers;

public abstract class Asset extends Object {
	private String productCode;
	private String identifier;
	protected double cost;
	protected int quantity;

	/**
	 * @param productCode
	 * @param identifier
	 * @param cost
	 */
	public Asset(String productCode, String identifier, double cost) {
		super();
		this.productCode = productCode;
		this.identifier = identifier;
		this.cost = cost;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return productCode;
	}

	/**
	 * @return the productCode
	 */

	public String getIdentifier() {
		return identifier;
	}

	/**
	 * 
	 * @return cost
	 */
	public double getCost() {
		return cost;
	}

	public abstract double getTax();

	public void setQuantity(int i) {
		this.quantity = i;
	}

	public abstract double getDiscount();

	/**
	 * @return the productCode
	 */
	public String getProductCode() {
		return productCode;
	}

	/**
	 * @return the quantity
	 */
	public int getQuantity() {
		return quantity;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}

	public abstract String getName();

	public abstract Address getAddress();

	public abstract String getDateTime();
}
