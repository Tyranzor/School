package containers;

public class EquipmentRental extends Asset {

	private String name;
	double subtotal;

	/**
	 * @param name
	 */
	public EquipmentRental(String productCode, String identifier, double cost, String name) {
		super(productCode, "R", cost);
		this.name = name;
		// TODO Auto-generated constructor stub
	}

	public EquipmentRental(String productCode, String identifier, double cost, String name, int quantity,
			double subtotal) {
		super(productCode, "R", cost);
		this.name = name;
		this.quantity = quantity;

		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the name
	 */
	@Override
	public String getName() {
		return name;
	}

	@Override
	public double getTax() {
		return this.getCost() * .04;
	}

	@Override
	public double getDiscount() {

		return 0;
	}

	@Override
	public Address getAddress() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getDateTime() {
		return null;
	}

}
