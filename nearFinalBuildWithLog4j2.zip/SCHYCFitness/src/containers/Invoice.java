package containers;

import java.util.ArrayList;

public class Invoice {

	private String invoiceCode;
	private Member memberName;
	private Person personalTrainer;
	private String date;
	private ArrayList<Asset> products;
	private boolean isStudent = false;
	private double subtotal;
	private double tax;
	private double total;
	private double discount;

	/**
	 * @return the tax
	 */
	public double getTax() {
		return tax;
	}

	/**
	 * @param tax
	 *            the tax to set
	 */
	public void setTax(double tax) {
		this.tax = tax;
	}

	/**
	 * @return the total
	 */
	public double getTotal() {
		return total;
	}

	/**
	 * @param total
	 *            the total to set
	 */
	public void setTotal(double total) {
		this.total = total;
	}

	/**
	 * @param subtotal
	 *            the subtotal to set
	 */
	public void setSubtotal(double subtotal) {
		this.subtotal = subtotal;
	}

	public String getInvoiceCode() {
		return invoiceCode;
	}

	public Member getMemberCode() {
		return memberName;
	}

	public Person getPersonalTrainer() {
		return personalTrainer;
	}

	public String getDate() {
		return date;
	}

	public ArrayList<Asset> getProducts() {
		return products;
	}

	public boolean isStudent() {
		return isStudent;
	}

	public double getSubtotal() {
		return subtotal;
	}

	public void setSubtotal() {
		for (Asset a : products) {
			subtotal = subtotal + a.getCost() * a.getQuantity();
		}

	}

	public Invoice(String invoiceCode, Member memberName, Person personalTrainer, String date,
			ArrayList<Asset> products, boolean isStudent) {

		this.invoiceCode = invoiceCode;
		this.memberName = memberName;
		this.personalTrainer = personalTrainer;
		this.date = date;
		this.products = (ArrayList<Asset>) products.clone();
		this.isStudent = isStudent;
	}

	/**
	 * @param discount
	 *            the discount to set
	 */
	public void setDiscount(double discount) {
		this.discount = discount;
	}

	/**
	 * @return the memberName
	 */
	public Member getMemberName() {
		return memberName;
	}

	/**
	 * @return the discount
	 */
	public double getDiscount() {
		return discount;
	}

	public void setIsStudent(boolean check) {
		this.isStudent = check;
	}

}
