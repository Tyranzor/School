package containers;

public class Member {

	private String type;
	private String memberCode;
	private Person primaryContact;
	private String name;
	private Address address;

	// Member constructor
	public Member(String type, String memberCode, Person primaryContact, String name, Address address) {
		super();
		this.type = type;
		this.memberCode = memberCode;
		this.primaryContact = primaryContact;
		this.name = name;
		this.address = address;
	}

	// Getter methods
	public String getType() {
		return type;
	}

	public String getMemberCode() {
		return memberCode;
	}

	public Person getPrimaryContact() {
		return primaryContact;
	}

	public String getName() {
		return name;
	}

	public Address getAddress() {
		return address;
	}

	@Override
	public String toString() {
		return this.name + ", " + this.memberCode;
	}
}
