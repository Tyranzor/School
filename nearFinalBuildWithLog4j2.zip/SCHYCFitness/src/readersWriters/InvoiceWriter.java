package readersWriters;

import java.util.ArrayList;

import containers.Address;
import containers.Asset;
import containers.DayMembership;
import containers.EquipmentRental;
import containers.Invoice;
import containers.ParkingPass;
import containers.YearLongMembership;

public class InvoiceWriter {
	private static InvoiceReader read = new InvoiceReader();
	private static DatabaseReader dbr = new DatabaseReader();

	public static void writeInvoices(ArrayList<Invoice> invoices) {

		String s;
		double fees = 0;
		double discount = 0;
		double totalSubtotal = 0;
		double totalFees = 0;
		double totalTaxes = 0;
		double totalDiscount = 0;
		double totalTotal = 0;
		System.out.println("Executive Summary Report");
		System.out.println("========================");
		System.out.printf("%s %9s %50s %22s %8s %13s %15s %10s", "Invoice", "Member", "Personal Trainer", "Subtotal",
				"Fees", "Taxes", "Discount", "Total\n");
		for (Invoice i : invoices) {
			i.setIsStudent(false);
			for (Asset flag : i.getProducts()) {
				if (flag instanceof YearLongMembership)
					i.setIsStudent(true);
			}
			discount = 0;
			i.setSubtotal();

			if (i.isStudent()) {
				s = "[Student]";
				fees = 10.50;
				discount = discount + (i.getSubtotal() * .08);
			} else {
				s = "[General]";
				fees = 0;
			}
			boolean isYear = false;
			for (Asset a : i.getProducts()) {
				isYear = true;
			}

			for (Asset a : i.getProducts()) {
				if (a instanceof YearLongMembership) {
					i.setIsStudent(true);
					YearLongMembership y;
					y = (YearLongMembership) a;
					String dateTest = a.getDateTime();

					if (dateTest.charAt(5) == '0' && dateTest.charAt(6) == '1') {
						discount = discount + ((y.getCost() * .15) * y.getQuantity());

					}

					if (a instanceof ParkingPass && i.isStudent() == true) {
						a.setCost(0);
					}
					if (a instanceof EquipmentRental && i.isStudent() == true) {
						discount = discount + ((a.getCost() * .05) * a.getQuantity());

					}

				}
				if (a instanceof DayMembership) {
					String dateTest = a.getDateTime();

					if (dateTest.charAt(5) == '0' && dateTest.charAt(6) == '1') {
						discount = discount + ((a.getCost() * .5) * a.getQuantity());

					}
				}

				i.setTax(i.getTax() + (a.getTax() * a.getQuantity()));
				discount = discount + a.getDiscount();

				i.setDiscount(discount);

			}

			System.out.printf("%-10s %-40s %-30s %s %-10.2f %s %-10.2f %s %-10.2f %s %-10.2f %s %-10.2f",
					i.getInvoiceCode(), i.getMemberName().getName() + " " + s, i.getPersonalTrainer().getName(), "$",
					i.getSubtotal(), "$", fees, "$", i.getTax(), "$", i.getDiscount(), "$",
					(i.getSubtotal() + fees + i.getTax() - discount));
			System.out.println("");
			totalSubtotal = totalSubtotal + i.getSubtotal();
			totalFees = totalFees + fees;
			totalTaxes = totalTaxes + i.getTax();
			totalDiscount = totalDiscount + i.getDiscount();
			totalTotal = totalTotal + (i.getSubtotal() + fees + i.getTax() - discount);
		}
		System.out.println("============================================================================"
				+ "=========================================================================");
		System.out.printf("%s %77s %.2f %3s %.2f %6s %.2f %6s %.2f %5s %.2f %s", "TOTALS", "$", totalSubtotal, "$",
				totalFees, "$", totalTaxes, "$", totalDiscount, "$", totalTotal, "\n");
		System.out.println("\nIndividual Invoice Detail Reports");
		System.out.println("==================================================");
		for (Invoice i : invoices) {
			i.setIsStudent(false);
			for (Asset flag : i.getProducts()) {
				if (flag instanceof YearLongMembership)
					i.setIsStudent(true);
			}

			String membershipCode = null;
			if (i.getProducts().get(0) instanceof DayMembership
					|| i.getProducts().get(0) instanceof YearLongMembership) {
				membershipCode = i.getProducts().get(0).getProductCode();
			}

			discount = 0;
			i.setSubtotal();

			if (i.isStudent()) {
				s = "[Student]";
				fees = 10.50;
				discount = discount + (i.getSubtotal() * .08);
			} else {
				s = "[General]";
				fees = 0;
			}

			System.out.println("Invoice " + i.getInvoiceCode());
			System.out.println("========================");
			System.out.println("Personal Trainer: " + i.getPersonalTrainer().getLastName() + ", "
					+ i.getPersonalTrainer().getFirstName());
			System.out.println("Member Info:");
			System.out.println(i.getMemberName().getName() + " (" + i.getMemberCode() + ")");
			System.out.println(s);
			System.out.println(i.getMemberName().getAddress().toString());
			System.out.println("-------------------------------------------");
			System.out.printf("%-8s %-60s %-18s %-15s %s %s", "Code", "Item", "SubTotal", "Tax", "Total", "\n");

			for (Asset a : i.getProducts()) {
				System.out.println(i.isStudent());
				String productName = null;
				Address address = null;
				String date = null;

				double assetDiscount = 0;

				if (a instanceof YearLongMembership) {

					YearLongMembership y;
					y = (YearLongMembership) a;
					String dateTest = y.getStartDate();

					if (dateTest.charAt(5) == '0' && dateTest.charAt(6) == '1') {
						assetDiscount = ((y.getCost() * .15) * y.getQuantity());
						y.setCost(y.getCost() * .85);

					}
				}

				if (a instanceof ParkingPass && i.isStudent() != false) {

					a.setCost(0);
				}
				if (a instanceof EquipmentRental && i.isStudent() != false) {
					assetDiscount = ((a.getCost() * .05) * a.getQuantity());
					a.setCost(a.getCost() - (a.getCost() * .05));

				}

				else if (a instanceof DayMembership) {
					DayMembership d;
					d = (DayMembership) a;
					String dateTest = a.getDateTime();

					if (dateTest.charAt(5) == '0' && dateTest.charAt(6) == '1') {
						assetDiscount = ((d.getCost() * .5) * d.getQuantity());
						d.setCost(d.getCost() - (d.getCost() * .5));

					}
				}

				i.setTax(i.getTax() + a.getTax());
				discount = discount + a.getDiscount();
				i.setDiscount(discount);
				if (a.getName() == null) {
					if (a.getIdentifier().equalsIgnoreCase("D")) {
						productName = "Day-long membership";
						address = a.getAddress();
						date = a.getDateTime();
					} else if (a.getIdentifier().equalsIgnoreCase("Y")) {
						productName = "Year-long membership";
						address = a.getAddress();
						date = a.getDateTime();

					} else if (a.getIdentifier().equalsIgnoreCase("P")) {
						productName = "Parking Pass";
					}

				} else {
					productName = a.getName();
				}

				// Print a Day or Year Membership in a neatly formatted fashion
				if (a.getIdentifier().equalsIgnoreCase("D") || a.getIdentifier().equalsIgnoreCase("Y")) {
					System.out.printf("%-8s %-60s %-1s %-16.2f %s %-13.2f %s %.2f %-9s %s %s %s %.2f %s",
							a.getProductCode(), productName + " @ " + address.getStreet().toString(), "$",
							a.getCost() * a.getQuantity(), "$", a.getTax() * a.getQuantity(), "$",
							(a.getCost() * a.getQuantity() + a.getTax() * a.getQuantity()), "\n", date, "(",
							a.getQuantity() + " units @ $", +a.getCost(), ")");
					System.out.println("\n");
				}
				// Print a Parking Pass or Rental without a membership attached
				// in a neatly formatted fashion
				else if ((a.getIdentifier().equalsIgnoreCase("P") || a.getIdentifier().equalsIgnoreCase("R"))
						&& membershipCode == null) {
					System.out.printf("%-8s %-1s %-1s %-1d %-1s %-1s %.2f %-26s %s %-16.2f %s %.2f %10s %.2f",
							a.getProductCode(), productName, "(", a.getQuantity(), "units @", "$", a.getCost(), ")",
							"$", a.getCost() * a.getQuantity(), "$", a.getTax() * a.getQuantity(), "$",
							(a.getCost() * a.getQuantity() + a.getTax() * a.getQuantity()));
					System.out.println("\n");
				}
				// Print a Parking Pass or Rental with a membership attached in
				// a neatly formatted fashion
				else if (a.getIdentifier().equalsIgnoreCase("P") || a.getIdentifier().equalsIgnoreCase("R")) {
					System.out.printf("%-8s %-1s %-1s %-1s %-1d %-1s %.2f %-22s %s %-7.2f %10s %.2f %10s %.2f",
							a.getProductCode(), productName, membershipCode, "(", a.getQuantity(), "units @ $",
							a.getCost(), ")", "$", a.getCost() * a.getQuantity(), "$", a.getTax() * a.getQuantity(),
							"$", (a.getCost() * a.getQuantity() + a.getTax() * a.getQuantity()));
					System.out.println("\n");
				}

			}

			System.out.println("Thank you for your purchase!\n");

		}

	}

}