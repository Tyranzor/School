package readersWriters;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.*;
import containers.*;
public class AssetReader {
	
	private static ArrayList<YearLongMembership> yearList= new ArrayList<YearLongMembership>();
	private static ArrayList<DayMembership> dayList= new ArrayList<DayMembership>();
	private static ArrayList<EquipmentRental> equipList= new ArrayList<EquipmentRental>();
	private static ArrayList<ParkingPass> parkList= new ArrayList<ParkingPass>();
	
	private static void ReadAssets () {
		yearList.clear();
		dayList.clear();
		equipList.clear();
		parkList.clear();
		
		ArrayList<String> strings= new ArrayList<String>();
		
		try { 
			BufferedReader in = new BufferedReader(new FileReader("data/Products.dat"));
			in.readLine();
			
		
		String str;
		
		while((str = in.readLine()) != null){
		    strings.add(str);
			}
		in.close();
		}
		catch (Exception e){ e.printStackTrace();
		System.out.println("you done fucked up now");
	}
		
		for (String s:strings){
			String data []= s.split("[;]");
			
			if (data[1].equalsIgnoreCase("Y")){
				
				String address []=data[4].split("[,]");
				Address a= new Address (address[0],address[1],address[2],address[4],address[3]);
				YearLongMembership y= new YearLongMembership (data[0],"Y",Double.parseDouble(data[6]),data[2],data[3],a,data[5]);
				yearList.add(y);
			}
			
			else if (data[1].equalsIgnoreCase("R")){
				
				EquipmentRental r= new EquipmentRental (data[0],"R",Double.parseDouble(data[3]), data[2]);
				equipList.add(r);
			}
			
			else if (data[1].equalsIgnoreCase("D")){

				String address []=data[3].split("[,]");
				Address a= new Address (address[0],address[1],address[2],address[4],address[3]);
				DayMembership d= new DayMembership(data[0],"D",Double.parseDouble(data[4]), a,data[2]);
				dayList.add(d);
			}
			
			else if (data[1].equalsIgnoreCase("P")){

				ParkingPass p= new ParkingPass(data[0],"P", Double.parseDouble(data[2]));
				parkList.add(p);
				
			}
			
		}
		
	}
	
	/**
	 * @return the yearList
	 */
	public static ArrayList<YearLongMembership> getYearList() {
		ReadAssets();
		return yearList;
	}
	
	/**
	 * @return the dayList
	 */
	public static ArrayList<DayMembership> getDayList() {
		ReadAssets();
		return dayList;
	}
	
	/**
	 * @return the equipList
	 */
	public static ArrayList<EquipmentRental> getEquipList() {
		ReadAssets();
		return equipList;
	}
	
	/**
	 * @return the parkList
	 */
	public static ArrayList<ParkingPass> getParkList() {
		ReadAssets();
		return parkList;
	}
	
}


