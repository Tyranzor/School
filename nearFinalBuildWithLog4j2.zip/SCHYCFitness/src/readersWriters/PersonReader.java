package readersWriters;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.*;
import containers.Address;
import containers.Person;
public class PersonReader {
	private static ArrayList<Person> personList= new ArrayList<Person>();
	
	private static void ReadPersons(){
		
	
	try { 
		BufferedReader in = new BufferedReader(new FileReader("data/Persons.dat"));
		in.readLine();
		
	ArrayList<String> strings= new ArrayList<String>();
	String str;
	
	while((str = in.readLine()) != null){
	    strings.add(str);
	}
		
		for (String s: strings){

			String personCode;
			String name;
	String fullAddress;
		String emails = null;
			String lastName;
			String firstName;
			String street;
			String city;
			String state;
			String zip;
			String country;
		
		 String data[] = s.split("[;]"); 
		personCode= data[0];
		name=data[1];
		fullAddress= data[2];
		
		if(data.length>3){				
			emails=data[3];
		}
		
		else if(data.length<=3)  {}
		
		
		 String [] splits=name.split("[,]");
		 lastName= splits[0];
		 firstName= splits[1];		  
		 splits= fullAddress.split("[,]");		 
		 street=splits[0];
		 city=splits[1];
		 state=splits[2];
		 zip=splits[3];
		 country=splits[4];
		 
		 Address address= new Address (street, city, state, country,zip);
		 
		 if(data.length>3){				
				Person newPerson= new Person (lastName, personCode, emails, address, firstName);
				personList.add(newPerson);
			}
		 else if(data.length<=3)  {
			 Person newPerson= new Person (lastName, personCode, address, firstName);
			 personList.add(newPerson);
		 }


		}
		
	in.close();
	}
	catch (Exception e){ e.printStackTrace();
		System.out.println("you done fucked up now");
	}
	

	}
	public static ArrayList<Person> getPersonList() {
		ReadPersons();
		return personList;
	}
}