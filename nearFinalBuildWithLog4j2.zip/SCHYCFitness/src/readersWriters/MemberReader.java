package readersWriters;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.*;
import containers.*;

public class MemberReader {
	
	//Create the reader to read in the persons for primary contacts
	protected static PersonReader readP= new PersonReader();
	
	//Create the array lists needed to store the members and persons
	private static ArrayList<Member> memberList= new ArrayList<Member>();
	private static ArrayList<Person> personList = new ArrayList<Person>();
	
	private static void ReadMembers(){
		
		//Fill the person list with each person so that it can be used later for primary contacts
		personList= readP.getPersonList();
		
		//Create a new array list to store strings
		ArrayList<String> strings= new ArrayList<String>();
		
		try { 
			
			//Create the reader object to read in each line of the Members.dat file
			BufferedReader in = new BufferedReader(new FileReader("data/Members.dat"));
			in.readLine();
		
			String str;
			
			//Continuously read in each line until no more lines exist
			while((str = in.readLine()) != null){
				if (str.length()>0){
					strings.add(str);
				}
			}
			
			//Close the reader object
			in.close();
		
		}
		catch (Exception e){ e.printStackTrace();
		System.out.println("error, file not found");
	}

		//Split each line into its components
		for (String s: strings){
			String data []= s.split("[;]");
			Person p = null;
			String line=data[4];
			String address []=line.split("[,]");
			
			//Call the address constructor
			Address a= new Address (address[0],address[1],address[2],address[4],address[3]);
				
				//Match each primary contact person code to its respective person
				for (Person pers:personList){
					if (data[2].contentEquals(pers.getPersonCode())){
						p=pers;
					}
				}
				
				//Call the member constructor
				Member m= new Member(data[1],data[0],p,data[3],a);
				memberList.add(m);
			
		}
	}

	//Getter method
	public static ArrayList<Member> getMemberList() {
		ReadMembers();
		return memberList;
	}
}