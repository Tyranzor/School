package readersWriters;
import readersWriters.*;
import containers.*;
import java.util.*;
public class AssetMasterList {
 
	 protected static AssetReader readA= new AssetReader();
	 
	 public static ArrayList<Asset> readAssets(){
		 ArrayList<YearLongMembership> yearList= new ArrayList<YearLongMembership>();
			ArrayList<DayMembership> dayList= new ArrayList<DayMembership>();
			ArrayList<EquipmentRental> equipList= new ArrayList<EquipmentRental>();
			ArrayList<ParkingPass> parkList= new ArrayList<ParkingPass>();
			ArrayList<Asset> masterAsset= new ArrayList<Asset>();
			
			yearList=readA.getYearList();
			dayList= readA.getDayList();
			equipList= readA.getEquipList();
			parkList= readA.getParkList();
			
			//Combine all the asset subclass lists into one master asset list
			for (YearLongMembership y:yearList ){
				masterAsset.add(y);
			}
			for (DayMembership y:dayList ){
				masterAsset.add(y);
			}
			for (EquipmentRental y:equipList ){
				masterAsset.add(y);
			}
			for (ParkingPass y:parkList ){
				masterAsset.add(y);
			}
			return masterAsset;
	 }
		
}
