package readersWriters;

import readersWriters.*;
import containers.*;
import java.util.*;

public class DataConverter {
 
 //Create the reader and writer objects needed for each data type
 protected static PersonReader readP= new PersonReader();
 protected static AssetMasterList list= new AssetMasterList();
 protected static MemberReader readM= new MemberReader();
 private static JSONWriter jWrite= new JSONWriter();
 private static XMLWriter xmlWrite= new XMLWriter();
 protected static InvoiceWriter iWrite= new InvoiceWriter();
 
	public static void main(String[] args) {
		
		//Create array lists to store each data type
		ArrayList<Person> personList = new ArrayList<Person>();
		ArrayList<Member> memberList= new ArrayList<Member>();
		ArrayList<Asset> masterAsset= list.readAssets();
		
		//Populate each array list by using getter methods
		personList= PersonReader.getPersonList();
		memberList= readM.getMemberList();
		
		
		
		
		//Convert each list into a neatly formatted output type
		jWrite.JSONConverter(masterAsset, "data/Products.json");
		jWrite.JSONConverter(memberList, "data/Members.json");
		jWrite.JSONConverter(personList, "data/Persons.json");
		xmlWrite.xmlConverter(masterAsset, "data/Products.xml");
		xmlWrite.xmlConverter(memberList, "data/Members.xml");
		xmlWrite.xmlConverter(personList, "data/Persons.xml");
		iWrite.writeInvoices();
	}

}