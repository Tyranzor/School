/**
 * 
 */
package readersWriters;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 * @author Nathan P with assistance from Jonathan Trost
 * SQLFactory provides methods to take sql query arguments and execute them as needed
 * includes executeUpdate for when a ResultSet is not necessary and executeQuery for when a ResultSet is necessary 
 * as well as an Execute method as a failsafe
 *
 */
public class SQLFactory {

	
	static Connection conn = null;
	static Statement stmt = null;
	
	//JDBC driver name and database URL
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	static final String DB_URL = "jdbc:mysql://cse.unl.edu:3306/jtrost";
	
	//Database login info
	static final String USER = "jtrost";
	static final String PASS = "YGVud5";
	/**
	 * executes a query which will not require a resultSet
	 * @param query should be proper SQL syntax before being passed 
	 */
	public void executeUpdate(String query) {
		 
		Statement stmt=null;
		Connection conn=null;
		try{
			
		    //STEP 2: Register JDBC driver 
		    Class.forName("com.mysql.jdbc.Driver");

		    //STEP 3: Open a connection
		    conn = DriverManager.getConnection(DB_URL,USER,PASS);

		    //STEP 4: Execute a query
		    stmt = conn.createStatement();
		    
		//retrieves customer type from customer code
		    String sql=query;
		     stmt.executeUpdate(sql);}
		catch (Exception e){
			e.printStackTrace();
		
		}
		
	}
	/**
	 * executes a query when a ResultSet is expected
	 * @param query should be proper SQL syntax before being passed
	 * @return 
	 */
	public ResultSet executeQuery(String query) {
		 
		Statement stmt=null;
		Connection conn=null;
		try{
			
		    //STEP 2: Register JDBC driver 
		    Class.forName("com.mysql.jdbc.Driver");

		    //STEP 3: Open a connection
		    conn = DriverManager.getConnection(DB_URL,USER,PASS);

		    //STEP 4: Execute a query
		    stmt = conn.createStatement();
		    ResultSet rs= null;
		//retrieves customer type from customer code
		    String sql=query;
		     rs= stmt.executeQuery(sql);
		     return rs;
		     }
		catch (Exception e){
			e.printStackTrace();
		
		}
		return null;
		
		
	}
	/**
	 * failsafe method 
	 * @param query should be proper SQL syntax before being passed
	 */
	public void execute(String query) {
		 
		Statement stmt=null;
		Connection conn=null;
		try{
			
		    //STEP 2: Register JDBC driver 
		    Class.forName("com.mysql.jdbc.Driver");

		    //STEP 3: Open a connection
		    conn = DriverManager.getConnection(DB_URL,USER,PASS);

		    //STEP 4: Execute a query
		    stmt = conn.createStatement();
		    
		//retrieves customer type from customer code
		    String sql=query;
		     stmt.execute(sql);}
		catch (Exception e){
			e.printStackTrace();
		
		}
		
	}

}
