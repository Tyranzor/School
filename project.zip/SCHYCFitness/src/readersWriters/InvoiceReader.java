package readersWriters;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.*;
import containers.*;

public class InvoiceReader {
	private static ArrayList<Invoice> invoiceList= new ArrayList<Invoice>();
	 protected static PersonReader readP= new PersonReader();
	 protected static MemberReader readM= new MemberReader();
	
	private static void readInvoices(){
		invoiceList.clear();
		
		AssetMasterList AML= new AssetMasterList();
		ArrayList<String> strings= new ArrayList<String>();
		ArrayList<Person> personList = new ArrayList<Person>();
		ArrayList<Member> memberList= new ArrayList<Member>();
		
		ArrayList<Asset>masterAsset= AML.readAssets();
		personList= PersonReader.getPersonList();
		memberList= readM.getMemberList();
		
		try { 
			BufferedReader in = new BufferedReader(new FileReader("data/Invoices.dat"));
			in.readLine();
			
		
		String str;
		
		while((str = in.readLine()) != null){
		    strings.add(str);
			}
		in.close();
		}
		
			catch (Exception e){ e.printStackTrace();
			System.out.println("you done fucked up now");
	

		}
		
		ArrayList<Asset> invoiceAssets= new ArrayList<Asset>();
		Member m = null;
		Person p = null;
		boolean student=false;
		String code = null;
		String date = null;
		
		
		
		for (String s:strings){

			student=false;
			invoiceAssets.clear();
			String data []= s.split("[;]");
			code=data[0];
		
			for (Member mem:memberList){
				if (mem.getMemberCode().contentEquals(data[1])){
					m=mem;
					if( mem.getType().equalsIgnoreCase("S")){
						student=true;
					}
				}
			}
			for (Person per:personList){
				if (per.getPersonCode().contentEquals(data[2])){
					
					p=per;
				}
			}
			
			date=data[3];
			
			String products []= data[4].split("[,]");
			 
			String[] productIdentifier;
			for (String pro: products){
				
				productIdentifier= pro.split("[:]");
				
	
					for(Asset a: masterAsset){
						
					
						if(a.getCode().contentEquals(productIdentifier[0])){
							invoiceAssets.add(a);
							a.setQuantity(Integer.parseInt(productIdentifier[1]));
							
						}
						
					}
				
			}
			
			
			Invoice i= new Invoice(code, m,p,date, invoiceAssets, student);
			invoiceList.add(i);
			}
		
		

			
		
		
	}
	public static ArrayList<Invoice> getInvoices(){
		readInvoices();
		return invoiceList;
	}

}
