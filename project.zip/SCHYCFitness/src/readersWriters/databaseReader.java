/**
 *
 */
package readersWriters;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import containers.Address;
import containers.Asset;
import containers.DayMembership;
import containers.EquipmentRental;
import containers.Invoice;
import containers.Member;
import containers.ParkingPass;
import containers.Person;
import containers.YearLongMembership;
import log4j.log4j;

public class databaseReader {

	private static ArrayList<Invoice> invoiceList = new ArrayList<Invoice>();
	private static ArrayList<Person> personList = new ArrayList<Person>();
	private static ArrayList<Member> memberList = new ArrayList<Member>();
	private static Multimap<Integer, Address> addressList = new Multimap<Integer, Address>();
	private static HashMap<String, Asset> assetMap = new HashMap<String, Asset>();
	private static log4j errorLogger = new log4j();
	private static SQLFactory fact = new SQLFactory();

	/**
	 * processes data from the database based on the returned results from
	 * subsequent methods
	 */

	public databaseReader() {

	}

	public static ResultSet getTable(String tableName) {

		String sql = "SELECT * FROM " + tableName;
		ResultSet rs = fact.executeQuery(sql);
		return rs;
	}

	public static ArrayList<Person> getPersons() throws SQLException {
		ResultSet persons = getTable("Person");
		getAddress();
		Address a = null;
		while (persons.next()) {

			for (Integer i : addressList.keySet()) {
				if ((persons.getInt("address")) == 1) {
					a = addressList.get(i);
					;
				}
			}

			if (persons.getString("emails") != null) {
				Person p = new Person(persons.getString("lastName"), persons.getString("personCode"),
						persons.getString("emails"), a, persons.getString("firstName"));
				personList.add(p);
			} else {
				Person p = new Person(persons.getString("lastName"), persons.getString("personCode"), a,
						persons.getString("firstName"));
				personList.add(p);

			}
		}
		return personList;
	}

	/**
	 * retrieves all address data from database and builds appopriate objects
	 *
	 * @throws SQLException
	 */
	public static void getAddress() throws SQLException {

		ResultSet addresses = getTable("Address");
		while (addresses.next()) {
			Address a = new Address(addresses.getString("street"), addresses.getString("city"),
					addresses.getString("state"), addresses.getString("country"), addresses.getString("zip"));
			addressList.put(addresses.getInt("ID"), a);
		}
	}

	public static ArrayList<Member> getMembers() throws SQLException {
		ResultSet members = getTable("Member");
		Address a = null;
		Person trainer = null;
		while (members.next()) {

			for (Integer i : addressList.keySet()) {
				if ((members.getInt("address")) == 1) {
					a = addressList.get(i);

				}
			}

			for (Person P : personList) {
				if (members.getString("person").contentEquals(P.getPersonCode())) {
					trainer = P;
				}
			}
			Member m = new Member(members.getString("memType"), members.getString("memberCode"), trainer,
					members.getString("memName"), a);
			memberList.add(m);

		}
		return memberList;
	}

	// TODO USE <INT,ADDRESS> HASHMAP IN ADDRESS TABLE, PROCESS THAT HASHMAP
	// WITH INT RETURNS IN OTHER METHODS
	public static ArrayList<Invoice> getInvoices() throws SQLException {
		getAddress();
		getPersons();
		getMembers();
		boolean isStudent;
		ParkingPass p = null;
		EquipmentRental r = null;
		DayMembership d = null;
		YearLongMembership y = null;
		Invoice inv = null;
		Address a = null;
		ArrayList<Asset> aList = new ArrayList<Asset>();
		Member mem = null;
		Person train = null;

		ResultSet rs = getTable("ParkingPass");
		while (rs.next()) {

			/**
			 *
			 */
			p = new ParkingPass(rs.getString("productCode"), "P",
					(rs.getDouble("subtotal") / rs.getDouble("quantity")));
			assetMap.put(rs.getString("invoiceCode"), p);
			System.out.println(assetMap.size() + "P");

		}

		rs = getTable("EquipmentRental");
		while (rs.next()) {
			r = new EquipmentRental(rs.getString("productCode"), "R",
					(rs.getDouble("subtotal") / rs.getDouble("quantity")), rs.getString("rentalName"));
			assetMap.put(rs.getString("invoiceCode"), r);
			System.out.println(assetMap.size() + "R");

		}

		rs = getTable("DayMembership");
		while (rs.next()) {

			for (Integer i : addressList.keySet()) {
				if ((rs.getInt("address")) == 1) {
					a = addressList.get(i);

				}
			}

			d = new DayMembership(rs.getString("productCode"), "D",
					(rs.getDouble("subtotal") / rs.getDouble("quantity")), a, rs.getString("timeDate"));
			assetMap.put(rs.getString("invoiceCode"), d);
			System.out.println(assetMap.size() + "D");

		}

		rs = getTable("YearMembership");
		while (rs.next()) {

			for (Integer i : addressList.keySet()) {
				if ((rs.getInt("address")) == 1) {
					a = addressList.get(i);

				}
			}

			y = new YearLongMembership(rs.getString("productCode"), "Y",
					(rs.getDouble("subtotal") / rs.getDouble("quantity")), rs.getString("timeDateStart"),
					rs.getString("timeDateEnd"), a, rs.getString("membershipName"));
			assetMap.put(rs.getString("invoiceCode"), y);
			System.out.println(assetMap.size() + "Y");

		}

		rs = getTable("Invoice");
		while (rs.next()) {
			System.out.println(assetMap.size());
			System.out.println(rs.getString("invoiceCode"));
			for (String k : assetMap.keySet()) {
				System.out.println(k);
				if (k.contentEquals(rs.getString("invoiceCode"))) {
					aList.add(assetMap.get(k));
				}
			}
			ResultSet bool = fact.executeQuery(
					"Select memType from Member where memberCode like '" + rs.getString("memberCode") + "';");
			if (bool.getString("memType").equalsIgnoreCase("s")) {
				isStudent = true;
			} else {
				isStudent = false;
			}
			for (Member m : memberList) {
				if (m.getName().contentEquals(rs.getString("member"))) {
					mem = m;
				}
			}
			for (Person pt : personList) {
				if (pt.getName().contentEquals(rs.getString("personalTrainer"))) {
					train = pt;
				}
			}

			inv = new Invoice(rs.getString("invoiceCode"), mem, train, rs.getString("timeDate"), aList, isStudent);
			invoiceList.add(inv);
		}
		return invoiceList;

	}
}
