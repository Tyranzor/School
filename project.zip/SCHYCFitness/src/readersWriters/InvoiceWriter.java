package readersWriters;
import java.util.ArrayList;

import containers.*;
public class InvoiceWriter {
	 private static InvoiceReader read= new InvoiceReader();
	 public static void writeInvoices(){
		 ArrayList<Invoice> invoices= read.getInvoices();
		 String s;
		 double fees=0;
		 double discount=0;
		for(Invoice i: invoices){
			discount=0;
			i.setSubtotal();
			if (i.isStudent()){
				s="[Student]";
				fees=10.50;
				discount= discount+(i.getSubtotal()*.08);
			}
			else {
				s= "[General]";
				fees=0;
			}
			
			
			for(Asset a: i.getProducts()){
				i.setTax(i.getTax()+a.getTax());
				discount=discount+a.getDiscount();
				i.setDiscount(discount);
				
			}
			
			System.out.printf("%-10s %-40s  %-30s %-10f %-10f %-10f %-10f %-10f", i.getInvoiceCode(), 
					i.getMemberCode().getName()+" "+s,  i.getPersonalTrainer().getName(), i.getSubtotal(),fees , i.getTax(), 
					i.getDiscount(), (i.getSubtotal()+fees+i.getTax()-discount) );
			System.out.println("");
		}
		 
	 }

}