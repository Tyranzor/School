package containers;

public class DayMembership extends Asset {
	
	private Address address;
	private String dateTime;
	/**
	 * 
	 * @param productCode
	 * @param identifier
	 * @param cost
	 * @param address
	 * @param dateTime
	 */
	public DayMembership(String productCode, String identifier, double cost, Address address, String dateTime) {
		super(productCode, "D", cost);
		this.address=address;
		this.dateTime=dateTime;
		// TODO Auto-generated constructor stub
	}
	/**
	 * 
	 * @return the address of the membership
	 */
	public Address getAddress() {
		return address;
	}
	/**
	 * 
	 * @return the date time of the membership
	 */
	public String getDateTime() {
		return dateTime;
	}
	@Override
	public double getTax() {
		
		return this.getCost()*.06;
		
	}
	public double getDiscount(){
		char[] array= this.getDateTime().toCharArray();
		if(array[6]==0&&array[7]==1){
			return this.cost*.5;
		}
		return 0;
	}
	
}
