package containers;

public class ParkingPass extends Asset{
/**
 * 
 * @param productCode
 * @param identifier
 * @param cost
 */
	public ParkingPass(String productCode, String identifier, double cost) {
		super(productCode, "P", cost);
		// TODO Auto-generated constructor stub
	}

@Override
public double getTax() {
	return this.getCost()*.04;
}
public double getDiscount(){
	
	return 0;
}
}
