package containers;

public class ParkingPass extends Asset {
	/**
	 * 
	 * @param productCode
	 * @param identifier
	 * @param cost
	 */
	public ParkingPass(String productCode, String identifier, double cost) {
		super(productCode, "P", cost);
		// TODO Auto-generated constructor stub
	}

	@Override
	public double getTax() {
		return this.getCost() * .04;
	}

	@Override
	public double getDiscount() {

		return 0;
	}

	@Override
	public String getName() {
		return null;
	}

	@Override
	public Address getAddress() {
		return null;
	}

	@Override
	public String getDateTime() {
		return null;
	}

}
