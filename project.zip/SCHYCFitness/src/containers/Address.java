package containers;

public class Address extends Object {
	private String street;
	private String city;
	private String state;
	private String country;
	private String zip;
	/**
	 * 
	 * @param street
	 * @param city
	 * @param state
	 * @param country
	 * @param zip
	 */
	public Address(String street, String city, String state, String country, String zip) {
		super();
		this.street = street;
		this.city = city;
		this.state = state;
		this.country = country;
		this.zip = zip;
	}
/**
 * 
 * @return street
 */
	public String getStreet() {
		return street;
	}
	/**]
	 * 
	 * @return city
	 */
	public String getCity() {
		return city;
	}
	/**
	 * 
	 * @return state
	 */
	public String getState() {
		return state;
	}
	/**
	 * 
	 * @return country
	 */
	public String getCountry() {
		return country;
	}
	/**
	 * 
	 * @return zip
	 */
	public String getZip() {
		return zip;
	}
	
}
