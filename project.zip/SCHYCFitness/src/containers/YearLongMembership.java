package containers;

public class YearLongMembership extends Asset {
private String startDate;
private String endDate;
private Address address;
private String membershipName;
/**
 * @param productCode
 * @param identifier
 * @param cost
 * @param startDate
 * @param endDate
 * @param address
 * @param membershipName
 */
public YearLongMembership(String productCode, String identifier, double cost, String startDate, String endDate,
		Address address, String membershipName) {
	super(productCode, "Y", cost);
	this.startDate = startDate;
	this.endDate = endDate;
	this.address = address;
	this.membershipName = membershipName;
}
/**
 * @return the startDate
 */
public String getStartDate() {
	return startDate;
}
/**
 * @return the endDate
 */
public String getEndDate() {
	return endDate;
}
/**
 * @return the address
 */
public Address getAddress() {
	return address;
}
/**
 * @return the membershipName
 */
public String getMembershipName() {
	return membershipName;
}
@Override
public double getTax() {
	return this.getCost()*.06;
}
public double getDiscount(){
	char[] array= this.getStartDate().toCharArray();
	if(array[6]==0&&array[7]==1){
		return this.cost*.15;
	}
	return 0;
}
}
