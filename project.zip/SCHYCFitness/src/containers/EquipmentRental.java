package containers;

public class EquipmentRental extends Asset{


private String name;

/**
 * @param name
 */
public EquipmentRental(String productCode, String identifier, double cost, String name) {
	super(productCode, "R", cost);
	this.name=name;
	// TODO Auto-generated constructor stub
}

/**
 * @return the name
 */
public String getName() {
	return name;
}

@Override
public double getTax() {
	return this.getCost()*.04;
}
public double getDiscount(){
	
	return 0;
}

}
