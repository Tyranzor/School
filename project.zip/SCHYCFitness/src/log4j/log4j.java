package log4j;
import java.util.logging.LogManager;
import java.util.logging.Logger;

import org.apache.logging.log4j.*;

import readersWriters.MemberReader;
import readersWriters.databaseReader;
public class log4j {

	public log4j() {
		//Logger Logger = LogManager.getLogger("log4j.java");
		
	}
	public static void log (Exception error){
		System.out.println("Error logged");
		
	}

}
