package unl.cse.labs.lab02.lab02_code;

import org.joda.time.DateTime;
import org.joda.time.Interval;
import org.joda.time.Period;

public class Birthday {

	public static void main(String args[]) {
		
		String name = "Java";
		
		int month = 2;
		int date  = 4;
		int year  = 1994;

		DateTime bday = new DateTime(year, month, date, 0, 0);
		DateTime today = new DateTime(2018, 1, 17,0,0);

		Period age = new Period(bday, today);
		
		int years = age.getYears();
		int months = age.getMonths();
		int days = age.getWeeks() * 7 + age.getDays();

		DateTime next_bday = new DateTime(year + years + 1, month, date, 0, 0);
		Interval days_to_next_bday_i = new Interval(today, next_bday);
		double days_remaining = days_to_next_bday_i.toDurationMillis() / (1000 * 60 * 60 * 24) + 1;
		

		//TODO: write code to output results here
		System.out.println("Greetings "+name+" as of today you are " +years+" years old "+months+" months old "+days+" days old!");
		System.out.println("There are "+days_remaining+" until your next birthday");
		if (days_remaining>364){
			System.out.println("Happy birthday "+name+" !");
		}
	}
}
