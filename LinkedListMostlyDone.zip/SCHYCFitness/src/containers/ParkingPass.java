package containers;

public class ParkingPass extends Asset {
	/**
	 *
	 * @param productCode
	 * @param identifier
	 * @param cost
	 */
	double subtotal;
	double discount;

	public ParkingPass(String productCode, String identifier, double cost) {
		super(productCode, "P", cost);
		// TODO Auto-generated constructor stub
	}

	public ParkingPass(String productCode, String identifier, double cost, double discount, double subtotal,
			int quantity) {
		super(productCode, "P", cost);
		this.quantity = quantity;
		this.subtotal = subtotal;
		this.discount = discount;

	}

	@Override
	public double getTax() {
		return this.getCost() * .04;
	}

	@Override
	public double getDiscount() {

		return discount;
	}

	@Override
	public String getName() {
		return null;
	}

	@Override
	public Address getAddress() {
		return null;
	}

	@Override
	public String getDateTime() {
		return null;
	}

}
