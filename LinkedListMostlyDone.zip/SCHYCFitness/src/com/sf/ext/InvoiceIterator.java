package com.sf.ext;

import java.util.Iterator;

import containers.Invoice;

public class InvoiceIterator implements Iterator<Invoice> {
	InvoiceNode current;

	public InvoiceIterator(InvoiceNode node) {
		this.current = node;
	}

	@Override
	public boolean hasNext() {
		if (current.getNext() == null) {
			return false;
		} else {
			return true;
		}

	}

	@Override
	public Invoice next() {
		Invoice returnvalue = current.getInvoice();
		current = current.getNext();
		return returnvalue;
	}

}