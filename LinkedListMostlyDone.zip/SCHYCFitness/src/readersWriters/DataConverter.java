package readersWriters;

import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;

import com.sf.ext.InvoiceList;

import containers.Invoice;
import containers.Member;
import containers.Person;

public class DataConverter {

	// Create the reader and writer objects needed for each data type
	protected static PersonReader readP = new PersonReader();
	protected static AssetMasterList list = new AssetMasterList();
	protected static MemberReader readM = new MemberReader();
	private static JSONWriter jWrite = new JSONWriter();
	private static XMLWriter xmlWrite = new XMLWriter();
	protected static InvoiceWriter iWrite = new InvoiceWriter();
	private static DatabaseReader dbr = new DatabaseReader();
	private static final org.apache.logging.log4j.Logger Logger = LogManager.getLogger(DataConverter.class);

	private static ArrayList<Invoice> invoiceList = null;

	public static void main(String[] args) {

		// Create array lists to store each data type
		ArrayList<Person> personList = new ArrayList<Person>();
		ArrayList<Member> memberList = new ArrayList<Member>();
		// populate all lists from the database
		try {
			invoiceList = dbr.getInvoices();
			personList = dbr.getPersons();
			memberList = dbr.getMembers();
		} catch (SQLException e1) {
			Logger.info("SQL Error", e1);
			e1.printStackTrace();
		}

		InvoiceList invoices = new InvoiceList();
		for (Invoice i : invoiceList) {
			invoices.add(i);
		}
		LinkedListInvoiceOverview.writeInvoices(invoices);
		invoices.print();

		// Convert each list into a neatly formatted output type

		jWrite.JSONConverter(memberList, "data/Members.json");
		jWrite.JSONConverter(personList, "data/Persons.json");

		xmlWrite.xmlConverter(memberList, "data/Members.xml");
		xmlWrite.xmlConverter(personList, "data/Persons.xml");
		// InvoiceWriter.writeInvoices(invoiceList);

	}

}