package readersWriters;

import com.sf.ext.InvoiceList;

import containers.Asset;
import containers.DayMembership;
import containers.EquipmentRental;
import containers.Invoice;
import containers.ParkingPass;
import containers.YearLongMembership;

public class LinkedListInvoiceOverview {

	public static void writeInvoices(InvoiceList invoices) {

		String s;
		double fees = 0;// invoice associated fees
		double discount = 0;// invoice associated discount
		double totalSubtotal = 0; // invoice associated subtotal
		double totalFees = 0;// invoice associated fees for all invoices
		double totalTaxes = 0; // invoice associated taxes for all invoices
		double totalDiscount = 0;// invoice associated discounts for all
									// discounts
		double totalTotal = 0; // invoice associated totals for all invoices

		// Begin summary report
		System.out.println("Executive Summary Report");
		System.out.println("========================");
		System.out.printf("%s %9s %50s %22s %8s %13s %15s %10s", "Invoice", "Member", "Personal Trainer", "Subtotal",
				"Fees", "Taxes", "Discount", "Total\n");
		// Loop through invoices and print summary reports

		for (Invoice i : invoices) {
			// isYear boolean used to properly calculate discounts
			i.setIsYear(false);
			for (Asset flag : i.getProducts()) {
				// looks for Year long memberships and changes appropriate
				// boolean
				if (flag instanceof YearLongMembership)
					i.setIsYear(true);
			} // end flag setting for loop

			discount = 0;
			i.setSubtotal();

			if (i.isStudent()) {
				s = "[Student]";
				fees = 10.50;
				discount = discount + (i.getSubtotal() * .08);
			} else {
				s = "[General]";
				fees = 0;
			} // end of member type determining

			for (Asset a : i.getProducts()) {
				// loop through assets to determine appropriate discounts
				if (a instanceof YearLongMembership) {

					YearLongMembership y;
					y = (YearLongMembership) a; // cast SuperClass asset to
												// subclass YearLongMembership
					String dateTest = a.getDateTime();

					if (dateTest.charAt(5) == '0' && dateTest.charAt(6) == '1') {
						discount = discount + ((y.getCost() * .15) * y.getQuantity());

					} // end if

					if (a instanceof ParkingPass && i.isYear() == true) {
						a.setCost(0);
					} // end if
					if (a instanceof EquipmentRental && i.isYear() == true) {
						discount = discount + ((a.getCost() * .05) * a.getQuantity());

					} // end if

				} // end YearLong if
				if (a instanceof DayMembership) {
					String dateTest = a.getDateTime();

					if (dateTest.charAt(5) == '0' && dateTest.charAt(6) == '1') {
						discount = discount + ((a.getCost() * .5) * a.getQuantity());

					} // end nested if
				} // end DayMembership if

				i.setTax(i.getTax() + (a.getTax() * a.getQuantity()));
				discount = discount + a.getDiscount();

				i.setDiscount(discount);

			} // end for asset loop
				// print details for each Invoice in a full summary report
			System.out.printf("%-10s %-40s %-30s %s %-10.2f %s %-10.2f %s %-10.2f %s %-10.2f %s %-10.2f",
					i.getInvoiceCode(), i.getMemberName().getName() + " " + s, i.getPersonalTrainer().getName(), "$",
					i.getSubtotal(), "$", fees, "$", i.getTax(), "$", i.getDiscount(), "$",
					(i.getSubtotal() + fees + i.getTax() - discount));
			System.out.println("");
			totalSubtotal = totalSubtotal + i.getSubtotal();
			totalFees = totalFees + fees;
			totalTaxes = totalTaxes + i.getTax();
			totalDiscount = totalDiscount + i.getDiscount();
			totalTotal = totalTotal + (i.getSubtotal() + fees + i.getTax() - discount);
		} // end for invoice loop

		System.out.println("============================================================================"
				+ "=========================================================================");
		System.out.printf("%s %77s %.2f %3s %.2f %6s %.2f %6s %.2f %5s %.2f %s", "TOTALS", "$", totalSubtotal, "$",
				totalFees, "$", totalTaxes, "$", totalDiscount, "$", totalTotal, "\n");
		System.out.println("\nIndividual Invoice Detail Reports");
		System.out.println("==================================================");

	}
}
