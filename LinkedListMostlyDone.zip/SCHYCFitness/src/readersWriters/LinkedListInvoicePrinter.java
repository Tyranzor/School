package readersWriters;

import containers.Address;
import containers.Asset;
import containers.DayMembership;
import containers.EquipmentRental;
import containers.Invoice;
import containers.ParkingPass;
import containers.YearLongMembership;

public class LinkedListInvoicePrinter {

	/**
	 * Writes neatly formatted invoices to the console
	 *
	 * @param invoices
	 *            arrayList of invoices to be printed
	 */
	public static void print(Invoice i) {

		// begin for loop for detailed invoice discount and information
		double totalSubtotal = 0;
		double totalTaxes = 0;
		double totalTotal = 0;
		double fees = 0;

		i.setIsYear(false);
		for (Asset flag : i.getProducts()) {
			// begin for asset loop for discount calculation
			if (flag instanceof YearLongMembership) {
				i.setIsYear(true);
			} // end if
		} // end asset for loop

		String membershipCode = null;
		if (i.getProducts().get(0) instanceof DayMembership || i.getProducts().get(0) instanceof YearLongMembership) {
			membershipCode = i.getProducts().get(0).getProductCode();
		} // end if

		double discount = 0;
		i.setSubtotal();

		String s;
		if (i.isStudent()) {
			s = "[Student]";
			fees = 10.50;
			discount = discount + (i.getSubtotal() * .08);
		} else {
			s = "[General]";
			fees = 0;
		} // end if else for member type

		System.out.println("Invoice " + i.getInvoiceCode());
		System.out.println("========================");
		System.out.println("Personal Trainer: " + i.getPersonalTrainer().getLastName() + ", "
				+ i.getPersonalTrainer().getFirstName());
		System.out.println("Member Info:");
		System.out.println(i.getMemberName().getName() + " (" + i.getMemberCode() + ")");
		System.out.println(s);
		System.out.println(i.getMemberName().getAddress().toString());
		System.out.println("-------------------------------------------");
		System.out.printf("%-8s %-60s %-18s %-15s %s %s", "Code", "Item", "SubTotal", "Tax", "Total", "\n");

		for (Asset a : i.getProducts()) {
			// asset loop to handle all printing and pricing of assets
			String productName = null;
			Address address = null;
			String date = null;

			double assetDiscount = 0;// total discount on each asset

			if (a instanceof YearLongMembership) {
				// cast superclass asset to subclass YearLongMembership
				YearLongMembership y;
				y = (YearLongMembership) a;
				String dateTest = y.getStartDate();

				if (dateTest.charAt(5) == '0' && dateTest.charAt(6) == '1') {
					assetDiscount = ((y.getCost() * .15) * y.getQuantity());
					y.setCost(y.getCost() * .85);

				} // end if to test for first month discount
			} // end instanceof YearLongMembership if
			/**
			 * below if loops apply appropriate discounts to correct products
			 */
			if (a instanceof ParkingPass && i.isYear() != false) {

				a.setCost(0);
			} // end instanceof ParkingPass if
			if (a instanceof EquipmentRental && i.isYear() != false) {
				assetDiscount = ((a.getCost() * .05) * a.getQuantity());
				a.setCost(a.getCost() - (a.getCost() * .05));

			} // end instanceof EquipmentRental if

			else if (a instanceof DayMembership) {
				DayMembership d;
				d = (DayMembership) a;
				String dateTest = a.getDateTime();

				if (dateTest.charAt(5) == '0' && dateTest.charAt(6) == '1') {
					assetDiscount = ((d.getCost() * .5) * d.getQuantity());
					d.setCost(d.getCost() - (d.getCost() * .5));

				} // end first month test if
			} // end instanceof DayMembership

			i.setTax(i.getTax() + a.getTax());
			discount = discount + a.getDiscount();
			i.setDiscount(discount);
			/**
			 * Below loops sort superclass assets to appropriate printing code
			 */
			if (a.getName() == null) {
				if (a.getIdentifier().equalsIgnoreCase("D")) {
					productName = "Day-long membership";
					address = a.getAddress();
					date = a.getDateTime();
				} else if (a.getIdentifier().equalsIgnoreCase("Y")) {
					productName = "Year-long membership";
					address = a.getAddress();
					date = a.getDateTime();

				} else if (a.getIdentifier().equalsIgnoreCase("P")) {
					productName = "Parking Pass";
				}

			} else {
				productName = a.getName();
			} // end product type sorting if statements
			/**
			 * calculate totals for each item
			 */
			totalSubtotal = totalSubtotal + (a.getCost() * a.getQuantity());
			totalTaxes = totalTaxes + (a.getTax() * a.getQuantity());
			totalTotal = totalTotal + (a.getCost() * a.getQuantity() + a.getTax() * a.getQuantity());

			// Print a Day or Year Membership in a neatly formatted fashion
			if (a.getIdentifier().equalsIgnoreCase("D") || a.getIdentifier().equalsIgnoreCase("Y")) {
				System.out.printf("%-8s %-60s %-1s %-16.2f %s %-13.2f %s %.2f %-9s %s %s %s %.2f %s",
						a.getProductCode(), productName + " @ " + address.getStreet().toString(), "$",
						a.getCost() * a.getQuantity(), "$", a.getTax() * a.getQuantity(), "$",
						(a.getCost() * a.getQuantity() + a.getTax() * a.getQuantity()), "\n", date, "(",
						a.getQuantity() + " units @ $", +a.getCost(), ")");
				System.out.println("\n");
			}
			// Print a Parking Pass or Rental without a membership attached
			// in a neatly formatted fashion
			else if ((a.getIdentifier().equalsIgnoreCase("P") || a.getIdentifier().equalsIgnoreCase("R"))
					&& membershipCode == null) {
				System.out.printf("%-8s %-1s %-1s %-1d %-1s %-1s %.2f %-26s %s %-16.2f %s %.2f %10s %.2f",
						a.getProductCode(), productName, "(", a.getQuantity(), "units @", "$", a.getCost(), ")", "$",
						a.getCost() * a.getQuantity(), "$", a.getTax() * a.getQuantity(), "$",
						(a.getCost() * a.getQuantity() + a.getTax() * a.getQuantity()));
				System.out.println("\n");
			}
			// Print a Parking Pass or Rental with a membership attached in
			// a neatly formatted fashion
			else if (a.getIdentifier().equalsIgnoreCase("P") || a.getIdentifier().equalsIgnoreCase("R")) {
				System.out.printf("%-8s %-1s %-1s %-1s %-1d %-1s %.2f %-22s %s %-7.2f %10s %.2f %10s %.2f",
						a.getProductCode(), productName, membershipCode, "(", a.getQuantity(), "units @ $", a.getCost(),
						")", "$", a.getCost() * a.getQuantity(), "$", a.getTax() * a.getQuantity(), "$",
						(a.getCost() * a.getQuantity() + a.getTax() * a.getQuantity()));
				System.out.println("\n");
			}

		} // end else if statements

		System.out.println(
				"                                                                     ===========================================");
		System.out.printf("%-68s %s %-16.2f %s %-13.2f %s %-10.2f", "SUB-TOTALS", "$", totalSubtotal, "$", totalTaxes,
				"$", totalTotal);
		System.out.print("\n");
		if (i.isStudent()) {
			System.out.printf("%-103s %s %.2f", "DISCOUNT (8%  STUDENT & NO TAX)", "$",
					(totalSubtotal * .08) + totalTaxes);
			System.out.print("\n");
			System.out.printf("%-103s %s %.2f", "ADDITIONAL FEE (Student)", "$", 10.50);
			System.out.print("\n");
			System.out.printf("%-103s %s %.2f", "TOTAL", "$", (totalSubtotal - totalSubtotal * .08 + 10.50));
		} else {
			System.out.printf("%-103s %s %.2f", "TOTAL", "$", totalTotal);
		}

		System.out.print("\n");
		System.out.println("Thank you for your purchase!\n");

	}// end print method

}// end class
