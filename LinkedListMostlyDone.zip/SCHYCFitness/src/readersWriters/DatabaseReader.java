/**
 *
 */
package readersWriters;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.logging.log4j.LogManager;

import containers.Address;
import containers.Asset;
import containers.DayMembership;
import containers.EquipmentRental;
import containers.Invoice;
import containers.Member;
import containers.ParkingPass;
import containers.Person;
import containers.YearLongMembership;

/**
 *
 * @author Nathan Pittman with java-induced rage control provided by Jonathan
 *         Trost
 * allowed Eclipse to handle autoformatting of comments, and some of them come out weird on certain monitors
 */
/**
 * @author npittman
 *
 */
public class DatabaseReader {
	// Reads, builds and sorts appropriate data objects from the database

	private static ArrayList<Invoice> invoiceList = new ArrayList<Invoice>();// Arraylist
																				// of
																				// invoice
																				// objects
	private static ArrayList<Person> personList = new ArrayList<Person>();// Arraylist
																			// of
																			// person
																			// objects
	private static ArrayList<Member> memberList = new ArrayList<Member>();// Arraylist
																			// of
																			// member
																			// objects
	private static HashMap<Integer, Address> addressList = new HashMap<Integer, Address>(); // Arraylist
																							// of
																							// address
																							// objects
	private static ArrayList<String> invoiceCodeList = new ArrayList<String>(); // Arraylist
																				// of
																				// invoice
																				// codes
																				// used
																				// to
																				// build
																				// invoices
																				// objects
	private static ArrayList<Asset> assetCodeList = new ArrayList<Asset>(); // Arraylist
																			// of
																			// product
																			// objects
																			// used
																			// to
																			// build
																			// invoice
																			// objects
	private static ArrayList<Asset> lostAssets = new ArrayList<Asset>();// catches
																		// any
																		// products
																		// that
																		// do
																		// not
																		// have
																		// an
																		// associated
																		// invoice
																		// and
																		// sends
																		// them
																		// to
																		// the
																		// log4j
																		// logger
	private static SQLFactory fact = new SQLFactory();// factory SQL methods for
														// database data
														// retrieval
	private static final org.apache.logging.log4j.Logger Logger = LogManager.getLogger(DataConverter.class);// log4j2
																											// logger
																											// to
																											// handle
																											// logging
																											// any
																											// errors
																											// during
																											// execution

	/**
	 * processes data from the database based on the returned results from
	 * subsequent methods
	 *
	 * @return ResultSet from passed table
	 */

	public static ResultSet getTable(String tableName) {

		String sql = "SELECT * FROM " + tableName;
		ResultSet rs = fact.executeQuery(sql);
		return rs;
	}

	/**
	 * Retrieves builds and sorts all person objects from the database
	 *
	 * @return the list of all person objects
	 * @throws SQLException
	 */
	public static ArrayList<Person> getPersons() throws SQLException {
		ResultSet persons = getTable("Person");
		getAddress();
		Address a = null;
		while (persons.next()) {

			for (Integer i : addressList.keySet()) {
				// retrieve address for the person
				if ((persons.getInt("address")) == i) {
					a = addressList.get(i);
					;
				} // close if
			} // close for
			/**
			 * determines if the person object has associated emails and builds
			 * the person objects
			 */
			if (persons.getString("emails") != null) {
				Person p = new Person(persons.getString("lastName"), persons.getString("personCode"),
						persons.getString("emails"), a, persons.getString("firstName"));
				personList.add(p);
			} else {
				Person p = new Person(persons.getString("lastName"), persons.getString("personCode"), a,
						persons.getString("firstName"));
				personList.add(p);

			} // end else if person construction
		} // end ResultSet while
		return personList;
	}// end method

	/**
	 * retrieves all address data from database and builds appopriate objects
	 *
	 * @throws SQLException
	 */
	public static void getAddress() throws SQLException {

		ResultSet addresses = getTable("Address");
		while (addresses.next()) {
			Address a = new Address(addresses.getString("street"), addresses.getString("city"),
					addresses.getString("state"), addresses.getString("country"), addresses.getString("zip"));
			addressList.put(addresses.getInt("ID"), a);
		} // end while
	}// end method

	/**
	 * retrieves and builds all member objects after utilizing the getPerson
	 * method
	 *
	 * @return list of all member objects
	 * @throws SQLException
	 */

	public static ArrayList<Member> getMembers() throws SQLException {
		ResultSet members = getTable("Member");
		Address a = null;
		Person trainer = null;
		while (members.next()) {

			for (Integer i : addressList.keySet()) {
				// retrieve address
				if ((members.getInt("address")) == i) {

					a = addressList.get(i);

				} // end address if
			} // end for loop

			for (Person P : personList) {
				// retirieves correct person object for the primary contact of
				// the member
				if (members.getString("person").contentEquals(P.getPersonCode())) {
					trainer = P;
				} // end if
			} // end person for
			/**
			 * builds member objects and populates arrayList
			 */
			Member m = new Member(members.getString("memType"), members.getString("memberCode"), trainer,
					members.getString("memName"), a);
			memberList.add(m);

		} // end while
		return memberList;
	}// end method

	/**
	 * retrieves and builds all invoices from the database, utilizes all other
	 * methods in this class as well as building all appropriate asset objects
	 *
	 * @return list of all invoice objects
	 * @throws SQLException
	 */
	public static ArrayList<Invoice> getInvoices() throws SQLException {
		getAddress();
		getPersons();
		getMembers();
		boolean isStudent = false;// Invoice isStudent boolean placeholder
		/**
		 * below are a series of null objects used later in construction of
		 * invoices
		 */
		ParkingPass p = null;
		EquipmentRental r = null;
		DayMembership d = null;
		YearLongMembership y = null;
		Invoice inv = null;
		Address a = null;
		ArrayList<Asset> aList = new ArrayList<Asset>();
		Member mem = null;
		Person train = null;
		/**
		 * builds all parkingPass objects
		 */
		ResultSet rs = getTable("ParkingPass");
		while (rs.next()) {

			p = new ParkingPass(rs.getString("productCode"), "P", rs.getDouble("subtotal"), rs.getDouble("discount"),
					rs.getDouble("subtotal"), rs.getInt("quantity"));

			if (rs.getString("invoiceCode") == null) {
				lostAssets.add(p);
			} else {
				invoiceCodeList.add(rs.getString("invoiceCode"));

				assetCodeList.add(p);
			} // end else if to handle invoiceCode assignment, also handles any
				// Assets with no associated invoiceCode
		} // end while

		/**
		 * Builds all equipmentRental objects
		 */

		rs = getTable("EquipmentRental");
		while (rs.next()) {
			r = new EquipmentRental(rs.getString("productCode"), "R", rs.getDouble("subtotal"),
					rs.getString("rentalName"), rs.getInt("quantity"), rs.getDouble("subtotal"));
			if (rs.getString("invoiceCode") == null) {
				lostAssets.add(r);
			} else {
				invoiceCodeList.add(rs.getString("invoiceCode"));

				assetCodeList.add(r);
			} // end else if to handle invoiceCode assignment, also handles any
				// Assets with no associated invoiceCode
		} // end while

		/**
		 * builds all DayMembership objects
		 */

		rs = getTable("DayMembership");
		while (rs.next()) {

			for (Integer i : addressList.keySet()) {
				// retrieves correct address
				if ((rs.getInt("address")) == i) {
					a = addressList.get(i);

				} // end address if
			} // end address for

			d = new DayMembership(rs.getString("productCode"), "D", rs.getDouble("subtotal"), a,
					rs.getString("timeDate"), rs.getInt("quantity"), rs.getDouble("subtotal"));
			if (rs.getString("invoiceCode") == null) {
				lostAssets.add(d);
			} else {
				invoiceCodeList.add(rs.getString("invoiceCode"));

				assetCodeList.add(d);
			} // end else if to handle invoiceCode assignment, also handles any
				// Assets with no associated invoiceCode
		} // end while

		/**
		 * builds all YearMembership objects
		 */

		rs = getTable("YearMembership");
		while (rs.next()) {

			for (Integer i : addressList.keySet()) {
				// retrieves correct address
				if ((rs.getInt("address")) == i) {
					a = addressList.get(i);

				} // end address if
			} // end address for

			y = new YearLongMembership(rs.getString("productCode"), "Y", rs.getDouble("subtotal"),
					rs.getString("timeDateStart"), rs.getString("timeDateEnd"), a, rs.getString("membershipName"),
					rs.getInt("quantity"), rs.getDouble("subtotal"));
			if (rs.getString("invoiceCode") == null) {
				lostAssets.add(y);
			} else {
				invoiceCodeList.add(rs.getString("invoiceCode"));

				assetCodeList.add(y);
			} // end else if to handle invoiceCode assignment, also handles any
				// Assets with no associated invoiceCode
		} // end while

		/**
		 * builds all invoice objects
		 */

		rs = getTable("Invoice");

		while (rs.next()) {

			for (int i = 0; i < assetCodeList.size(); i++) {
				// collects all Assets with the invoiceCode associated with this
				// invoice
				if (invoiceCodeList.get(i).contentEquals(rs.getString("invoiceCode"))) {
					aList.add(assetCodeList.get(i));
				} // end if
			} // end for loop

			/**
			 * boolean to determine if member is a student
			 */
			ResultSet bool = fact
					.executeQuery("Select memType from Member where memberCode like '" + rs.getString("member") + "';");
			while (bool.next()) {
				if (bool.getString("memType").equalsIgnoreCase("s")) {
					isStudent = true;
				} else {
					isStudent = false;
				} // end else if
			} // end while

			for (Member m : memberList) {

				if (m.getMemberCode().contentEquals(rs.getString("member"))) {
					mem = m;
				} // end if
			} // end member assignment for
			for (Person pt : personList) {

				if (pt.getPersonCode().contentEquals(rs.getString("personalTrainer"))) {
					train = pt;
				} // end if
			} // end personalTrainer assignment for

			inv = new Invoice(rs.getString("invoiceCode"), mem, train, rs.getString("timeDate"), aList, isStudent);
			invoiceList.add(inv);
			aList.clear();
		} // end while
		Logger.info("Warning! Assets imported from database with no correlating Invoice!", lostAssets);// hands
																										// all
																										// assets
																										// with
																										// no
																										// associated
																										// invoiceCode
																										// to
																										// the
																										// log4j2
																										// logger
		return invoiceList;
	}// end method
}// end class
