package unl.cse.labs.lab03;
import java.util.HashMap;
public class ChildCredit {

	public static void main(String args[]) {
		Child tom = new Child("Tommy", 2);
		Child dick = new Child("Richard", 18);
		Child harry = new Child("Harold", 19);
		
		Child arr[] = new Child[3];
		arr[0] = tom;
		arr[1] = dick;
		arr[2] = harry;
		getCredit(arr);
	

		
	}
	public static void getCredit (Child[] array){
		HashMap<String, Integer> childCredit = new HashMap();
		int totalCredit=0;
		boolean first=false;
		for (Child c: array){
			if(c.getAge()<18&&first==false){
				
				first=true;
				childCredit.put(c.getName(), 1000);
				totalCredit+=1000;
			}
			else if (c.getAge()<18&&first==true){
				childCredit.put(c.getName(), 500);
				totalCredit+=500;
			}
			else if (c.getAge()>=18){
				childCredit.put(c.getName(), 0);
			}
			
			System.out.printf("%10s\t%7s",c.getName(), "$"+childCredit.get(c.getName()));
			System.out.println("");
			
			
			
		}
		System.out.printf("%10s\t%7s","Total Credit", "$"+totalCredit);
		
		
		
}
}
