package unl.cse.labs.lab03;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

public class Baseball {

	public static void main(String args[]) {
		
		String fileName = "data/mlb_nl_2011.txt";
		Scanner s = null;
		try {
			s = new Scanner(new File(fileName));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		String name;
		int wins;
		int losses;
		int count=0;
		
		Team teams[] = new Team[16];

		while (s.hasNext()){
			name=s.next();
			wins=s.nextInt();
			losses=s.nextInt();
			teams[count]= new Team(name, wins, losses);
			count++;
		}

		System.out.println("Teams: ");
		for(Team t : teams) {
			System.out.println(t);
		}

		Arrays.sort(teams, new Comparator<Team>() {
			@Override
			public int compare(Team a, Team b) {
				return b.getWinPercentage().compareTo(a.getWinPercentage());
			}
			
		});
		
		System.out.println("\n\nSorted Teams: ");
		PrintWriter clear;
		try {
			clear= new PrintWriter (new FileWriter("data/mlb_nl_2011_results.txt",false));
			clear.write("");
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		for(Team t : teams) {
			System.out.println(t);
		
		
		
			PrintWriter out;
			
			try {
				
				out = new PrintWriter (new FileWriter("data/mlb_nl_2011_results.txt",true));
	
				out.printf("%10s\t %5.2f,%1s", t.getName(),(t.getWinPercentage()*100),"%" );
				out.println();
				out.flush();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
		
		}
		
	}
	
	
}
