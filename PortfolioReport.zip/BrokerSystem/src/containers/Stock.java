package containers;

public class Stock extends Asset {
private String code;
private final String Identifier="S";
private double quarterlyDividend;
private double baseRateOfReturn;
private double betaMeasure;
private String stockSymbol;
private double shareprice;
private double stockOwned;
private double total;


/**
 * @param code
 * @param quarterlyDividend
 * @param baseRateOfReturn
 * @param betaMeasure
 * @param stockSymbol
 * @param shareprice
 */
public Stock(String code, double quarterlyDividend, double baseRateOfReturn, double betaMeasure, String stockSymbol,
		double shareprice) {
	super();
	this.code = code;
	this.quarterlyDividend = quarterlyDividend;
	this.baseRateOfReturn = baseRateOfReturn;
	this.betaMeasure = betaMeasure;
	this.stockSymbol = stockSymbol;
	this.shareprice = shareprice;
}
/**
 * @return the code
 */
public String getCode() {
	return code;
}
/**
 * @return the identifier
 */
public String getIdentifier() {
	return Identifier;
}
/**
 * @return the quarterlyDividend
 */
public double getQuarterlyDividend() {
	return quarterlyDividend;
}
/**
 * @return the baseRateOfReturn
 */
public double getBaseRateOfReturn() {
	return baseRateOfReturn;
}
/**
 * @return the betaMeasure
 */
public double getBetaMeasure() {
	return betaMeasure;
}
/**
 * @return the stockSymbol
 */
public String getStockSymbol() {
	return stockSymbol;
}
/**
 * @return the shareprice
 */
public double getShareprice() {
	return shareprice;
}
/**
 * @return the stockOwned
 */
public double getStockOwned() {
	return stockOwned;
}
/**
 * @param stockOwned the stockOwned to set
 */
public void setStockOwned(double stockOwned) {
	this.stockOwned = stockOwned;
}
public double getTotal (){
	double Total= this.shareprice*this.stockOwned;
	this.total=Total;
	return total;
}
public double getRiskMeasure(){
	return betaMeasure;
}
public double getRateOfReturn(){
	double RateofReturn= this.baseRateOfReturn+(this.quarterlyDividend*4);
	return RateofReturn/this.total;
}
}
