package containers;

public class PrivateInvestment extends Asset {
private String code;
private final String Identifier="P";
private double quarterlyDivedend;
private double baseRateOfReturn;
private double OmegaMeasure;
private double totalValue;
private double percentOwned;
private double total;
/**
 * @param code
 * @param quarterlyDivedend
 * @param baseRateOfReturn
 * @param omegaMeasure
 * @param totalValue
 */
public PrivateInvestment(String code, double quarterlyDivedend, double baseRateOfReturn, double omegaMeasure,
		double totalValue) {
	super();
	this.code = code;
	this.quarterlyDivedend = quarterlyDivedend;
	this.baseRateOfReturn = baseRateOfReturn;
	OmegaMeasure = omegaMeasure;
	this.totalValue = totalValue;
}
/**
 * @return the code
 */
public String getCode() {
	return code;
}
/**
 * @return the identifier
 */
public String getIdentifier() {
	return Identifier;
}
/**
 * @return the quarterlyDivedend
 */
public double getQuarterlyDivedend() {
	return quarterlyDivedend;
}
/**
 * @return the baseRateOfReturn
 */
public double getBaseRateOfReturn() {
	return baseRateOfReturn;
}
/**
 * @return the omegaMeasure
 */
public double getOmegaMeasure() {
	return OmegaMeasure;
}
/**
 * @return the totalValue
 */
public double getTotalValue() {
	return totalValue;
}
/**
 * @return the percentOwned
 */
public double getPercentOwned() {
	return percentOwned;
}
/**
 * @param percentOwned the percentOwned to set
 */
public void setPercentOwned(double percentOwned) {
	this.percentOwned = percentOwned;
}
public double getTotal(){
	double Total= (this.totalValue*this.percentOwned);
	this.total=Total;
	return total;
}
public double getRiskMeasure (){
	return OmegaMeasure;
}
public double getRateOfReturn(){
	double RateOfReturn;
	RateOfReturn=this.baseRateOfReturn+(this.quarterlyDivedend*4);
	return (RateOfReturn/this.total);
}
}
