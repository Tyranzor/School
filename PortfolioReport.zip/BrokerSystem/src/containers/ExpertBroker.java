package containers;

import java.util.ArrayList;

public class ExpertBroker extends Person {
	private String EBIdentifier="E";
	@SuppressWarnings("unused")
	private String secCode;
	
public ExpertBroker(String identifier, String firstName, String lastName, String street, String city, String state,
			String country, String zip, String personCode, String emaillist,String secCode) {
		super( firstName, lastName, street, city, state, country, zip, personCode, emaillist);
		this.EBIdentifier=identifier;
		this.secCode=secCode;
		// TODO Auto-generated constructor stub
		
	}
	
public ExpertBroker(String Identifier, String firstName, String lastName, String street, String city, String state,
		String country, String zip, String personCode,String secCode) {
	super( firstName, lastName, street, city, state, country, zip, personCode);
	this.EBIdentifier=Identifier;
	this.secCode=secCode;
	// TODO Auto-generated constructor stub
	
}
	/**
	 * @return the identifier
	 */
	public String getIdentifier() {
		return EBIdentifier;
	}
	public double feeCalc(ArrayList<Asset> assets){
		double fees= assets.size()*10;
		return fees;
	}
	public double commissionCalc(ArrayList<Asset> assets){
		double totalCommission = 0;
		for (Asset a :assets){
			double flatfee= assets.size()*10;
			double commission= a.getTotal()*.05;
			totalCommission= totalCommission+commission+flatfee;
		}
		return totalCommission;
	}
	
	/**
	 * @return the street
	 */
	public String getStreet() {
		return street;
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @return the zip
	 */
	public String getZip() {
		return zip;
	}
	public Customer eBrokerConverter(ExpertBroker eb){
		Customer cust= new Customer (eb.getFirstName(), eb.getLastName(),eb.getStreet(),eb.getCity(),eb.getState(),eb.getCountry(),eb.getZip(),eb.getPersoncode());
		return cust;
		
	}
}
