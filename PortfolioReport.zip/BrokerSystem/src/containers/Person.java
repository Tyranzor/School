package containers;

import java.util.ArrayList;

public abstract class Person extends Object {
	private transient String Identifier= "";
	

	private String firstName;
	private String lastName;
	protected String street;
	protected String city;
	protected String state;
	protected String country;
	protected String zip;
	protected String personCode;
	protected String emaillist;
	
	/**
	 * @param identifier
	 * @param firstName
	 * @param lastName
	 * @param street
	 * @param city
	 * @param state
	 * @param country
	 * @param zip
	 * @param personCode
	 * @param emaillist
	 */
	public Person(String firstName, String lastName, String street, String city, String state,
			String country, String zip, String personCode,String emaillist) {
		super();
		this.Identifier = "";
		this.firstName = firstName;
		this.lastName = lastName;
		this.street = street;
		this.city = city;
		this.state = state;
		this.country = country;
		this.zip = zip;
		this.personCode = personCode;
		this.emaillist = emaillist;
	}
	
	/**
	 * @param firstName
	 * @param lastName
	 * @param street
	 * @param city
	 * @param state
	 * @param country
	 * @param zip
	 * @param personCode
	 */
	public Person(String firstName, String lastName, String street, String city, String state, String country,
			String zip, String personCode) {
		super();
		this.Identifier="";
		this.firstName = firstName;
		this.lastName = lastName;
		this.street = street;
		this.city = city;
		this.state = state;
		this.country = country;
		this.zip = zip;
		this.personCode = personCode;
	}


	// Getter and Setter methods
	public String getAddress(){
		return this.street+","+this.city+","+this.state+","+this.zip+","+this.country;
		
	}
	
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPersoncode() {
		return personCode;
	}

	public void setPersonCode(String personCode) {
		this.personCode = personCode;
	}

	public String getEmaillist() {
		return emaillist;
	}

	public void setEmaillist(String emaillist) {
		this.emaillist = emaillist;
	}
	/**
	 * @return the identifier
	 */
	public String getIdentifier() {
		return Identifier;
	}
	public double feeCalc(ArrayList<Asset>assets){
		double fees = 0;
		return fees;
	}
	public double commissionCalc(ArrayList<Asset> assets){
		double commission=0;
		return commission;
	}

	/**
	 * @return the street
	 */
	public String getStreet() {
		return street;
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @return the zip
	 */
	public String getZip() {
		return zip;
	}
	
}



