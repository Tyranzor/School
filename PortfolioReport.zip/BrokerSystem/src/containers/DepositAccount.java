package containers;

public class DepositAccount extends Asset {
	
private String code;
private String Identifier="D";
private String label;
private double apr;
private double total;

/**
 * @param code
 * @param identifier
 * @param label
 * @param apr
 */
public DepositAccount(String code, String label, double apr) {
	super();
	this.code = code;
	this.label = label;
	this.apr = apr;
}
/**
 * @return the code
 */
public String getCode() {
	return code;
}
/**
 * @return the identifier
 */
public String getIdentifier() {
	return Identifier;
}
/**
 * @return the label
 */
public String getLabel() {
	return label;
}
/**
 * @return the apr
 */
public double getApr() {
	return apr;
}
/**
 * @return the total
 */

public double getTotal() {
	return total;
}
/**
 * @param total the total to set
 */

public void setTotal(double total) {
	
}
public double getRiskMeasure(){
	return 0;
}
public double getRateOfReturn(){
	double rateOfReturn= (Math.pow(Math.E, apr)-1);
	return (rateOfReturn*this.total);
}
}
