package containers;

public abstract class Asset extends Object {
private transient String Code;
private transient String Identifier;
private transient double total;
private transient double riskMeasure;
private transient double rateOfReturn;
/**
 * @return the code
 */
public String getCode() {
	return Code;
}
/**
 * @return the identifier
 */
public String getIdentifier() {
	return Identifier;
}
public double getTotal(){
return total;
	
}
public double getRiskMeasure(){
	return riskMeasure;
};
public double getRateOfReturn(){
	return rateOfReturn;
};
}
