package containers;

import java.util.ArrayList;

public class Portfolio extends Asset {
private String Code;

private String Identifier;
private Customer Owner;
private Person Broker;
private double Fees;
private double Comissions;
private double riskMeasure;
private double Returns;
private double Total;
private Customer Beneficiary;
private ArrayList<Asset> AssetList= new ArrayList<Asset>(); 
private double assetCount;

/**
 * @param code
 * @param identifier
 * @param owner
 * @param broker
 * @param fees
 * @param comissions
 * @param riskMeasure
 * @param returns
 * @param total
 * @param beneficiary
 */

public Portfolio(String code, String identifier, Customer owner, Person broker, Customer beneficiary, ArrayList<Asset> assets) {
	super();
	Code = code;
	Identifier = " ";
	Owner = owner;
	Broker = broker;
	Fees = feeCalc();
	Comissions = ComissionCalc();
	this.riskMeasure = calcRisk();
	Returns = calcReturn();
	this.Total = getTotal();
	this.Beneficiary = beneficiary;
	this.assetCount=assets.size();
	for (Asset a:assets){
		AssetList.add(a);
	}
}

/**
 * @param code
 * @param identifier
 * @param owner
 * @param broker
 * @param fees
 * @param comissions
 * @param riskMeasure
 * @param returns
 * @param total
 */
public Portfolio(String code, String identifier, Customer owner, Person broker, ArrayList<Asset> assets) {
	super();
	Code = code;
	Identifier = identifier;
	Owner = owner;
	Broker = broker;
	Fees = feeCalc();
	Comissions = ComissionCalc();
	this.riskMeasure = calcRisk();
	Returns = 0;
	this.Total = getTotal();
	this.assetCount=assets.size();
	for (Asset a:assets){
		AssetList.add(a);
	}
}
public Portfolio (String code,String identifier,Customer owner,Person broker){
	super ();
	Code=code;
	Identifier= identifier;
	Owner=owner;
	Broker=broker;
}

/**
 * @return the code
 */
public String getCode() {
	return Code;
}
/**
 * @return the identifier
 */
public String getIdentifier() {
	return Identifier;
}
/**
 * @return the owner
 */
public Customer getOwner() {
	return Owner;
}
/**
 * @return the broker
 */
public Person getBroker() {
	return Broker;
}
/**
 * @return the fees
 */
public double getFees() {
	double fees = 0;
	if (this.Broker.getIdentifier().contentEquals("j")){
		fees= ((50*this.assetCount)+(.02*this.Returns));
	}
	if (this.Broker.getIdentifier().contentEquals("e")){
		fees= ((10*this.assetCount)+(.05*this.Returns));
	}
	return fees;
}
/**
 * @return the commissions
 */
public double getComissions() {
	double Comission = 0;
	if (this.Broker.getIdentifier().contentEquals("j")){
		Comission= (.02*this.Returns);
	}
	if (this.Broker.getIdentifier().contentEquals("e")){
		Comission= (.05*this.Returns);
	}
	return Comission;
}
/**
 * @return the riskMeasure
 */
public double getRiskMeasure() {
	double aggregatRisk = 0;
	double assetRisk;
	for (Asset a: this.AssetList){
		assetRisk=a.getRiskMeasure();
		double valueMeasure= (a.getTotal()/this.getTotal());
		aggregatRisk+=assetRisk*valueMeasure;
	}
	return aggregatRisk;
}
/**
 * @return the returns
 */
public double getReturns() {
	return Returns;
}
/**
 * @return the total
 */
public double getTotal() {
	double total=0;
	for (Asset a:AssetList){
		
		 total=total+ a.getTotal();
	}
	this.Total=total;
	return total;
}
/**
 * @return the beneficiary
 */
public Customer getBeneficiary() {
	return Beneficiary;
}

public double feeCalc(){
	
return this.Broker.feeCalc(AssetList);


	
}
public double ComissionCalc(){
	return this.Broker.commissionCalc(AssetList);
}

public double calcRisk(){
	
double aggregatRisk = 0;
double assetRisk;
for (Asset a: this.AssetList){
	assetRisk=a.getRiskMeasure();
	double valueMeasure= (a.getTotal()/this.getTotal());
	aggregatRisk+=assetRisk*valueMeasure;
}
return aggregatRisk;
}
public double calcReturn(){
	double totalAsset = 0;
	for (Asset a:AssetList){
		totalAsset+=a.getRateOfReturn()*this.Total;
	}
	
	return totalAsset;
}
public void print(){
	System.out.println("Portfolio report for portfolio: "+this.Code);
	System.out.println("-----------------------------------------------------------");
	try{System.out.print("Owner: "); System.out.println("\t\t\t"+this.Owner.getFirstName()+this.Owner.getLastName());}
	catch(NullPointerException e){}
	System.out.print("Broker: "); System.out.println("\t        "+this.Broker.getFirstName()+this.Owner.getLastName());
	System.out.print("Total:"); System.out.println("\t\t\t "+this.getTotal());
	System.out.print("Fees: "); System.out.println("\t\t\t "+this.feeCalc());
	System.out.print("Commissions"); System.out.println("\t\t "+this.ComissionCalc());
	System.out.print("Risk Measurement: "); System.out.println("\t "+this.getRiskMeasure());
	System.out.print("Returns: "); System.out.println("\t\t "+this.calcReturn());
	System.out.println();
}
}
