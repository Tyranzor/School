package readersWriters;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import com.thoughtworks.xstream.XStream;
import containers.*;




public class XMLWriter {

	public <T extends Person> void xmlPersonConverter(ArrayList<T> personList){
		XStream xs= new XStream();
		File xmlOutput= new File ("data/People.xml");
		PrintWriter xmlPrintWriter = null; 
			
		try {
			 xmlPrintWriter = new PrintWriter(xmlOutput);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		xmlPrintWriter.write("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n");
		xs.alias("person", Person.class);
		String personOutput=xs.toXML(personList);
	
		xmlPrintWriter.write(personOutput);
		xmlPrintWriter.close();
	}
	
	
	
	public <T extends Asset> void xmlAssetsConverter(ArrayList<T> Objects){
		XStream xs= new XStream();
		File xmlOutput= new File ("data/Assets.xml");
		PrintWriter xmlPrintWriter = null; 
			
		try {
			 xmlPrintWriter = new PrintWriter(xmlOutput);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		xmlPrintWriter.write("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n");
		xs.alias("Asset", Asset.class);
		String personOutput=xs.toXML(Objects);
		
		xmlPrintWriter.write(personOutput);
		xmlPrintWriter.close();
	}
	public <T extends Asset> void xmlPortfolioConverter(ArrayList<T> Objects){
		XStream xs= new XStream();
		File xmlOutput= new File ("data/portfolio.xml");
		PrintWriter xmlPrintWriter = null; 
			
		try {
			 xmlPrintWriter = new PrintWriter(xmlOutput);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		xmlPrintWriter.write("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n");
		xs.alias("Portfolio", Portfolio.class);
		String personOutput=xs.toXML(Objects);
		
		xmlPrintWriter.write(personOutput);
		xmlPrintWriter.close();
	}
}




