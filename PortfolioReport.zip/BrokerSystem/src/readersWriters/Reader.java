package readersWriters;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import containers.ExpertBroker;
import containers.JuniorBroker;
import containers.Person;
import containers.Portfolio;
import containers.Asset;
import containers.Customer;
import containers.DepositAccount;
import containers.PrivateInvestment;
import containers.Stock;

@SuppressWarnings("unused")
public class Reader {
	 private ArrayList<Customer> customerList = new ArrayList<Customer>();
	private ArrayList<ExpertBroker> eBrokerList= new ArrayList <ExpertBroker>();
	private ArrayList<JuniorBroker> jBrokerList= new ArrayList <JuniorBroker>();
	private ArrayList<Stock> stockList =new ArrayList <Stock>();
	private ArrayList <DepositAccount> accountList = new ArrayList<DepositAccount>();
	private ArrayList <PrivateInvestment> investmentList =new ArrayList<PrivateInvestment>();

	public void readPersons() {
		Scanner sc = null;		
		try {
			sc = new Scanner(new File("data/Persons.dat"));
			sc.nextLine(); 
		
			
			
			while (sc.hasNext()) {
				ArrayList<String> emaillist = new ArrayList<String>();
				StringBuilder sb= new StringBuilder();
				String line = sc.nextLine();		
				String data[] = line.split("[;,]"); 
//personcode,J,sec543;Baker, C.;Avery Hall,Lincoln,NE,68503,USA;dr@baker.com1svndr													
				String personCode = data[0]; //identifier  
				String brokerCode=data[1];   // secCode
				String lastName = data[2];	//last name
				String firstName = data[3]; // firstname
				String street = data[4];    //street
				String city = data[5];		//city
				String state = data[6];  	//state
				String zip = data[7];		//zip
				String country = data[8];	//country
				                            //email(s)
				if(data.length >= 10&&!data[1].isEmpty()){
				for(int i = 10; i < data.length; i++){
				String emailaddress = data[i];
				sb.append(emailaddress);										
				}}
				if (data.length>=9&&data[1].isEmpty()){
					for(int i = 10; i < data.length; i++){
						String emailaddress = data[i];
						sb.append(emailaddress);
						}	
				}
				
				
				Customer person;
				JuniorBroker jrBroker;
				ExpertBroker exBroker;
				
				if(!(sb.length()>1)&&data[1].isEmpty()){
					person= new Customer (firstName,lastName,street,city,state,country,zip,personCode);
					customerList.add(person);
					sb.delete(0, sb.length());
					
					
				}
				else if(!(sb.length()>1)&&data[1].equalsIgnoreCase("J")) {
					jrBroker= new JuniorBroker ("J",data[4],data[3],data[5],data[6],data[7],data[8],data[9],data[0],data[2]);
					jBrokerList.add(jrBroker);
					sb.delete(0, sb.length());
					
				}
				else if(!(sb.length()>1)&&data[1].equalsIgnoreCase("E")) {
					exBroker= new ExpertBroker ("E",data[4],data[3],data[5],data[6],data[7],data[8],data[9],data[0],data[2]);
					eBrokerList.add(exBroker);
					sb.delete(0, sb.length());
					
				}
				else if((sb.length()>1)&&data[1].isEmpty()) {
					person= new Customer (firstName,lastName,street,city,state,country,zip,personCode,sb.toString());
					
					customerList.add(person);
					sb.delete(0, sb.length());
					
				}
				else if((sb.length()>1)&&data[1].equalsIgnoreCase("J")) {
					jrBroker= new JuniorBroker ("J",data[4],data[3],data[5],data[6],data[7],data[8],data[9],data[0],sb.toString(),data[2]);
					jBrokerList.add(jrBroker);
					sb.delete(0, sb.length());
					
				}
				else if((sb.length()>1)&&data[1].equalsIgnoreCase("E")) {
					exBroker= new ExpertBroker ("J",data[4],data[3],data[5],data[6],data[7],data[8],data[9],data[0],sb.toString(),data[2]);
					eBrokerList.add(exBroker);
					sb.delete(0, sb.length());
					
				}
				
							
			emaillist.clear();
			sb.delete(0, sb.length());}
			sc.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			
		}		
	}
	/**
	 * @return the stockList
	 */
	public ArrayList<Stock> getStockList() {
		return stockList;
	}
	/**
	 * @return the accountList
	 */
	public ArrayList<DepositAccount> getAccountList() {
		return accountList;
	}
	/**
	 * @return the investmentList
	 */
	public ArrayList<PrivateInvestment> getInvestmentList() {
		return investmentList;
	}
	
	/**
	 * @return the personList
	 */
	public ArrayList<Customer> getCustomerList() {
		return customerList;
	}
	/**
	 * @return the eBrokerList
	 */
	public ArrayList<ExpertBroker> geteBrokerList() {
		return eBrokerList;
	}
	/**
	 * @return the jBrokerList
	 */
	public ArrayList<JuniorBroker> getjBrokerList() {
		return jBrokerList;
	}
	public void readAssets() {
		Scanner sc = null;
		try {
			sc = new Scanner(new File("data/Assets.dat"));
			sc.nextLine(); 

			while (sc.hasNext()) {
				String line = sc.nextLine(); 
				String datastuff[] = line.split("[;,]"); 
				ArrayList<String> data= new ArrayList<String>();
				for (String s:datastuff){
					data.add(s);
				}
				String baseRateOfReturn = null;
				String measure=null;
				String stockSymbolOrValue=null;
				String sharePrice=null;
				String APRorDivedend =null;
				String assetCode = data.get(0);
				String identifier = data.get(1);
				String label = data.get(2);
				if (datastuff.length>=4){ APRorDivedend = data.get(3);}
				if (datastuff.length>4){baseRateOfReturn = data.get(4);
				 measure = data.get(5);
				 stockSymbolOrValue = data.get(6);}
				if (datastuff.length>7){sharePrice= data.get(7);}
				
				
				DepositAccount da;
				Stock stock;
				PrivateInvestment pi;
				
				
				if (data.get(1).equalsIgnoreCase("D")){
					da= new DepositAccount(assetCode, label, Double.parseDouble(APRorDivedend));
					accountList.add(da);
				}
				else if (data.get(1).equalsIgnoreCase("S")){
					//code;S;label;quarterlyDividend;baseRateOfReturn;betaMeasure;stockSymbol;sharePrice
					stock= new Stock(assetCode, Double.parseDouble(APRorDivedend), Double.parseDouble(baseRateOfReturn), Double.parseDouble(measure), stockSymbolOrValue, Double.parseDouble(sharePrice));
					stockList.add(stock);
				}
				else if (data.get(1).equalsIgnoreCase("P")){
					//(String code, double quarterlyDivedend, double baseRateOfReturn, double omegaMeasure,
					//double totalValue)
					pi=new PrivateInvestment(assetCode,Double.parseDouble(APRorDivedend),Double.parseDouble(baseRateOfReturn),Double.parseDouble(measure),Double.parseDouble(stockSymbolOrValue));
					investmentList.add(pi);
				}
			
			data.clear();
				
			}
			sc.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			
		}
	}
	
}
