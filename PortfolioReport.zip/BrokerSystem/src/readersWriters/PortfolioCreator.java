package readersWriters;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Scanner;

import containers.*;




public class PortfolioCreator {
	private static Reader read= new Reader();
	private static ArrayList<DepositAccount> accountList;
	private static ArrayList<Stock> stockList;
	private static ArrayList<PrivateInvestment> investmentList;
	private static ArrayList<Asset> assetList;
	private static ArrayList<ExpertBroker>eBrokerList;
	private static ArrayList <JuniorBroker>jBrokerList;
	private static ArrayList<Customer> customerList;
	private static ArrayList<Portfolio> portfolioList;
	
	public static ArrayList<Portfolio> readPortfolios() {
		assetList= new ArrayList<Asset>();
		portfolioList= new ArrayList<Portfolio>();
		ArrayList<Asset> portfolioAssets= new ArrayList<Asset>();
		read.readPersons();
		read.readAssets();
		accountList=read.getAccountList();
		investmentList=read.getInvestmentList();
		eBrokerList= read.geteBrokerList();
		jBrokerList= read.getjBrokerList();
		customerList= read.getCustomerList();
		stockList=read.getStockList();
		
		for (Stock s:stockList){
			assetList.add(s);
		}
		for (DepositAccount da:accountList){
			assetList.add(da);
		}
		for (PrivateInvestment pi:investmentList){
			assetList.add(pi);
		}
		
		Scanner sc = null;
		
			try {
				sc = new Scanner(new File("data/Portfolios.dat"));
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			sc.nextLine(); 
			
			while (sc.hasNext()) { 
				HashMap<String, Double> assetMap= new HashMap<String,Double>();
				boolean flag=false;
				Customer Owner = null;
				Customer placeHolder=null;
				Person Manager = null;
				Customer Beneficiary = null;
				String pCode="";
				Portfolio port;
				
				String line = sc.nextLine(); 
				String datastuff[] = line.split("[;]"); 
				ArrayList<String> data= new ArrayList<String>();
				for (String s:datastuff){
					data.add(s);
				}
				
				 pCode= data.get(0);
				
				for (Customer c: customerList){
					if (c.getPersoncode().contentEquals(data.get(1))){
						 Owner=(Customer)c;
				
						}
					}
				if (Owner==null){for (ExpertBroker e:eBrokerList){
					if (e.getPersoncode().contentEquals(data.get(1))){
						Owner=e.eBrokerConverter(e);
					}
				}
				}
			if (Owner==null){	for (JuniorBroker j:jBrokerList){
					if (j.getPersoncode().contentEquals(data.get(1))){
						Owner= j.jBrokerConverter(j);
					}
				}
			}
				for (ExpertBroker eb:eBrokerList){
					if (eb.getPersoncode().contentEquals(data.get(2))){
						 Manager=(ExpertBroker)eb;
						 
					}
				}
				for (JuniorBroker jb:jBrokerList){ 
					if (jb.getPersoncode().contentEquals(data.get(2))){
						Manager=(JuniorBroker)jb;
						
						}
					}
				
				if (data.size()>3){ 
					for (Customer c:customerList){ 
						if (c.getPersoncode().equals(data.get(3))){
							Beneficiary =c;
							flag=true;
						}
					}
					}
				
				if (data.size()>4){String assetLine=data.get(4);
				String assetInfo[]=assetLine.split("[:,]");
				ArrayList<String> assets= new ArrayList<String>();
				for (String ai:assetInfo){
					assets.add(ai);
					}
				for (int i=0;i<assets.size();i++){
					assetMap.put(assets.get(i), Double.parseDouble(assets.get(i+1)));
					assets.remove(0);assets.remove(0);
					i--;
				}
				
				for (Entry<String,Double> entry: assetMap.entrySet()){ 
					for (Asset a:assetList){
						if (entry.getKey().equals(a.getCode())){
							if (a.getIdentifier().equalsIgnoreCase("s")){ 
								Stock stock= (Stock)a;
								stock.setStockOwned(entry.getValue());
								portfolioAssets.add(stock);}
							
							if (a.getIdentifier().equalsIgnoreCase("p")){ 
								PrivateInvestment pi= (PrivateInvestment)a;
								pi.setPercentOwned(entry.getValue());
								portfolioAssets.add(pi);}
							
							if (a.getIdentifier().equalsIgnoreCase("d")){ 
								DepositAccount da= (DepositAccount)a;
								da.setTotal(entry.getValue());
								portfolioAssets.add(da);}
							}
						}
					}
				}
				
				if (data.size()<=3){ 
					port = new Portfolio(pCode,"",Owner,Manager);
					portfolioList.add(port);}
				else {
					if (!(Beneficiary==null)){
						port = new Portfolio(pCode, "",Owner,Manager,Beneficiary,portfolioAssets);
					portfolioList.add(port);}
					else if (flag=false){
						port = new Portfolio(pCode, "",Owner,Manager,portfolioAssets);
					portfolioList.add(port);	
					}
					
				}
				
				
				flag=false;
				
				}
				
			sc.close();
			return portfolioList;}
			
		
	
	

}
