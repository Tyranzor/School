package readersWriters;
import java.util.ArrayList;

import containers.*;
public class InvoiceWriter {
	 private static InvoiceReader read= new InvoiceReader();
	 public static void writeInvoices(){
		 ArrayList<Invoice> invoices= read.getInvoices();
		 String s;
		 double fees=0;
		 double discount=0;
		for(Invoice i: invoices){
			discount=0;
			i.setSubtotal();
			if (i.isStudent()){
				s="[Student]";
				fees=10.50;
				discount= discount+(i.getSubtotal()*.08);
			}
			else {
				s= "[General]";
				fees=0;
			}
			
			
			for(Asset a: i.getProducts()){
				i.setTax(i.getTax()+a.getTax());
				discount=discount+a.getDiscount();
				
				i.setDiscount(discount);
				
			}
			
			System.out.printf("%-10s %-40s  %-30s %-10f %-10f %-10f %-10f %-10f", i.getInvoiceCode(), 
					i.getMemberCode().getName()+" "+s,  i.getPersonalTrainer().getName(), i.getSubtotal(),fees , i.getTax(), 
					i.getDiscount(), (i.getSubtotal()+fees+i.getTax()-discount) );
			System.out.println("");
		}
		
		for(Invoice i: invoices){
			String membershipCode = null;
			if(i.getProducts().get(0) instanceof DayMembership || i.getProducts().get(0) instanceof YearLongMembership) {
				membershipCode = i.getProducts().get(0).getProductCode();
			}
			
			discount=0;
			i.setSubtotal();
			if (i.isStudent()){
				s="[Student]";
				fees=10.50;
				discount= discount+(i.getSubtotal()*.08);
			}
			else {
				s= "[General]";
				fees=0;
			}
			
			
			for(Asset a: i.getProducts()){
				String productName = null;
				Address address = null;
				String date = null;
			
				i.setTax(i.getTax()+a.getTax());
				discount=discount+a.getDiscount();
				i.setDiscount(discount);
				if(a.getName() == null) {
					if (a.getIdentifier().equalsIgnoreCase("D")){
						productName = "Day-long membership";
						address = a.getAddress();
						date = a.getDateTime();
					}
					else if(a.getIdentifier().equalsIgnoreCase("Y")) {
						productName = "Year-long membership";
						address = a.getAddress();
						date = a.getDateTime();
					}
					else if(a.getIdentifier().equalsIgnoreCase("P")){
						productName = "Parking Pass"; 
					}
					
				}
				else {
					productName = a.getName();
				}
				if(a.getIdentifier().equalsIgnoreCase("D") || a.getIdentifier().equalsIgnoreCase("Y")) {
					System.out.printf("%-8s %s %-30s %s %12.2f %3s %12.2f %3s %12.2f %s %s %s %.2f %s", a.getProductCode(), 
							productName + " @", address.getStreet().toString(),
							"$", a.getCost()*a.getQuantity(), "$", a.getTax()*a.getQuantity(), "$", 
							(a.getCost()*a.getQuantity()+a.getTax()*a.getQuantity()),
							"\n" + date, "(", a.getQuantity() + " units @ $", + a.getCost(), ")");
					System.out.println("\n");
				}
				else if((a.getIdentifier().equalsIgnoreCase("P") || a.getIdentifier().equalsIgnoreCase("R")) && membershipCode == null) {
					System.out.printf("%-8s %s %d %f %f %f %f", a.getProductCode(), productName, a.getQuantity(),
							a.getCost(), a.getCost()*a.getQuantity(), 
							a.getTax()*a.getQuantity(), (a.getCost()*a.getQuantity()+a.getTax()*a.getQuantity()));
					System.out.println("\n");
				}
				else if(a.getIdentifier().equalsIgnoreCase("P") || a.getIdentifier().equalsIgnoreCase("R")){
				System.out.printf("%-8s %s %s %s %d %s %f %-15s %.2f %.2f %.2f", a.getProductCode(), productName, membershipCode, 
						"(", a.getQuantity(), "units @ $", a.getCost(), ")", a.getCost()*a.getQuantity(), 
						a.getTax()*a.getQuantity(), (a.getCost()*a.getQuantity()+a.getTax()*a.getQuantity()));
				System.out.println("\n");
				}
				
				
			}
			
			
			System.out.println("Thank you for your purchase!\n");
		}
		 
	 }

}