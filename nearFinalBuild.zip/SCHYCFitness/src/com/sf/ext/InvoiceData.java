package com.sf.ext;

import java.sql.ResultSet;
import java.sql.SQLException;

import readersWriters.SQLFactory;

public class InvoiceData {

	private static SQLFactory fact = new SQLFactory();

	public static void removeAllPersons() {

		String sql;

		// Remove all foreign key dependencies
		sql = "UPDATE Invoice SET personalTrainer = null";
		fact.executeUpdate(sql);

		sql = "UPDATE Invoice SET member = null";
		fact.executeUpdate(sql);

		// Members must be deleted when deleting all Persons due to the
		// dependency on persons
		sql = "DELETE FROM Member";
		fact.executeUpdate(sql);

		// Delete all Persons
		sql = "DELETE FROM Person";
		fact.executeUpdate(sql);

	}

	/**
	 * 2. Method to add a person record to the database with the provided data.
	 *
	 * @param personCode
	 * @param firstName
	 * @param lastName
	 * @param street
	 * @param city
	 * @param state
	 * @param zip
	 * @param country
	 * @throws SQLException
	 */
	public static void addPerson(String personCode, String firstName, String lastName, String street, String city,
			String state, String zip, String country) throws SQLException {

		String sql;

		// Strings to pass the values to the query properly formatted
		String values = "(" + "'" + personCode + "'" + "," + "'" + firstName + "'" + "," + "'" + lastName + "'" + ")";
		String advalues = "(" + "'" + street + "'" + "," + "'" + city + "'" + "," + "'" + state + "'" + "," + "'" + zip
				+ "'" + "," + "'" + country + "'" + ")";

		// Create the Address for the Person
		sql = "INSERT INTO Address (street,city,state,zip,country) VALUES " + advalues;
		fact.executeUpdate(sql);

		// Select the recently updated address
		int id = 0;
		sql = "SELECT Address.id FROM Address ORDER BY Address.id DESC LIMIT 1";
		ResultSet rs = fact.executeQuery(sql);

		while (rs.next()) {
			// Retrieve by column name
			id = rs.getInt("id");
		}

		// Create the Person
		sql = "INSERT INTO Person (personCode,lastName,firstName) VALUES " + values;
		fact.executeUpdate(sql);

		// Update the Person and set the Address to the ID of the Address
		// added in the first step
		sql = "UPDATE Person SET address = " + id + " WHERE Person.personCode = " + "'" + personCode + "'";
		fact.executeUpdate(sql);

	}

	/**
	 * 3. Adds an email record corresponding person record corresponding to the
	 * provided <code>personCode</code>
	 *
	 * @param personCode
	 * @param email
	 */
	public static void addEmail(String personCode, String email) {

		String sql;

		// Add the email(s) to the Person indicated
		sql = "UPDATE Person SET emails = " + "'" + email + "'" + " WHERE personCode = " + "'" + personCode + "'";
		fact.executeUpdate(sql);

	}

	/**
	 * 4. Method that removes every member record from the database
	 */
	public static void removeAllMembers() {

		String sql;

		// Remove foreign key dependency
		sql = "UPDATE Invoice SET member = null";
		fact.executeUpdate(sql);

		// Delete all members
		sql = "DELETE FROM Member";
		fact.executeUpdate(sql);

	}

	/**
	 * 5. Method to add a member record to the database with the provided data
	 *
	 * @param memberCode
	 * @param memberType
	 * @param primaryContactPersonCode
	 * @param name
	 * @param street
	 * @param city
	 * @param state
	 * @param zip
	 * @param country
	 * @throws SQLException
	 */
	public static void addMember(String memberCode, String memberType, String primaryContactPersonCode, String name,
			String street, String city, String state, String zip, String country) throws SQLException {

		String sql;

		// Format the values for the queries
		String values = "(" + "'" + memberCode + "'" + "," + "'" + memberType + "'" + "," + "'"
				+ primaryContactPersonCode + "'" + "," + "'" + name + "'" + ")";
		String advalues = "(" + "'" + street + "'" + "," + "'" + city + "'" + "," + "'" + state + "'" + "," + "'" + zip
				+ "'" + "," + "'" + country + "'" + ")";

		// Create a new Address with the values given
		sql = "INSERT INTO Address (street,city,state,zip,country) VALUES " + advalues;
		fact.executeUpdate(sql);

		// Select the recently updated Address
		int id = 0;
		sql = "SELECT  Address.id FROM Address ORDER  BY Address.id DESC LIMIT 1";
		ResultSet rs = fact.executeQuery(sql);

		while (rs.next()) {
			// Retrieve by column name
			id = rs.getInt("id");
		}

		// Create a new Member with the values given
		sql = "INSERT INTO Member (memberCode,memType,person,memName) VALUES " + values;
		fact.executeUpdate(sql);

		// Update the Member and set the Address to the ID of the Address
		// added earlier
		sql = "UPDATE Member SET address = " + id + " WHERE Member.memberCode=" + "'" + memberCode + "'";
		fact.executeUpdate(sql);

	}

	/**
	 * 6. Removes all product records from the database
	 */
	public static void removeAllProducts() {

		String sql;

		// Delete all Year Memberships
		sql = "DELETE FROM YearMembership";
		fact.executeUpdate(sql);

		// Delete all Day Memberships
		sql = "DELETE FROM DayMembership";
		fact.executeUpdate(sql);

		// Delete all Parking Passes
		sql = "DELETE FROM ParkingPass";
		fact.executeUpdate(sql);

		// Delete all Equipment Rentals
		sql = "DELETE FROM EquipmentRental";
		fact.executeUpdate(sql);

	}

	/**
	 * 7. Adds a day-pass record to the database with the provided data.
	 *
	 * @throws SQLException
	 */
	public static void addDayPass(String productCode, String dateTime, String street, String city, String state,
			String zip, String country, int quantity, double discount, double tax, double subtotal, double total)
			throws SQLException {

		// Create formatted strings with values for the queries
		String values = "(" + "'" + productCode + "'" + "," + "'" + "D" + "'" + "," + "'" + dateTime + "'" + "," + "'"
				+ quantity + "'" + "," + "'" + discount + "'" + "," + "'" + tax + "'" + "," + "'" + subtotal + "'" + ","
				+ "'" + total + "'" + ")";
		String advalues = "(" + "'" + street + "'" + "," + "'" + city + "'" + "," + "'" + state + "'" + "," + "'" + zip
				+ "'" + "," + "'" + country + "'" + ")";

		// Create a new address
		String sql = "INSERT INTO Address (street,city,state,zip,country) VALUES " + advalues;
		fact.executeUpdate(sql);

		// Select the recently created address
		int id = 0;
		sql = "SELECT  Address.id FROM Address ORDER  BY Address.id DESC LIMIT 1";
		ResultSet rs = fact.executeQuery(sql);

		while (rs.next()) {
			// Retrieve by column name
			id = rs.getInt("id");
		}

		// Create new Day Membership
		sql = "INSERT INTO DayMembership (productCode,identifier,timeDate,quantity,discount,tax,subtotal,total ) VALUES "
				+ values;
		fact.executeUpdate(sql);

		// Update the Day Membership and set the Address to the ID of the
		// Address just created
		sql = "UPDATE DayMembership SET address = " + id + " WHERE DayMembership.productCode=" + "'" + productCode
				+ "'";
		fact.executeUpdate(sql);

	}

	/**
	 * 8. Adds a year-long-pass record to the database with the provided data.
	 * 
	 * @throws SQLException
	 */
	public static void addYearPass(String productCode, String StartDate, String EndDate, String street, String city,
			String state, String zip, String country, String name, int quantity, double discount, double tax,
			double subtotal, double total) throws SQLException {

		// Create formatted strings with the values for queries
		String values = "(" + "'" + productCode + "'" + "," + "'" + "Y" + "'" + "," + "'" + StartDate + "'" + "," + "'"
				+ EndDate + "'" + "," + "'" + name + "'" + "," + "'" + quantity + "'" + "," + "'" + discount + "'" + ","
				+ "'" + tax + "'" + "," + "'" + subtotal + "'" + "," + "'" + total + "'" + ")";
		String advalues = "(" + "'" + street + "'" + "," + "'" + city + "'" + "," + "'" + state + "'" + "," + "'" + zip
				+ "'" + "," + "'" + country + "'" + ")";

		// Create a new Address
		String sql = "INSERT INTO Address (street,city,state,zip,country) VALUES " + advalues;
		fact.executeUpdate(sql);

		// Select the recently updated Address
		int id = 0;
		sql = "SELECT  Address.id FROM Address ORDER  BY Address.id DESC LIMIT 1";
		ResultSet rs = fact.executeQuery(sql);

		while (rs.next()) {
			// Retrieve by column name
			id = rs.getInt("id");
		}

		// Create a new Year Membership
		sql = "INSERT INTO YearMembership (productCode,identifier,timeDateStart,timeDateEnd,membershipName,quantity,"
				+ "discount,tax,subtotal,total) VALUES " + values;
		fact.executeUpdate(sql);

		// Update the new Year Membership and set the Address to the Address
		// ID created previously
		sql = "UPDATE YearMembership SET address = " + id + " WHERE YearMembership.productCode=" + "'" + productCode
				+ "'";
		fact.executeUpdate(sql);

	}

	/**
	 * 9. Adds a ParkingPass record to the database with the provided data.
	 */
	public static void addParkingPass(String productCode, int quantity, double discount, double tax, double subtotal,
			double total) {

		// Create a formatted string with the values for the query
		String values = "(" + "'" + productCode + "'" + "," + "'" + "P" + "'" + "," + quantity + "," + discount + ","
				+ tax + "," + subtotal + "," + total + ")";

		// Create a new Parking Pass
		String sql = "INSERT INTO ParkingPass (productCode,identifier,quantity, discount,tax,subtotal,total) VALUES "
				+ values;
		fact.executeUpdate(sql);

	}

	/**
	 * 10. Adds an equipment rental record to the database with the provided
	 * data.
	 */
	public static void addRental(String productCode, String name, double quantity, double discount, double tax,
			double subtotal, double total) {

		// Create formatted strings with the values for the queries
		String values = "(" + "'" + productCode + "'" + "," + "'" + "R" + "'" + "," + "'" + name + "'" + "," + quantity
				+ "," + discount + "," + tax + "," + subtotal + "," + total + ")";

		// Create a new Equipment Rental
		String sql = "INSERT INTO EquipmentRental (productCode,identifier,rentalName,quantity,discount,"
				+ "tax,subtotal,total) VALUES " + values;
		fact.executeUpdate(sql);

	}

	/**
	 * 11. Removes all invoice records from the database
	 */
	public static void removeAllInvoices() {

		String sql;

		// Remove foreign key dependency
		sql = "UPDATE DayMembership SET invoiceCode = null";
		fact.executeUpdate(sql);

		// Remove foreign key dependency
		sql = "UPDATE YearMembership SET invoiceCode = null";
		fact.executeUpdate(sql);

		// Remove foreign key dependency
		sql = "UPDATE ParkingPass SET invoiceCode = null";
		fact.executeUpdate(sql);

		// Remove foreign key dependency
		sql = "UPDATE EquipmentRental SET invoiceCode = null";
		fact.executeUpdate(sql);

		// Delete the Invoices
		sql = "DELETE FROM Invoice";
		fact.executeUpdate(sql);

	}

	/**
	 * 12. Adds an invoice record to the database with the given data.
	 */
	public static void addInvoice(String invoiceCode, String memberCode, String personalTrainerCode, String invoiceDate,
			double discount, double tax, double subtotal, double total) {

		String sql;

		// Create formatted strings with the values for the query
		String values = "(" + "'" + invoiceCode + "'" + "," + "'" + invoiceDate + "'" + "," + "'" + discount + "'" + ","
				+ "'" + tax + "'" + "," + "'" + subtotal + "'" + "," + "'" + total + "'" + ")";

		// Create a new Invoice
		sql = "INSERT INTO Invoice (invoiceCode,timeDate,discount,tax,subtotal,total)  VALUES " + values;
		fact.executeUpdate(sql);

		// Update the Invoice and set the Member to the Member Code
		sql = "UPDATE Invoice SET member = " + "'" + memberCode + "'" + "WHERE Invoice.invoiceCode= " + "'"
				+ invoiceCode + "'";
		fact.executeUpdate(sql);

		// Update the Invoice and set the Personal Trainer to the Person
		// Code
		sql = "UPDATE Invoice SET personalTrainer = " + "'" + personalTrainerCode + "'" + "WHERE Invoice.invoiceCode= "
				+ "'" + invoiceCode + "'";
		fact.executeUpdate(sql);

	}

	/**
	 * 13. Adds a particular day-pass (corresponding to <code>productCode</code>
	 * to an invoice corresponding to the provided <code>invoiceCode</code> with
	 * the given number of units
	 * 
	 * @throws SQLException
	 */

	public static void addDayPassToInvoice(String productCode, String dateTime, String street, String city,
			String state, String zip, String country, int quantity, double discount, double tax, double subtotal,
			double total, String InvoiceCode) throws SQLException {

		// Create formatted strings with the values for the queries
		String values = "(" + "'" + productCode + "'" + "," + "'" + "D" + "'" + "," + "'" + dateTime + "'" + "," + "'"
				+ quantity + "'" + "," + "'" + discount + "'" + "," + "'" + tax + "'" + "," + "'" + subtotal + "'" + ","
				+ "'" + total + "'" + "," + "'" + InvoiceCode + "'" + ")";
		String advalues = "(" + "'" + street + "'" + "," + "'" + city + "'" + "," + "'" + state + "'" + "," + "'" + zip
				+ "'" + "," + "'" + country + "'" + ")";

		// Create a new Address
		String sql = "INSERT INTO Address (street,city,state,zip,country) VALUES " + advalues;
		fact.executeUpdate(sql);

		// Select the recently created Address
		int id = 0;
		sql = "SELECT  Address.id FROM Address ORDER  BY Address.id DESC LIMIT 1";
		ResultSet rs = fact.executeQuery(sql);

		while (rs.next()) {
			// Retrieve by column name
			id = rs.getInt("id");
		}

		// Create new Day Membership
		sql = "INSERT INTO DayMembership (productCode,identifier,timeDate,quantity,discount,tax,subtotal,total,invoiceCode) VALUES "
				+ values;
		fact.executeUpdate(sql);

		// Update the Day Membership and set the Address to the Address ID
		// previously created
		sql = "UPDATE DayMembership SET address = " + id + " WHERE DayMembership.productCode=" + "'" + productCode
				+ "'";
		fact.executeUpdate(sql);

	}

	/**
	 * 14. Adds a particular year-long-pass (corresponding to
	 * <code>productCode</code> to an invoice corresponding to the provided
	 * <code>invoiceCode</code> with the given begin/end dates
	 * 
	 * @throws SQLException
	 */
	public static void addYearPassToInvoice(String productCode, String StartDate, String EndDate, String street,
			String city, String state, String zip, String country, String name, int quantity, double discount,
			double tax, double subtotal, double total, String InvoiceCode) throws SQLException {

		// Create formatted strings with the values for the queries
		String values = "(" + "'" + productCode + "'" + "," + "'" + "Y" + "'" + "," + "'" + StartDate + "'" + "," + "'"
				+ EndDate + "'" + "," + "'" + quantity + "'" + "," + "'" + discount + "'" + "," + "'" + tax + "'" + ","
				+ "'" + subtotal + "'" + "," + "'" + total + "'" + "," + "'" + InvoiceCode + "'" + "," + "'" + name
				+ "'" + ")";
		String advalues = "(" + "'" + street + "'" + "," + "'" + city + "'" + "," + "'" + state + "'" + "," + "'" + zip
				+ "'" + "," + "'" + country + "'" + ")";

		// Create a new Address
		String sql = "INSERT INTO Address (street,city,state,zip,country) VALUES " + advalues;
		fact.executeUpdate(sql);

		// Select the recently created Address
		int id = 0;
		sql = "SELECT  Address.id FROM Address ORDER  BY Address.id DESC LIMIT 1";
		ResultSet rs = fact.executeQuery(sql);

		while (rs.next()) {
			// Retrieve by column name
			id = rs.getInt("id");
		}

		// Create a new Year Membership
		sql = "INSERT INTO YearMembership (productCode,identifier,timeDateStart,timeDateEnd,quantity, discount,tax, subtotal, total, invoiceCode, membershipName) VALUES "
				+ values;
		fact.executeUpdate(sql);

		// Update the Year Membership and set the Address to the Address ID
		// previously created
		sql = "UPDATE YearMembership SET address = " + id + " WHERE YearMembership.productCode=" + "'" + productCode
				+ "'";
		fact.executeUpdate(sql);

	}

	/**
	 * 15. Adds a particular ParkingPass (corresponding to
	 * <code>productCode</code> to an invoice corresponding to the provided
	 * <code>invoiceCode</code> with the given number of quantity. NOTE:
	 * membershipCode may be null
	 */
	public static void addParkingPassToInvoice(String productCode, int quantity, double discount, double tax,
			double subtotal, double total, String InvoiceCode) {

		// Create a formatted string of values for the query
		String values = "(" + "'" + productCode + "'" + "," + "'" + "P" + "'" + "," + quantity + "," + discount + ","
				+ tax + "," + subtotal + "," + total + "," + "'" + InvoiceCode + "'" + ")";

		// Create a new Parking Pass
		String sql = "INSERT INTO ParkingPass (productCode,identifier,quantity,"
				+ "discount,tax,subtotal,total,invoiceCode) VALUES " + values;
		fact.executeUpdate(sql);

	}

	/**
	 * 16. Adds a particular equipment rental (corresponding to
	 * <code>productCode</code> to an invoice corresponding to the provided
	 * <code>invoiceCode</code> with the given number of quantity. NOTE:
	 * membershipCode may be null
	 */
	public static void addRentalToInvoice(String productCode, String name, double quantity, double discount, double tax,
			double subtotal, double total, String InvoiceCode) {

		// Create a formatted string with the values for the query
		String values = "(" + "'" + productCode + "'" + "," + "'" + "R" + "'" + "," + quantity + "," + discount + ","
				+ tax + "," + subtotal + "," + total + "," + "'" + InvoiceCode + "'" + "," + "'" + name + "'" + ")";

		// Create a new Equipment Rental
		String sql = "INSERT INTO EquipmentRental (productCode,identifier,quantity,discount,tax,subtotal,"
				+ "total,invoiceCode,rentalName) VALUES " + values;
		fact.executeUpdate(sql);

	}

}