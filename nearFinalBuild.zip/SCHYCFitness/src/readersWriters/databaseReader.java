/**
 *
 */
package readersWriters;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import containers.Address;
import containers.Asset;
import containers.DayMembership;
import containers.EquipmentRental;
import containers.Invoice;
import containers.Member;
import containers.ParkingPass;
import containers.Person;
import containers.YearLongMembership;
import log4j.log4j;

public class databaseReader {

	private static ArrayList<Invoice> invoiceList = new ArrayList<Invoice>();
	private static ArrayList<Person> personList = new ArrayList<Person>();
	private static ArrayList<Member> memberList = new ArrayList<Member>();
	private static HashMap<Integer, Address> addressList = new HashMap<Integer, Address>();
	private static ArrayList<String> invoiceCodeList = new ArrayList<String>();
	private static ArrayList<Asset> assetCodeList = new ArrayList<Asset>();
	private static log4j errorLogger = new log4j();
	private static SQLFactory fact = new SQLFactory();

	/**
	 * processes data from the database based on the returned results from
	 * subsequent methods
	 */

	public databaseReader() {

	}

	public static ResultSet getTable(String tableName) {

		String sql = "SELECT * FROM " + tableName;
		ResultSet rs = fact.executeQuery(sql);
		return rs;
	}

	public static ArrayList<Person> getPersons() throws SQLException {
		ResultSet persons = getTable("Person");
		getAddress();
		Address a = null;
		while (persons.next()) {

			for (Integer i : addressList.keySet()) {
				if ((persons.getInt("address")) == i) {
					a = addressList.get(i);
					;
				}
			}

			if (persons.getString("emails") != null) {
				Person p = new Person(persons.getString("lastName"), persons.getString("personCode"),
						persons.getString("emails"), a, persons.getString("firstName"));
				personList.add(p);
			} else {
				Person p = new Person(persons.getString("lastName"), persons.getString("personCode"), a,
						persons.getString("firstName"));
				personList.add(p);

			}
		}
		return personList;
	}

	/**
	 * retrieves all address data from database and builds appopriate objects
	 *
	 * @throws SQLException
	 */
	public static void getAddress() throws SQLException {

		ResultSet addresses = getTable("Address");
		while (addresses.next()) {
			Address a = new Address(addresses.getString("street"), addresses.getString("city"),
					addresses.getString("state"), addresses.getString("country"), addresses.getString("zip"));
			addressList.put(addresses.getInt("ID"), a);
		}
	}

	public static ArrayList<Member> getMembers() throws SQLException {
		ResultSet members = getTable("Member");
		Address a = null;
		Person trainer = null;
		while (members.next()) {

			for (Integer i : addressList.keySet()) {
				if ((members.getInt("address")) == i) {
					System.out.println(addressList.get(i));
					a = addressList.get(i);

				}
			}

			for (Person P : personList) {
				if (members.getString("person").contentEquals(P.getPersonCode())) {
					trainer = P;
				}
			}
			Member m = new Member(members.getString("memType"), members.getString("memberCode"), trainer,
					members.getString("memName"), a);
			memberList.add(m);

		}
		return memberList;
	}

	public static ArrayList<Invoice> getInvoices() throws SQLException {
		getAddress();
		getPersons();
		getMembers();
		boolean isStudent = false;
		ParkingPass p = null;
		EquipmentRental r = null;
		DayMembership d = null;
		YearLongMembership y = null;
		Invoice inv = null;
		Address a = null;
		ArrayList<Asset> aList = new ArrayList<Asset>();
		Member mem = null;
		Person train = null;

		ResultSet rs = getTable("ParkingPass");
		while (rs.next()) {

			p = new ParkingPass(rs.getString("productCode"), "P", (rs.getDouble("subtotal") / rs.getDouble("quantity")),
					rs.getDouble("discount"), rs.getDouble("subtotal"), rs.getInt("quantity"));

			if (rs.getString("invoiceCode") == null) {
			} else {
				invoiceCodeList.add(rs.getString("invoiceCode"));

				assetCodeList.add(p);
			}
		}

		rs = getTable("EquipmentRental");
		while (rs.next()) {
			r = new EquipmentRental(rs.getString("productCode"), "R",
					(rs.getDouble("subtotal") / rs.getDouble("quantity")), rs.getString("rentalName"),
					rs.getInt("quantity"), rs.getDouble("subtotal"));
			if (rs.getString("invoiceCode") == null) {
			} else {
				invoiceCodeList.add(rs.getString("invoiceCode"));

				assetCodeList.add(r);
			}
		}

		rs = getTable("DayMembership");
		while (rs.next()) {

			for (Integer i : addressList.keySet()) {
				if ((rs.getInt("address")) == i) {
					a = addressList.get(i);

				}
			}

			d = new DayMembership(rs.getString("productCode"), "D",
					(rs.getDouble("subtotal") / rs.getDouble("quantity")), a, rs.getString("timeDate"),
					rs.getInt("quantity"), rs.getDouble("subtotal"));
			if (rs.getString("invoiceCode") == null) {
			} else {
				invoiceCodeList.add(rs.getString("invoiceCode"));

				assetCodeList.add(d);
			}
		}

		rs = getTable("YearMembership");
		while (rs.next()) {

			for (Integer i : addressList.keySet()) {
				if ((rs.getInt("address")) == i) {
					a = addressList.get(i);

				}
			}

			y = new YearLongMembership(rs.getString("productCode"), "Y",
					(rs.getDouble("subtotal") / rs.getDouble("quantity")), rs.getString("timeDateStart"),
					rs.getString("timeDateEnd"), a, rs.getString("membershipName"), rs.getInt("quantity"),
					rs.getDouble("subtotal"));
			if (rs.getString("invoiceCode") == null) {
			} else {
				invoiceCodeList.add(rs.getString("invoiceCode"));

				assetCodeList.add(y);
			}
		}

		rs = getTable("Invoice");

		while (rs.next()) {

			for (int i = 0; i < assetCodeList.size(); i++) {

				if (invoiceCodeList.get(i).contentEquals(rs.getString("invoiceCode"))) {
					aList.add(assetCodeList.get(i));
				}
			}

			ResultSet bool = fact
					.executeQuery("Select memType from Member where memberCode like '" + rs.getString("member") + "';");
			while (bool.next()) {
				if (bool.getString("memType").equalsIgnoreCase("s")) {
					isStudent = true;
				} else {
					isStudent = false;
				}
			}
			for (Member m : memberList) {

				if (m.getMemberCode().contentEquals(rs.getString("member"))) {
					mem = m;
				}
			}
			for (Person pt : personList) {

				if (pt.getPersonCode().contentEquals(rs.getString("personalTrainer"))) {
					train = pt;
				}
			}

			inv = new Invoice(rs.getString("invoiceCode"), mem, train, rs.getString("timeDate"), aList, isStudent);
			invoiceList.add(inv);
			aList.clear();
		}
		return invoiceList;

	}
}
