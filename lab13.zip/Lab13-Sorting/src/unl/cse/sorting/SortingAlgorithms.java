package unl.cse.sorting;

import java.util.Arrays;

public class SortingAlgorithms {

	public static Location[] javaSort(Location list[]) {
		Location result[] = Arrays.copyOf(list, list.length);
		Arrays.sort(result);
		return result;
	}

	public static Location[] selectionSort(Location list[]) {
		Location result[] = Arrays.copyOf(list, list.length);
		for (int i = 0; i < result.length; i++) {
			int minIndex = i;
			for (int j = i + 1; j < result.length; j++) {
				if (result[j].compareTo(result[minIndex]) < 0)
					minIndex = j;
			}
			Location tmp = result[i];
			result[i] = result[minIndex];
			result[minIndex] = tmp;
		}
		return result;
	}

	public static Location[] insertionSort(Location list[]) {
		Location result[] = Arrays.copyOf(list, list.length);
		int i = 1;
		int j;
		while (i < result.length) {
			j = i;
			while (j > 0 && result[j - 1].compareTo(result[j]) > 0) {
				Location temp = result[j];
				result[j] = result[j - 1];
				result[j - 1] = temp;
				j = j - 1;
			}
			i = i + 1;
		}
		return result;
	}

	public static Location[] quickSort(Location list[]) {
		Location result[] = Arrays.copyOf(list, list.length);
		quickSortRecursive(result, 0, result.length - 1);
		return result;
	}

	private static void quickSortRecursive(Location list[], int low, int high) {
		int index = partition(list, low, high);
		if (low < index - 1) {
			quickSortRecursive(list, low, index - 1);
		}
		if (index < high) {
			quickSortRecursive(list, index, high);
		}

	}

	public static int partition(Location list[], int low, int high) {
		int i = low, j = high;
		Location tmp;
		Location pivot = list[(low + high) / 2];

		while (i <= j) {
			while (pivot.compareTo(list[i]) > 0) {
				i++;
			}
			while (pivot.compareTo(list[j]) < 0) {
				j--;
			}
			if (i <= j) {
				tmp = list[i];
				list[i] = list[j];
				list[j] = tmp;
				i++;
				j--;
			}
		}
		return i;
	}

}
