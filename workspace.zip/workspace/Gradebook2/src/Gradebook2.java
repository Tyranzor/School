//************************************************************************************************************************************
// Author: Nathan Pittman  
// This program allows you to get random grades for a set amount of students as well as inputting a seed for the number 
//generator
//*************************************************************************************************************************

import java.util.*;
import java.math.RoundingMode;
import java.text.DecimalFormat;
public class Gradebook2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner scanner=new Scanner (System.in);
String k= ("y");
int s=0, seed=0, y=0; 
DecimalFormat fmt= new DecimalFormat("0.00");
fmt.setRoundingMode(RoundingMode.CEILING);

while (k!=("n")) {
	
	System.out.println("Please enter the seed for the random number generator:");
	
  try  { seed= scanner.nextInt();}
  
  catch (InputMismatchException e) {System.out.println("Please try again! Looks like something went wrong");}
  catch (NoSuchElementException e) {System.out.println("Please double-check your input");}
  catch (IllegalStateException e) {System.out.println("I have no idea how you managed to close the scanner, but well done");}
  
Random random= new Random (seed);

System.out.println("Please enter the number of students");
 
try {  y=scanner.nextInt();}
 catch (InputMismatchException e) {System.out.println("Please try again! Looks like something went wrong");}
 catch (NoSuchElementException e) {System.out.println("Please double-check your input");}
 catch (IllegalStateException e) {System.out.println("I have no idea how you managed to close the scanner, but well done");}



int q=1;//student counter 
int n=0,b=0,v=0,c=0,z=0,f=0,/*These are all throw away variables used to determine averages and totals, they are labeled
in the program where they are used*/
u=0,a=0, d=0, g=0, t=0, r=0;//these are also throw away variables.


int[][] grades;
grades=new int [y][7];
for (int i=0; i<y;i++){
	grades [i][0]= random.nextInt(301)+300;
	grades [i][1]=random.nextInt(301)+300;
	grades [i][2]=random.nextInt(301)+300;
	grades [i][3]= random.nextInt(51)+50;
	grades [i][4]=random.nextInt(126)+125;
	grades [i][5]= random.nextInt(251)+250;
	grades [i][6]= ((grades [i][0])+(grades [i][1])+(grades [i][2])+(grades [i][3])+(grades [i][4])+(grades [i][5] ));
	
}

double [][] percent;
percent= new double [y][1];
for (int j= 0; j<y; j++){
	percent [j][0]= ((grades [j][6]/2400.0)*100);
	
}
String [][] studentcount;
studentcount= new String [y][1];
for (int x=0; x<y; x++){
	
	studentcount [x][0]= ("Student "+ q) ;
	q=q+1;
}

String [][] grade;
grade= new String [y][1];
for (int h=0; h<y; h++){
	if (percent [h][0]>=96.67) { grade [h][0]= ("A+");}
	else if (percent [h][0]>=91.71) { grade [h][0]= ("A");}
	else if (percent [h][0]>=90.04) { grade [h][0] = ("A-");}
	else if (percent [h][0]>=86.71) { grade [h][0] = ("B+");}
	else if (percent [h][0]>=81.71) { grade [h][0] = ("B");}
	else if (percent [h][0]>=80.04) { grade [h][0] = ("B-");}
	else if (percent [h][0]>=76.71){ grade [h][0] = ("C+");}
	else if (percent [h][0]>=71.71) { grade [h][0] = ("C");}
	else if (percent [h][0]>=70.04) { grade [h][0] = ("C-");}
	else if (percent [h][0]>=66.71) { grade [h][0] = ("D+");}
	else if (percent [h][0]>=61.71) { grade [h][0] = ("D");}
	else if (percent [h][0]>=60.04) { grade [h][0] = ("D-");}
	else if (percent [h][0]<=60.03) { grade [h][0] = ("F");}
}

for (int e=0; e<y; e++){
		
		n = n+ (grades [e][0]);// HW total
		b= b+ (grades [e][1]);// lab total
		v= v+ (grades [e][2]);// midterm total
		c= c+ (grades [e][3]);//PRS total
		z= z+ (grades [e][4]);//EC total
		f= f+ (grades [e][5]);//final total
		
	
}
int overalltotal=0;
try{
 overalltotal= (int) (n+b+v+c+z+f);
u= (n/y);// Hw average
a = (b/y);// lab average
d = (v/y);// midterm average
g = (c/y);//PRS average
t = (z/y);// EC average
r= (f/y); //final average
}
catch (Exception e){System.out.println("looks like one of your inputs was wrong, please try again.");}
int maximum=0,max=0;
try { max= grades [0][6];}
catch (ArrayIndexOutOfBoundsException e){System.out.println("Please try again!");}
for ( maximum=0;maximum<y;maximum++){
	if (grades [maximum][6]>max)
	{max= grades [maximum][6];
}
}


int minimum=0,min=0;
try { min= grades [0][6];}
catch (ArrayIndexOutOfBoundsException e){System.out.println("Please try again!");}
	for ( minimum=0; minimum<y; minimum++){
		if (grades [minimum][6]<min){
min= grades [minimum][6];
}
}
	int hwtotal=0,hwmax=0;
try { hwmax= grades [0][0];}
catch (ArrayIndexOutOfBoundsException e){System.out.println("Please try again!");}
	for (int w=0;w<y;w++){
		if (grades [w][0]>hwmax)
{hwmax= grades [w][0];
}

hwtotal=hwtotal + grades [w][0];
}
	int hwmin=0,labtotal=0,labmax=0,labmin=0,midtotal=0,midmin=0,midmax=0,prstotal=0,prsmin=0,
			prsmax=0,ectotal=0,ecmin=0,ecmax=0,finaltotal=0,finalmin=0,finalmax=0;
try{ hwmin= grades [0][0];
	for (int ab=0; ab<y; ab++){
		if (grades [ab][0]<hwmin){
hwmin= grades [ab][0];
}
}
	 labtotal=0;
 labmax= grades [0][1];
	for (int w=0;w<y;w++){
		if (grades [w][1]>labmax)
{labmax= grades [w][1];
}

labtotal=labtotal + grades [w][1];		
}
 labmin= grades [0][1];
	for (int ab=0; ab<y; ab++){
		if (grades [ab][1]<labmin){
labmin= grades [ab][1];
}		
}
	 midtotal=0;
 midmax= grades [0][2];
	for (int w=0;w<y;w++){
		if (grades [w][0]>midmax)
{midmax= grades [w][2];
}

midtotal=midtotal + grades [w][2];
}
 midmin= grades [0][2];
	for (int ab=0; ab<y; ab++){
		if (grades [ab][2]<midmin){
midmin= grades [ab][2];
}
}
	 prstotal=0;
 prsmax= grades [0][3];
	for (int w=0;w<y;w++){
		if (grades [w][3]>prsmax)
{prsmax= grades [w][3];
}

prstotal=prstotal + grades [w][3];		
}
 prsmin= grades [0][3];
	for (int ab=0; ab<y; ab++){
		if (grades [ab][3]<prsmin){
prsmin= grades [ab][3];
}
}
	 ectotal=0;
 ecmax= grades [0][4];
for (int w=0;w<y;w++){
	if (grades [w][4]>ecmax)
{ecmax= grades [w][4];
}

ectotal=ectotal + grades [w][4];	
}
	 ecmin= grades [0][4];
	for (int ab=0; ab<y; ab++){
		if (grades [ab][4]<ecmin){
ecmin= grades [ab][4];
}
}
	 finaltotal=0;
 finalmax= grades [0][5];
	for (int w=0;w<y;w++){
		if (grades [w][5]>finalmax)
{finalmax= grades [w][5];
}

finaltotal=finaltotal + grades [w][5];		
}
 finalmin= grades [0][5];
	for (int ab=0; ab<y; ab++){
		if (grades [ab][5]<finalmin){
finalmin= grades [ab][5];
}
}	
}
catch (ArrayIndexOutOfBoundsException e){System.out.println("Please try again!");}
	System.out.println ("Students    Homework    Labs  Midterm   PRS  \tEC     Final    Total   Grade   Letter grade  ");
for (int ab = 0; ab < grades.length; ab++) {
	System.out.print("Student "+(ab+1)+ "");
    for (int ac = 0; ac < grades[ab].length; ac++) {
    	System.out.print(" \t"+grades[ab][ac] + " ");   	
    }
    System.out.print(" \t"+fmt.format(percent[ab][0])+" ");
    System.out.print(" \t"+grade[ab][0]+" ");
    System.out.println();
}
System.out.println("The maximum for each category is: Homework "+hwmax+ " Labs "+labmax+ " Midterms "+midmax+ " PRS "+
prsmax+ " Extra Credit  "+ ecmax+ " Finals "+finalmax);	
System.out.println("The minimum for each category is: Homework "+hwmin+ " Labs "+labmin+ " Midterms "+midmin+ " PRS "+
prsmin+ " Extra Credit  "+ ecmin+ " Finals "+finalmin);	
System.out.println("The total for each category is: Homework "+hwtotal+ " Labs "+labtotal+ " Midterms "+midtotal+ " PRS "+
prstotal+ " Extra Credit  "+ ectotal+ " Finals "+finaltotal);	
System.out.println("Averages for each category are " +" Homework "+ fmt.format(u) +" Labs " +fmt.format(a)+ " Midterms "
+fmt.format(d) + " PRS "+fmt.format(g)+ " EC "+t +" Final "+ fmt.format(r));
System.out.println("The minimum score is "+min);
System.out.println("The maximum score is "+max);
System.out.println("Points earned through all categories are "+overalltotal);
System.out.println (" ");

System.out.println("Would you like to repeat the program with a new set of data? (y or n)");
 k= ("n");
 k= scanner.next();
 if (k.contains("n")) {scanner.close(); System.exit(s);}
 else if (k.contains("N")) {scanner.close(); System.exit(s);}
 

 

}
}}





