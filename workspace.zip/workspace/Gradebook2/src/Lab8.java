
public class Lab8 {

}
