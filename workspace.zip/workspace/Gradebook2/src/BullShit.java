import java.util.*;
public class BullShit {
	public static void main (String [] args){
		int[][] grades= new int [12] [7];
		Random random=new Random (100);
		
		for (int x=0; x>12; x++){
			for (int j=0; j>7; j++){
				grades [x][j]= random.nextInt(251)+250;
			}
		}
		System.out.println(Arrays.deepToString(grades));
	
}
}

