package unl.cse.albums;

public class DatabaseInfo {

	public static final String url = "jdbc:mysql://cse.unl.edu/login";
	public static final String username = "login";
	public static final String password = "password";
}
